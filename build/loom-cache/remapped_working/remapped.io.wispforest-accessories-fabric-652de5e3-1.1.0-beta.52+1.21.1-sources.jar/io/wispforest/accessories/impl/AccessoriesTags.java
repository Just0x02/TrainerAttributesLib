package io.wispforest.accessories.impl;

import io.wispforest.accessories.Accessories;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.entity.EntityType;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.TagKey;

@Deprecated(forRemoval = true)
public class AccessoriesTags {

    public static final TagKey<EntityType<?>> MODIFIABLE_ENTITY_WHITELIST = io.wispforest.accessories.api.data.AccessoriesTags.MODIFIABLE_ENTITY_WHITELIST;
    public static final TagKey<EntityType<?>> MODIFIABLE_ENTITY_BLACKLIST = io.wispforest.accessories.api.data.AccessoriesTags.MODIFIABLE_ENTITY_BLACKLIST;

    public static final TagKey<Enchantment> VALID_FOR_REDIRECTION = ofTag(RegistryKeys.ENCHANTMENT, "valid_for_redirection");

    public static <T, R extends Registry<T>> TagKey<T> ofTag(RegistryKey<R> resourceKey, String path) {
        return TagKey.of(resourceKey, Accessories.of(path));
    }
}
