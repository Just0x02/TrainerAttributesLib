package io.wispforest.accessories.impl;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Multimap;
import com.google.common.collect.Sets;
import com.google.common.collect.Sets.SetView;
import com.google.common.collect.UnmodifiableIterator;
import io.wispforest.accessories.Accessories;
import io.wispforest.accessories.AccessoriesInternals;
import io.wispforest.accessories.api.*;
import io.wispforest.accessories.api.attributes.AccessoryAttributeBuilder;
import io.wispforest.accessories.api.components.AccessoriesDataComponents;
import io.wispforest.accessories.api.components.AccessoryItemAttributeModifiers;
import io.wispforest.accessories.api.components.AccessoryItemAttributeModifiers.Builder;
import io.wispforest.accessories.api.components.AccessoryNestContainerContents;
import io.wispforest.accessories.api.data.AccessoriesTags;
import io.wispforest.accessories.api.events.*;
import io.wispforest.accessories.api.slot.*;
import io.wispforest.accessories.data.EntitySlotLoader;
import io.wispforest.accessories.data.SlotTypeLoader;
import io.wispforest.accessories.endec.NbtMapCarrier;
import io.wispforest.owo.serialization.RegistriesAttribute;
import it.unimi.dsi.fastutil.Pair;
import io.wispforest.accessories.menu.variants.AccessoriesMenuBase;
import io.wispforest.accessories.networking.AccessoriesNetworking;
import io.wispforest.accessories.networking.client.SyncContainerData;
import io.wispforest.accessories.networking.client.SyncData;
import io.wispforest.accessories.networking.client.SyncEntireContainer;
import io.wispforest.accessories.utils.AttributeUtils;
import io.wispforest.endec.SerializationContext;
import net.fabricmc.fabric.api.util.TriState;
import net.minecraft.component.ComponentType;
import net.minecraft.component.EnchantmentEffectComponentTypes;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.screen.ScreenTexts;
import net.minecraft.server.PlayerManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.GameRules;
import net.minecraft.world.World;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.Map.Entry;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import static io.wispforest.accessories.Accessories.ACCESSORY_EQUIPPED;
import static io.wispforest.accessories.Accessories.ACCESSORY_UNEQUIPPED;

import I;
import Z;

@ApiStatus.Internal
public class AccessoriesEventHandler {

    public static boolean dataReloadOccurred = false;

    public static void onWorldTick(World level) {
        if (!(level instanceof ServerWorld serverLevel)) return;

        revalidatePlayersOnReload(serverLevel.getServer().getPlayerManager());
    }

    public static void revalidatePlayersOnReload(PlayerManager playerList) {
        if (!dataReloadOccurred) return;

        for (var player : playerList.getPlayerList()) revalidatePlayer(player);

        dataReloadOccurred = false;
    }

    public static void revalidatePlayer(ServerPlayerEntity player) {
        var capability = AccessoriesCapability.get(player);

        if (capability == null) return;

        var validSlotTypes = EntitySlotLoader.getEntitySlots(player).values();

        var holderImpl = ((AccessoriesHolderImpl) capability.getHolder());

        holderImpl.setValidTypes(validSlotTypes.stream().map(SlotType::name).collect(Collectors.toSet()));

        for (var container : holderImpl.getAllSlotContainers().values()) {
            var slotType = container.slotType();

            if (slotType != null && validSlotTypes.contains(slotType)) {
                var baseSize = ((AccessoriesContainerImpl) container).getBaseSize();

                if (baseSize == null || baseSize != slotType.amount()) {
                    container.markChanged();
                    container.update();
                }

                var stacks = container.getAccessories();
                var cosmeticStacks = container.getCosmeticAccessories();

                for (int i = 0; i < container.getSize(); i++) {
                    var reference = container.createReference(i);

                    handleInvalidStacks(stacks, reference, player);
                    handleInvalidStacks(cosmeticStacks, reference, player);
                }
            } else {
                // TODO: DROP CONTAINER ?!
                var stacks = container.getAccessories();
                var cosmeticStacks = container.getCosmeticAccessories();

                for (int i = 0; i < container.getSize(); i++) {
                    var reference = container.createReference(i);

                    dropAndRemoveStack(stacks, reference, player);
                    dropAndRemoveStack(cosmeticStacks, reference, player);
                }
            }
        }
    }

    private static void handleInvalidStacks(Inventory container, SlotReference reference, ServerPlayerEntity player) {
        var stack = container.getStack(reference.slot());

        if (stack.isEmpty()) return;

        var bl = !AccessoriesAPI.canInsertIntoSlot(stack, reference);

        if (bl) dropAndRemoveStack(container, reference, player);
    }

    private static void dropAndRemoveStack(Inventory container, SlotReference reference, ServerPlayerEntity player) {
        var stack = container.getStack(reference.slot());

        container.setStack(reference.slot(), ItemStack.EMPTY);

        AccessoriesInternals.giveItemToPlayer(player, stack);
    }

    public static void entityLoad(LivingEntity entity, World level) {
        if (!level.isClient() || !(entity instanceof ServerPlayerEntity serverPlayer)) return;

        SyncEntireContainer.syncToAllTrackingAndSelf(serverPlayer);
    }

    public static void onTracking(LivingEntity entity, ServerPlayerEntity serverPlayer) {
        SyncEntireContainer.syncTo(entity, (packet) -> AccessoriesNetworking.sendToPlayer(serverPlayer, packet));
    }

    public static void dataSync(@Nullable PlayerManager list, @Nullable ServerPlayerEntity player) {
        var syncPacket = SyncData.create();

        if (list != null && !list.getPlayerList().isEmpty()) {
            revalidatePlayersOnReload(list);

            // TODO: OPTIMIZE THIS?
            for (var playerEntry : list.getPlayerList()) {
                AccessoriesNetworking.sendToPlayer(playerEntry, syncPacket);

                var capability = AccessoriesCapability.get(playerEntry);

                if (capability == null) return;

                var carrier = NbtMapCarrier.of();

                ((AccessoriesHolderImpl) capability.getHolder()).write(carrier, SerializationContext.attributes(RegistriesAttribute.of(playerEntry.getWorld().getRegistryManager())));

                AccessoriesNetworking.sendToTrackingAndSelf(playerEntry, new SyncEntireContainer(capability.entity().getId(), carrier));

                if (playerEntry.currentScreenHandler instanceof AccessoriesMenuBase base) {
                    Accessories.openAccessoriesMenu(playerEntry, base.menuVariant(), base.targetEntity());
                }
            }
        } else if (player != null) {
            AccessoriesNetworking.sendToPlayer(player, syncPacket);

            revalidatePlayer(player);

            var capability = AccessoriesCapability.get(player);

            if (capability == null) return;

            var carrier = NbtMapCarrier.of();

            ((AccessoriesHolderImpl) capability.getHolder()).write(carrier, SerializationContext.attributes(RegistriesAttribute.of(player.getWorld().getRegistryManager())));

            AccessoriesNetworking.sendToPlayer(player, new SyncEntireContainer(capability.entity().getId(), carrier));

            if (player.currentScreenHandler instanceof AccessoriesMenuBase base) {
                Accessories.openAccessoriesMenu(player, base.menuVariant(), base.targetEntity());
            }
        }

        AccessoriesCapabilityImpl.clearValidationCache(false);
    }

    public static void onLivingEntityTick(LivingEntity entity) {
        if (entity.isRemoved()) return;

        var capability = AccessoriesCapability.get(entity);

        if (capability != null) {
            var dirtyStacks = new HashMap<String, ItemStack>();
            var dirtyCosmeticStacks = new HashMap<String, ItemStack>();

            var removedAttributesBuilder = new AccessoryAttributeBuilder();
            var addedAttributesBuilder = new AccessoryAttributeBuilder();

            for (var containerEntry : ((AccessoriesHolderImpl)capability.getHolder()).getAllSlotContainers().entrySet()) {
                var container = containerEntry.getValue();

                var accessories = container.getAccessories();
                var cosmetics = container.getCosmeticAccessories();

                for (int i = 0; i < accessories.size(); i++) {
                    var slotReference = container.createReference(i);

                    var slotId = container.getSlotName() + "/" + i;

                    var currentStack = accessories.getStack(i);

                    // TODO: Move ticking below checks?
                    if (!currentStack.isEmpty()) {
                        // TODO: Document this behavior to prevent double ticking maybe!!!
                        currentStack.inventoryTick(entity.getWorld(), entity, -1, false);

                        var accessory = AccessoriesAPI.getOrDefaultAccessory(currentStack);

                        if (accessory != null) accessory.tick(currentStack, slotReference);
                    }

                    var lastStack = accessories.getPreviousItem(i);

                    // Prevent attribute related logic on the client and if the entity
                    // is dead as such data should not be updated. Though we allow for
                    // ticking to occur at least for vanilla parity I guess.
                    if (entity.getWorld().isClient() || entity.isDead()) continue;

                    if (!ItemStack.areEqual(currentStack, lastStack)) {
                        container.getAccessories().setPreviousItem(i, currentStack.copy());
                        dirtyStacks.put(slotId, currentStack.copy());

                        if (!lastStack.isEmpty()) {
                            removedAttributesBuilder.addFrom(AccessoriesAPI.getAttributeModifiers(lastStack, slotReference));
                        }

                        if (!currentStack.isEmpty()) {
                            addedAttributesBuilder.addFrom(AccessoriesAPI.getAttributeModifiers(currentStack, slotReference));
                        }

                        boolean equipmentChange = false;

                        /*
                         * TODO: Does item check need to exist anymore?
                         */
                        if (!ItemStack.areItemsEqual(currentStack, lastStack) || accessories.isSlotFlagged(i)) {
                            AccessoriesAPI.getOrDefaultAccessory(lastStack).onUnequip(lastStack, slotReference);
                            AccessoriesAPI.getOrDefaultAccessory(currentStack).onEquip(currentStack, slotReference);

                            if (entity instanceof ServerPlayerEntity serverPlayer) {
                                if (!currentStack.isEmpty()) {
                                    ACCESSORY_EQUIPPED.trigger(serverPlayer, currentStack, slotReference, false);
                                }

                                if (!lastStack.isEmpty()) {
                                    ACCESSORY_UNEQUIPPED.trigger(serverPlayer, lastStack, slotReference, false);
                                }
                            }

                            equipmentChange = true;
                        }

                        AccessoryChangeCallback.EVENT.invoker().onChange(lastStack, currentStack, slotReference, equipmentChange ? SlotStateChange.REPLACEMENT : SlotStateChange.MUTATION);

                        recursiveStackChange(slotReference, AccessoryNestUtils.getData(lastStack), AccessoryNestUtils.getData(currentStack));
                    }

                    var currentCosmeticStack = cosmetics.getStack(i);
                    var lastCosmeticStack = container.getCosmeticAccessories().getPreviousItem(i);

                    if (!ItemStack.areEqual(currentCosmeticStack, lastCosmeticStack)) {
                        cosmetics.setPreviousItem(i, currentCosmeticStack.copy());
                        dirtyCosmeticStacks.put(slotId, currentCosmeticStack.copy());

                        if (entity instanceof ServerPlayerEntity serverPlayer) {
                            if (!currentStack.isEmpty()) {
                                ACCESSORY_EQUIPPED.trigger(serverPlayer, currentStack, slotReference, true);
                            }
                            if (!lastStack.isEmpty()) {
                                ACCESSORY_UNEQUIPPED.trigger(serverPlayer, lastStack, slotReference, true);
                            }
                        }
                    }
                }
            }

            if (entity.getWorld().isClient()) return;

            AttributeUtils.removeTransientAttributeModifiers(entity, removedAttributesBuilder);
            AttributeUtils.addTransientAttributeModifiers(entity, addedAttributesBuilder);

            //--

            var updatedContainers = ((AccessoriesCapabilityImpl) capability).getUpdatingInventories();

            capability.updateContainers();

            ContainersChangeCallback.EVENT.invoker().onChange(entity, capability, ImmutableMap.copyOf(updatedContainers));

            if (!dirtyStacks.isEmpty() || !dirtyCosmeticStacks.isEmpty() || !updatedContainers.isEmpty()) {
                var packet = SyncContainerData.of(entity, updatedContainers.keySet(), dirtyStacks, dirtyCosmeticStacks);

                AccessoriesNetworking.sendToTrackingAndSelf(entity, packet);
            }

            updatedContainers.clear();
        }

        //--

        var holder = ((AccessoriesHolderImpl) AccessoriesInternals.getHolder(entity));

        // Fix for holder data not being loaded so invalid stacks can be collected
        if (holder.loadedFromTag && capability == null) {
            var tempCapability = new AccessoriesCapabilityImpl(entity);
        }

        var invalidStacks = (holder).invalidStacks;

        if (!invalidStacks.isEmpty()) {
            for (ItemStack invalidStack : invalidStacks) {
                if (entity instanceof ServerPlayerEntity serverPlayer) {
                    AccessoriesInternals.giveItemToPlayer(serverPlayer, invalidStack);
                } else {
                    entity.dropStack(invalidStack);
                }
            }

            invalidStacks.clear();
        }
    }

    private static void recursiveStackChange(SlotReference slotReference, @Nullable AccessoryNestContainerContents lastNestData, @Nullable AccessoryNestContainerContents currentNestData) {
        var currentNestChanges = (currentNestData != null)
                ? currentNestData.slotChanges()
                : new HashMap<Integer, SlotStateChange>();

        var lastInnerStacks = lastNestData != null ? List.copyOf(lastNestData.getMap(slotReference).entrySet()) : List.<Map.Entry<SlotEntryReference, Accessory>>of();
        var currentInnerStacks = currentNestData != null ? List.copyOf(currentNestData.getMap(slotReference).entrySet()) : List.<Map.Entry<SlotEntryReference, Accessory>>of();

        var maxIterationLength = Math.max(lastInnerStacks.size(), currentInnerStacks.size());

        for (int i = 0; i < maxIterationLength; i++) {
            var lastInnerEntry = (i < lastInnerStacks.size()) ? lastInnerStacks.get(i) : null;
            var currentInnerEntry = (i < currentInnerStacks.size()) ? currentInnerStacks.get(i) : null;

            var changeType = currentNestChanges.getOrDefault(i, SlotStateChange.REPLACEMENT);

            if (lastInnerEntry == null && currentInnerEntry != null) {
                var currentRef = currentInnerEntry.getKey();
                var currentInnerStack = currentRef.stack();

                onStackChange(currentRef.reference(), ItemStack.EMPTY, currentRef.stack(), changeType);

                recursiveStackChange(slotReference, null, AccessoryNestUtils.getData(currentInnerStack));
            } else if (currentInnerEntry == null && lastInnerEntry != null) {
                var lastRef = lastInnerEntry.getKey();
                var lastInnerStack = lastRef.stack();

                onStackChange(lastRef.reference(), lastRef.stack(), ItemStack.EMPTY, changeType);

                recursiveStackChange(slotReference, AccessoryNestUtils.getData(lastInnerStack), null);
            } else if (lastInnerEntry != null && currentInnerEntry != null) {
                var currentRef = currentInnerEntry.getKey();
                var lastRef = lastInnerEntry.getKey();

                var innerRef = lastRef.reference();

                var currentInnerStack = currentRef.stack();
                var lastInnerStack = lastRef.stack();

                onStackChange(innerRef, lastInnerStack, currentInnerStack, changeType);

                recursiveStackChange(slotReference, AccessoryNestUtils.getData(lastInnerStack), AccessoryNestUtils.getData(currentInnerStack));
            }
        }

        currentNestChanges.clear();
    }

    private static void onStackChange(SlotReference slotReference, ItemStack lastStack, ItemStack currentStack, SlotStateChange stateChange) {
        if (slotReference.entity() instanceof ServerPlayerEntity serverPlayer) {
            if (!currentStack.isEmpty()) {
                ACCESSORY_EQUIPPED.trigger(serverPlayer, currentStack, slotReference, false);
            }

            if (!lastStack.isEmpty()) {
                ACCESSORY_UNEQUIPPED.trigger(serverPlayer, lastStack, slotReference, false);
            }
        }

        AccessoryChangeCallback.EVENT.invoker().onChange(lastStack, currentStack, slotReference, stateChange);
    }

    public static void getTooltipData(@Nullable LivingEntity entity, ItemStack stack, List<Text> tooltip, Item.TooltipContext tooltipContext, TooltipType tooltipType) {
        var accessory = AccessoriesAPI.getOrDefaultAccessory(stack);

        if (accessory != null) {
            if (entity != null && AccessoriesCapability.get(entity) != null)
                addEntityBasedTooltipData(entity, accessory, stack, tooltip, tooltipContext, tooltipType);

            accessory.getExtraTooltip(stack, tooltip, tooltipContext, tooltipType);
        }
    }

    // TODO: Rewrite for better handling of various odd cases
    private static void addEntityBasedTooltipData(LivingEntity entity, Accessory accessory, ItemStack stack, List<Text> tooltip, Item.TooltipContext tooltipContext, TooltipType tooltipType) {
        // TODO: MAYBE DEPENDING ON ENTITY OR SOMETHING SHOW ALL VALID SLOTS BUT COLOR CODE THEM IF NOT VALID FOR ENTITY?
        // TODO: ADD BETTER HANDLING FOR POSSIBLE SLOTS THAT ARE EQUIPABLE IN BUT IS AT ZERO SIZE
        var validSlotTypes = new HashSet<>(AccessoriesAPI.getValidSlotTypes(entity, stack));

        if (validSlotTypes.isEmpty()) return;

        {
            final var validUniqueSlots = new HashSet<SlotType>();

            validSlotTypes.removeIf(slotType -> {
                var isUnique = UniqueSlotHandling.isUniqueSlot(slotType.name());

                if(isUnique) validUniqueSlots.add(slotType);

                return isUnique;
            });

            var sharedSlotTypes = SlotTypeLoader.getSlotTypes(entity.getWorld()).values()
                    .stream()
                    .filter(slotType -> !UniqueSlotHandling.isUniqueSlot(slotType.name()))
                    .collect(Collectors.toSet());

            var slotInfoComponent = Text.literal("");

            var slotsComponent = Text.literal("");
            boolean allSlots = false;

            if (validSlotTypes.containsAll(sharedSlotTypes)) {
                slotsComponent.append(Text.translatable(Accessories.translationKey("slot.any")));
                allSlots = true;
            } else {
                var entitySlotTypes = Set.copyOf(EntitySlotLoader.getEntitySlots(entity).values());

                var invalidSlotsTypes = Sets.difference(entitySlotTypes, validSlotTypes);

                if (invalidSlotsTypes.size() < validSlotTypes.size()) {
                    slotsComponent.append(Text.translatable(Accessories.translationKey("slot.any")));
                    slotsComponent.append(Text.translatable(Accessories.translationKey("slot.except")).formatted(Formatting.GRAY));

                    var invalidSlotsItr = invalidSlotsTypes.iterator();

                    while(invalidSlotsItr.hasNext()) {
                        var type = invalidSlotsItr.next();

                        if (ExtraSlotTypeProperties.getProperty(type.name(), entity.getWorld().isClient()).allowTooltipInfo()) {
                            slotsComponent.append(Text.translatable(type.translation()).formatted(Formatting.RED));

                            if (invalidSlotsItr.hasNext()) {
                                slotsComponent.append(Text.literal(", ").formatted(Formatting.GRAY));
                            }
                        }
                    }
                } else {
                    var validSlotsItr = validSlotTypes.iterator();

                    while(validSlotsItr.hasNext()) {
                        var type = validSlotsItr.next();

                        if (ExtraSlotTypeProperties.getProperty(type.name(), entity.getWorld().isClient()).allowTooltipInfo()) {
                            slotsComponent.append(Text.translatable(type.translation()));

                            if (validSlotsItr.hasNext()) {
                                slotsComponent.append(Text.literal(", ").formatted(Formatting.GRAY));
                            }
                        }
                    }
                }
            }

            validSlotTypes.addAll (validUniqueSlots);

            final var filteredValidUniqueSlots = validUniqueSlots.stream()
                    .filter(slotType -> ExtraSlotTypeProperties.getProperty(slotType.name(), true).allowTooltipInfo())
                    .toList();

            if (!filteredValidUniqueSlots.isEmpty()) {
                var uniqueItr = filteredValidUniqueSlots.iterator();

                while(uniqueItr.hasNext()) {
                    var type = uniqueItr.next();

                    slotsComponent.append(Text.translatable(type.translation()));

                    if(uniqueItr.hasNext()) {
                        slotsComponent.append(Text.literal(", ").formatted(Formatting.GRAY));
                    }
                }
            }

            if(!slotsComponent.getSiblings().isEmpty()) {
                var slotTranslationKey = "slot.tooltip." + ((validSlotTypes.size() > 1 && !allSlots) ? "plural" : "singular");

                slotInfoComponent.append(
                        Text.translatable(Accessories.translationKey(slotTranslationKey))
                                .formatted(Formatting.GRAY)
                                .append(slotsComponent.formatted(Formatting.BLUE))
                );

                tooltip.add(slotInfoComponent);
            }
        }

        var slotSpecificModifiers = new HashMap<SlotType, AccessoryAttributeBuilder>();
        AccessoryAttributeBuilder defaultModifiers = null;

        boolean allDuplicates = true;

        for (var slotType : validSlotTypes) {
            var reference = SlotReference.of(entity, slotType.name(), 0);

            var builder = AccessoriesAPI.getAttributeModifiers(stack, reference, true);

            slotSpecificModifiers.put(slotType, builder);

            if (defaultModifiers == null) {
                defaultModifiers = builder;
            } else if (allDuplicates) {
                // TODO: ! WARNING ! THIS MAY NOT WORK?
                allDuplicates = defaultModifiers.equals(builder);
            }
        }

        var slotTypeToTooltipInfo = new HashMap<SlotType, List<Text>>();

        if (allDuplicates) {
            if (!defaultModifiers.isEmpty()) {
                var attributeTooltip = new ArrayList<Text>();

                addAttributeTooltip(entity, stack, defaultModifiers.getAttributeModifiers(false), attributeTooltip, tooltipContext, tooltipType);

                slotTypeToTooltipInfo.put(null, attributeTooltip);
            }
        } else {
            for (var slotModifiers : slotSpecificModifiers.entrySet()) {
                var slotType = slotModifiers.getKey();
                var modifiers = slotModifiers.getValue();

                if (modifiers.isEmpty()) continue;

                var attributeTooltip = new ArrayList<Text>();

                addAttributeTooltip(entity, stack, modifiers.getAttributeModifiers(false), attributeTooltip, tooltipContext, tooltipType);

                slotTypeToTooltipInfo.put(slotType, attributeTooltip);
            }
        }

        var extraAttributeTooltips = new HashMap<SlotType, List<Text>>();
        List<Text> defaultExtraAttributeTooltip = null;

        boolean allDuplicatesExtras = true;

        for (var slotType : validSlotTypes) {
            var extraAttributeTooltip = new ArrayList<Text>();
            accessory.getAttributesTooltip(stack, slotType, extraAttributeTooltip, tooltipContext, tooltipType);

            extraAttributeTooltips.put(slotType, extraAttributeTooltip);

            if (defaultExtraAttributeTooltip == null) {
                defaultExtraAttributeTooltip = extraAttributeTooltip;
            } else if (allDuplicatesExtras) {
                allDuplicatesExtras = extraAttributeTooltip.equals(defaultExtraAttributeTooltip);
            }
        }

        if (allDuplicatesExtras) {
            slotTypeToTooltipInfo.computeIfAbsent(null, s -> new ArrayList<>())
                    .addAll(defaultExtraAttributeTooltip);
        } else {
            extraAttributeTooltips.forEach((slotType, components) -> {
                slotTypeToTooltipInfo.computeIfAbsent(slotType, s -> new ArrayList<>())
                        .addAll(components);
            });
        }

        if (slotTypeToTooltipInfo.containsKey(null)) {
            var anyTooltipInfo = slotTypeToTooltipInfo.get(null);

            if (anyTooltipInfo.size() > 0) {
                tooltip.add(ScreenTexts.EMPTY);

                tooltip.add(
                        Text.translatable(Accessories.translationKey("tooltip.attributes.any"))
                                .formatted(Formatting.GRAY)
                );

                tooltip.addAll(anyTooltipInfo);
            }

            slotTypeToTooltipInfo.remove(null);
        }

        if (!slotTypeToTooltipInfo.isEmpty()) {
            for (var entry : slotTypeToTooltipInfo.entrySet()) {
                var tooltipData = entry.getValue();

                if (tooltipData.size() == 0) continue;

                tooltip.add(ScreenTexts.EMPTY);

                tooltip.add(
                        Text.translatable(
                                Accessories.translationKey("tooltip.attributes.slot"),
                                Text.translatable(entry.getKey().translation()).formatted(Formatting.BLUE)
                        ).formatted(Formatting.GRAY)
                );

                tooltip.addAll(entry.getValue());
            }
        }
    }

    private static void addAttributeTooltip(LivingEntity entity, ItemStack stack, Multimap<RegistryEntry<EntityAttribute>, EntityAttributeModifier> multimap, List<Text> tooltip, Item.TooltipContext context, TooltipType flag) {
        if (multimap.isEmpty()) return;

        AccessoriesInternals.addAttributeTooltips((entity instanceof PlayerEntity player ? player : null), stack, multimap, tooltip::add, context, flag);
    }

    @Nullable
    public static Collection<ItemStack> onDeath(LivingEntity entity, DamageSource source) {
        var capability = AccessoriesCapability.get(entity);

        if (capability == null) return List.of();

        var droppedStacks = new ArrayList<ItemStack>();

        var gamerules = entity.getWorld().getGameRules();

        var keepInv = gamerules.get(GameRules.KEEP_INVENTORY).get() || gamerules.get(Accessories.RULE_KEEP_ACCESSORY_INVENTORY).get();

        for (var containerEntry : ((AccessoriesHolderImpl) capability.getHolder()).getAllSlotContainers().entrySet()) {
            var slotType = containerEntry.getValue().slotType();

            var slotDropRule = slotType != null ? slotType.dropRule() : DropRule.DEFAULT;

            var container = containerEntry.getValue();

            var stacks = container.getAccessories();
            var cosmeticStacks = container.getCosmeticAccessories();

            for (int i = 0; i < container.getSize(); i++) {
                var reference = SlotReference.of(entity, container.getSlotName(), i);

                var stack = dropStack(slotDropRule, entity, stacks, reference, source, keepInv);
                if (stack != null) droppedStacks.add(stack);

                var cosmeticStack = dropStack(slotDropRule, entity, cosmeticStacks, reference, source, keepInv);
                if (cosmeticStack != null) droppedStacks.add(cosmeticStack);
            }
        }

        var result = OnDeathCallback.EVENT.invoker().shouldDrop(TriState.DEFAULT, entity, capability, source, droppedStacks);

        if (!result.orElse(true)) return null;

        return droppedStacks;
    }

    @Nullable
    private static ItemStack dropStack(DropRule dropRule, LivingEntity entity, ExpandedSimpleContainer container, SlotReference reference, DamageSource source, boolean keepInvEnabled) {
        var stack = container.getStack(reference.slot());

        if (stack.isEmpty()) return null;

        var accessory = AccessoriesAPI.getOrDefaultAccessory(stack);

        if (accessory != null && dropRule == DropRule.DEFAULT) {
            dropRule = accessory.getDropRule(stack, reference, source);
        }

        if (accessory instanceof AccessoryNest holdable) {
            var dropRuleToStacks = holdable.getDropRules(stack, reference, source);

            for (int i = 0; i < dropRuleToStacks.size(); i++) {
                var rulePair = dropRuleToStacks.get(i);

                var innerStack = rulePair.right();

                var result = OnDropCallback.getAlternativeRule(rulePair.left(), innerStack, reference, source);

                var breakInnerStack = (result == DropRule.DEFAULT && EnchantmentHelper.hasAnyEnchantmentsWith(innerStack, EnchantmentEffectComponentTypes.PREVENT_EQUIPMENT_DROP))
                        || (result == DropRule.DESTROY);

                if (breakInnerStack) {
                    holdable.setInnerStack(stack, i, ItemStack.EMPTY);
                    // TODO: Do we call break here for the accessory?

                    container.setStack(reference.slot(), stack);
                }
            }
        }

        var result = OnDropCallback.getAlternativeRule(dropRule, stack, reference, source);

        boolean dropStack = true;
        boolean keepingStack = false;

        if (result == DropRule.DESTROY) {
            container.setStack(reference.slot(), ItemStack.EMPTY);
            dropStack = false;
            // TODO: Do we call break here for the accessory?
        } else if (result == DropRule.KEEP) {
            dropStack = false;
            keepingStack = true;
        } else if (result == DropRule.DEFAULT) {
            if (keepInvEnabled) {
                dropStack = false;

                keepingStack = true;
            } else if (EnchantmentHelper.hasAnyEnchantmentsWith(stack, EnchantmentEffectComponentTypes.PREVENT_EQUIPMENT_DROP)) {
                container.setStack(reference.slot(), ItemStack.EMPTY);
                dropStack = false;
                // TODO: Do we call break here for the accessory?
            }
        }

        // Used to indicate within the Accessories system when the player becomes alive that we need to
        // equip the accessory again to trigger equip call and properly add back Attributes
        if (keepingStack) {
            container.setPreviousItem(reference.slot(), ItemStack.EMPTY);
        }

        if (!dropStack) return null;

        container.setStack(reference.slot(), ItemStack.EMPTY);

        return stack;
    }

    public static TypedActionResult<ItemStack> attemptEquipFromUse(PlayerEntity player, Hand hand) {
        var stack = player.getStackInHand(hand);

        var capability = AccessoriesCapability.get(player);

        if (capability != null && !player.isSpectator() && !stack.isEmpty()) {
            var equipControl = capability.getHolder().equipControl();

            var shouldAttemptEquip = false;

            if (equipControl == PlayerEquipControl.MUST_CROUCH && player.isSneaking()) {
                shouldAttemptEquip = true;
            } else if (equipControl == PlayerEquipControl.MUST_NOT_CROUCH && !player.isSneaking()) {
                shouldAttemptEquip = true;
            }

            if (shouldAttemptEquip) {
                var accessory = AccessoriesAPI.getOrDefaultAccessory(stack);

                var equipReference = capability.canEquipAccessory(stack, true);

                if (equipReference != null && accessory.canEquipFromUse(stack)) {
                    accessory.onEquipFromUse(stack, equipReference.left());

                    var newHandStack = stack.copy();

                    var possibleSwappedStack = equipReference.second().equipStack(newHandStack);

                    if (possibleSwappedStack.isPresent()) {
                        var swappedStack = possibleSwappedStack.get();

                        if (newHandStack.isEmpty()) {
                            newHandStack = swappedStack;
                        } else if (ItemStack.areItemsAndComponentsEqual(newHandStack, swappedStack) && (newHandStack.getCount() + swappedStack.getCount()) <= newHandStack.getMaxCount()) {
                            newHandStack.increment(swappedStack.getCount());
                        } else {
                            player.giveItemStack(swappedStack);
                        }
                    }

                    return TypedActionResult.success(newHandStack);
                }
            }
        }

        return TypedActionResult.pass(stack);
    }

    public static ActionResult attemptEquipOnEntity(PlayerEntity player, Hand hand, Entity entity) {
        var stack = player.getStackInHand(hand);

        if (!(entity instanceof LivingEntity targetEntity) || !entity.getType().isIn(AccessoriesTags.EQUIPMENT_MANAGEABLE))
            return ActionResult.PASS;

        var targetCapability = AccessoriesCapability.get(targetEntity);

        var canModify = AllowEntityModificationCallback.EVENT.invoker().allowModifications(targetEntity, player, null).orElse(false);

        if (canModify && targetCapability != null && !player.isSpectator()) {
            if (player.isSneaking()) {
                var accessory = AccessoriesAPI.getOrDefaultAccessory(stack);

                var equipReference = targetCapability.canEquipAccessory(stack, true);

                if (equipReference != null && accessory.canEquipFromUse(stack)) {
                    if (!stack.isEmpty()) accessory.onEquipFromUse(stack, equipReference.left());

                    var newHandStack = stack.copy();

                    var possibleSwappedStack = equipReference.second().equipStack(newHandStack);

                    if (possibleSwappedStack.isPresent()) {
                        var swappedStack = possibleSwappedStack.get();

                        if (newHandStack.isEmpty()) {
                            newHandStack = swappedStack;
                        } else if (ItemStack.areItemsAndComponentsEqual(newHandStack, swappedStack) && (newHandStack.getCount() + swappedStack.getCount()) <= newHandStack.getMaxCount()) {
                            newHandStack.increment(swappedStack.getCount());
                        } else {
                            player.giveItemStack(swappedStack);
                        }
                    }

                    player.setStackInHand(hand, newHandStack);

                    return ActionResult.SUCCESS;
                }
            }
        }

        return ActionResult.PASS;
    }

    public static void setupItems(AddDataComponentCallback callback) {
        AccessoriesAPI.getAllAccessories().forEach((item, accessory) -> {
            var builder = AccessoryItemAttributeModifiers.builder();

            accessory.getStaticModifiers(item, builder);

            if (!builder.isEmpty()) {
                callback.addTo(item, AccessoriesDataComponents.ATTRIBUTES, builder.build());
            }
        });
    }

    public interface AddDataComponentCallback {
        <T> void addTo(Item item, ComponentType<T> componentType, T component);
    }
}
