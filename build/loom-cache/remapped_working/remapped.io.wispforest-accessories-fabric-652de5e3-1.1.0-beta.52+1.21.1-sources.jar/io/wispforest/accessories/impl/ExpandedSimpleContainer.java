package io.wispforest.accessories.impl;

import Z;
import com.mojang.datafixers.util.Pair;
import com.mojang.logging.LogUtils;
import io.wispforest.accessories.api.AccessoriesAPI;
import io.wispforest.accessories.api.AccessoriesCapability;
import io.wispforest.accessories.api.Accessory;
import io.wispforest.accessories.api.components.AccessoriesDataComponents;
import io.wispforest.accessories.impl.caching.AccessoriesHolderLookupCache;
import io.wispforest.accessories.utils.ItemStackMutation;
import io.wispforest.owo.util.EventSource;
import io.wispforest.owo.util.EventSource.Subscription;
import it.unimi.dsi.fastutil.ints.Int2BooleanArrayMap;
import it.unimi.dsi.fastutil.ints.Int2BooleanMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtList;
import net.minecraft.nbt.NbtOps;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.util.collection.DefaultedList;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * An implementation of SimpleContainer with easy utilities for iterating over the stacks
 * and holding on to previous stack info
 */
public class ExpandedSimpleContainer extends SimpleInventory implements Iterable<Pair<Integer, ItemStack>> {

    private static final Logger LOGGER = LogUtils.getLogger();

    private final AccessoriesContainerImpl container;

    private final String name;
    private final DefaultedList<ItemStack> previousItems;
    private final Int2BooleanMap setFlags = new Int2BooleanArrayMap();

    private boolean newlyConstructed;

    private final Int2ObjectMap<EventSource<ItemStackMutation>.Subscription> currentSubscriptions = new Int2ObjectOpenHashMap<>();

    public ExpandedSimpleContainer(AccessoriesContainerImpl container, int size, String name) {
        this(container, size, name, true);
    }

    public ExpandedSimpleContainer(AccessoriesContainerImpl container, int size, String name, boolean toggleNewlyConstructed) {
        super(size);

        this.container = container;

        this.addListener(container);

        if(toggleNewlyConstructed) this.newlyConstructed = true;

        this.name = name;
        this.previousItems = DefaultedList.ofSize(size, ItemStack.EMPTY);
    }

    public String name() {
        return this.name;
    }

    //--

    public boolean wasNewlyConstructed() {
        var bl = newlyConstructed;

        this.newlyConstructed = false;

        return bl;
    }

    public boolean isSlotFlagged(int slot){
        var bl = setFlags.getOrDefault(slot, false);

        if(bl) setFlags.put(slot, false);

        return bl;
    }

    public void setPreviousItem(int slot, ItemStack stack) {
        if(slot >= 0 && slot < this.previousItems.size()) {
            this.previousItems.set(slot, stack);
            if (!stack.isEmpty() && stack.getCount() > this.getMaxCountPerStack()) {
                stack.setCount(this.getMaxCountPerStack());
            }
        }
    }

    public ItemStack getPreviousItem(int slot) {
        return slot >= 0 && slot < this.previousItems.size()
                ? this.previousItems.get(slot)
                : ItemStack.EMPTY;
    }

    //--

    @Override
    public int getMaxCount(ItemStack itemStack) {
        var accessory = AccessoriesAPI.getOrDefaultAccessory(itemStack);

        return Math.min(super.getMaxCount(itemStack), accessory.maxStackSize(itemStack));
    }

    @Override
    public ItemStack getStack(int slot) {
        if(!validIndex(slot)) return ItemStack.EMPTY;

        return super.getStack(slot);
    }

    @Override
    public ItemStack removeStack(int slot, int amount) {
        if(!validIndex(slot)) return ItemStack.EMPTY;

        var stack = super.removeStack(slot, amount);

        if (!stack.isEmpty()) {
            this.setFlags.put(slot, true);

            var prevStack = this.getStack(slot);

            if (prevStack.isEmpty()) {
                var subscription = this.currentSubscriptions.remove(slot);

                if (subscription != null) subscription.cancel();
            }
        }

        return stack;
    }

    @Override
    public ItemStack removeStack(int slot) {
        if(!validIndex(slot)) return ItemStack.EMPTY;

        // TODO: Concerning the flagging system, should this work for it?

        var subscription = this.currentSubscriptions.remove(slot);

        if (subscription != null) subscription.cancel();

        return super.removeStack(slot);
    }

    @Override
    public void setStack(int slot, ItemStack stack) {
        if(!validIndex(slot)) return;

        var subscription = this.currentSubscriptions.remove(slot);

        if (subscription != null) subscription.cancel();

        super.setStack(slot, stack);

        if (!stack.isEmpty()) {
            this.currentSubscriptions.put(slot,
                    ItemStackMutation.getEvent(stack).source().subscribe((stack1, types) -> {
                        if (types.contains(AccessoriesDataComponents.ATTRIBUTES) || types.contains(AccessoriesDataComponents.NESTED_ACCESSORIES)) {
                            this.markDirty();
                        }

                        if (!this.container.capability.entity().getWorld().isClient()) {
                            var cache = ((AccessoriesHolderImpl) this.container.capability.getHolder()).getLookupCache();

                            if (cache != null) cache.invalidateLookupData(this.container.getSlotName(), stack1, types);
                        }
                    })
            );
        }

        setFlags.put(slot, true);
    }

    // Simple validation method to make sure that the given access is valid before attempting an operation
    public boolean validIndex(int slot){
        var isValid = slot >= 0 && slot < this.size();

        var nameInfo = (this.name != null ? "Container: " + this.name + ", " : "");

        if(!isValid && FabricLoader.getInstance().isDevelopmentEnvironment()){
            try {
                throw new IllegalStateException("Access to a given Inventory was found to be out of the range valid for the container! [Name: " + nameInfo + " Index: " + slot + "]");
            } catch (Exception e) {
                LOGGER.debug("Full Exception: ", e);
            }
        }

        return isValid;
    }

    //--

    @Override
    public void readNbtList(NbtList containerNbt, RegistryWrapper.WrapperLookup provider) {
        this.container.containerListenerLock = true;

        var capability = this.container.capability;

        var prevStacks = new ArrayList<ItemStack>();
        for(int i = 0; i < this.size(); ++i) {
            var currentStack = this.getStack(i);

            prevStacks.add(currentStack);

            this.setStack(i, ItemStack.EMPTY);
        }

        var invalidStacks = new ArrayList<ItemStack>();
        var decodedStacks = new ArrayList<ItemStack>();

        for(int i = 0; i < containerNbt.size(); ++i) {
            var compoundTag = containerNbt.getCompound(i);

            int j = compoundTag.getInt("Slot");

            var stack = parseOptional(provider, compoundTag);

            decodedStacks.add(stack);

            if (j >= 0 && j < this.size()) {
                this.setStack(j, stack);
            } else {
                invalidStacks.add(stack);
            }
        }

        this.container.containerListenerLock = false;

        if (!capability.entity().getWorld().isClient()) {
            if (!prevStacks.equals(decodedStacks)) {
                this.markDirty();
            }

            ((AccessoriesHolderImpl) capability.getHolder()).invalidStacks.addAll(invalidStacks);
        }
    }

    public ItemStack parseOptional(RegistryWrapper.WrapperLookup lookupProvider, NbtElement tag) {
        return ItemStack.CODEC.parse(lookupProvider.getOps(NbtOps.INSTANCE), tag)
                .resultOrPartial(string -> {
                    LOGGER.error("[ExpandedSimpleContainer] An error has occured while decoding stack!");
                    LOGGER.error(" - Entity Effected: '{}'", this.container.capability.entity().toString());
                    LOGGER.error(" - Container Name: '{}'", this.container.getSlotName());
                    LOGGER.error(" - Tried to load invalid item: '{}'", string);
                    LOGGER.error(" - Stack Data: '{}'", tag.toString());
                })
                .orElse(ItemStack.EMPTY);
    }

    @Override
    public NbtList toNbtList(RegistryWrapper.WrapperLookup provider) {
        NbtList listTag = new NbtList();

        for(int i = 0; i < this.size(); ++i) {
            ItemStack itemStack = this.getStack(i);

            if (!itemStack.isEmpty()) {
                var compoundTag = new NbtCompound();

                compoundTag.putInt("Slot", i);

                listTag.add(itemStack.encode(provider, compoundTag));
            }
        }

        return listTag;
    }

    //--

    @NotNull
    @Override
    public Iterator<Pair<Integer, ItemStack>> iterator() {
        return new Iterator<>() {
            private int index = 0;

            @Override
            public boolean hasNext() {
                return index < ExpandedSimpleContainer.this.size();
            }

            @Override
            public Pair<Integer, ItemStack> next() {
                var pair = new Pair<>(index, ExpandedSimpleContainer.this.getStack(index));

                index++;

                return pair;
            }
        };
    }

    public void setFromPrev(ExpandedSimpleContainer prevContainer) {
        prevContainer.forEach(pair -> this.setPreviousItem(pair.getFirst(), pair.getSecond()));
    }

    public void copyPrev(ExpandedSimpleContainer prevContainer) {
        for (int i = 0; i < prevContainer.size(); i++) {
            if(i >= this.size()) continue;

            var prevItem = prevContainer.getPreviousItem(i);

            if(!prevItem.isEmpty()) this.setPreviousItem(i, prevItem);
        }
    }
}
