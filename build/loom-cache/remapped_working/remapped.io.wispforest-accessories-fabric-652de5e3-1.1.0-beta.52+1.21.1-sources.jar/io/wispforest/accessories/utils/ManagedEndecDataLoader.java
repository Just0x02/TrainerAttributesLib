package io.wispforest.accessories.utils;

import com.google.common.collect.BiMap;
import com.google.common.collect.HashBiMap;
import com.google.gson.JsonElement;
import io.wispforest.accessories.AccessoriesInternals;
import io.wispforest.accessories.mixin.ConfigurableRegistryLookupAccessor;
import io.wispforest.endec.Endec;
import io.wispforest.endec.SerializationContext;
import io.wispforest.endec.StructEndec;
import io.wispforest.endec.impl.StructEndecBuilder;
import io.wispforest.owo.network.ClientAccess;
import io.wispforest.owo.network.OwoNetChannel;
import io.wispforest.owo.serialization.RegistriesAttribute;
import io.wispforest.owo.serialization.endec.MinecraftEndecs;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.UnaryOperator;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.resource.ResourceManager;
import net.minecraft.server.DataPackContents;
import net.minecraft.util.Identifier;
import net.minecraft.util.profiler.Profiler;
import net.minecraft.world.World;

public class ManagedEndecDataLoader<T> extends EndecDataLoader<T>  {

    private static final Map<Identifier, ManagedEndecDataLoader<?>> ALL_DATA_LOADERS = new LinkedHashMap<>();

    private final BiMap<Identifier, T> server = HashBiMap.create();
    private final BiMap<Identifier, T> client = HashBiMap.create();

    private final Endec<BiMap<Identifier, T>> mapEndec;

    private BiConsumer<Identifier, T> handleEntry = (location, t) -> {};

    protected ManagedEndecDataLoader(Identifier id, String type, Endec<T> endec) {
        super(SerializationContext.empty(), id, type, endec);

        this.mapEndec = biMapEndec(Identifier::toString, Identifier::tryParse, endec);

        ALL_DATA_LOADERS.put(id, this);

        AccessoriesInternals.registerLoader(this, this::setupOps);
    }

    public static <T> ManagedEndecDataLoader<T> of(Identifier id, String type, Endec<T> endec) {
        return of(id, type, endec);
    }

    public ManagedEndecDataLoader<T> onEntryAdd(BiConsumer<Identifier, T> value) {
        this.handleEntry = value;

        return this;
    }

    @Nullable
    public static <T> ManagedEndecDataLoader<T> getLoader(Identifier id) {
        return (ManagedEndecDataLoader<T>) ALL_DATA_LOADERS.get(id);
    }

    @Override
    protected void handleRawEntry(Identifier id, T t) {
        handleEntry.accept(id, t);

        server.put(id, t);
    }

    public Endec<BiMap<Identifier, T>> mapEndec() {
        return this.mapEndec;
    }

    private void handleUnsafeSync(BiMap<Identifier, ?> map) {
        this.client.clear();
        this.client.putAll((Map<? extends Identifier, ? extends T>) map);

        this.onSync();
    }

    protected void onSync() {}

    public Map<Identifier, T> getEntries(World level) {
        return getEntries(level.isClient());
    }

    public Map<Identifier, T> getEntries(boolean isClientSide) {
        return Collections.unmodifiableMap(isClientSide ? client : server);
    }

    @Nullable
    public T getEntry(Identifier id, World level) {
        return getEntry(id, level.isClient());
    }

    @Nullable
    public T getEntry(Identifier id, boolean isClientSide) {
        return (isClientSide ? client : server).get(id);
    }

    public Identifier getId(T t, World level) {
        return getId(t, level.isClient());
    }

    public Identifier getId(T t, boolean isClientSide) {
        return (isClientSide ? client : server).inverse().get(t);
    }

    //--


    @Override
    protected void apply(Map<Identifier, JsonElement> loadedObjects, ResourceManager resourceManager, Profiler profiler) {
        this.server.clear();

        super.apply(loadedObjects, resourceManager, profiler);
    }

    @ApiStatus.Internal
    private ManagedEndecDataLoader<T> setupOps(RegistryWrapper.WrapperLookup registries) {
        if (registries instanceof DataPackContents.ConfigurableWrapperLookup lookup) {
            this.context = context.withAttributes(RegistriesAttribute.of(((ConfigurableRegistryLookupAccessor) lookup).getRegistryAccess()));
        } else {
            this.context = context.withAttributes(RegistriesAttribute.of((DynamicRegistryManager) registries));
        }

        return this;
    }

    @Override
    @ApiStatus.Internal
    protected Map<Identifier, JsonElement> prepare(ResourceManager resourceManager, Profiler profiler) {
        if (!this.context.hasAttribute(RegistriesAttribute.REGISTRIES)) {
            throw new IllegalStateException("Unable to prepare files as the given Registry access has not been setup on the server! [Id: " + this.getLoaderId() + "]");
        }

        return super.prepare(resourceManager, profiler);
    }

    @ApiStatus.Internal
    private static <K, V> Endec<BiMap<K, V>> biMapEndec(Function<K, String> keyToString, Function<String, K> stringToKey, Endec<V> valueEndec) {
        return Endec.of((ctx, serializer, map) -> {
            try (var mapState = serializer.map(ctx, valueEndec, map.size())) {
                map.forEach((k, v) -> mapState.entry(keyToString.apply(k), v));
            }
        }, (ctx, deserializer) -> {
            var mapState = deserializer.map(ctx, valueEndec);

            var map = HashBiMap.<K, V>create(mapState.estimatedSize());
            mapState.forEachRemaining(entry -> map.put(stringToKey.apply(entry.getKey()), entry.getValue()));

            return map;
        });
    }

    @ApiStatus.Internal
    public static void init(OwoNetChannel channel, Consumer<Consumer<PlayerEntity>> hookRegistration) {
        channel.registerClientboundDeferred(SyncAllLoaderDataPacket.class, SyncAllLoaderDataPacket.ENDEC);

        hookRegistration.accept(player -> {
            var packets = ALL_DATA_LOADERS.values().stream()
                    .map(dataLoader -> new SyncLoaderDataPacket(dataLoader.id, (BiMap<Identifier, Object>) dataLoader.server))
                    .toList();

            channel.serverHandle(player).send(new SyncAllLoaderDataPacket(packets));
        });
    }

    @ApiStatus.Internal
    public static void initClient(OwoNetChannel channel) {
        channel.registerClientbound(SyncAllLoaderDataPacket.class, SyncAllLoaderDataPacket.ENDEC, SyncAllLoaderDataPacket::handle);
    }

    @ApiStatus.Internal
    private record SyncAllLoaderDataPacket(List<SyncLoaderDataPacket> packets) {
        private static final StructEndec<SyncAllLoaderDataPacket> ENDEC = StructEndecBuilder.of(
                SyncLoaderDataPacket.ENDEC.listOf().fieldOf("packets", SyncAllLoaderDataPacket::packets),
                SyncAllLoaderDataPacket::new
        );

        private static void handle(SyncAllLoaderDataPacket packet, ClientAccess access) {
            for (var innerPacket : packet.packets()) {
                SyncLoaderDataPacket.handle(innerPacket, access);
            }
        }
    }

    @ApiStatus.Internal
    private record SyncLoaderDataPacket(Identifier id, BiMap<Identifier, Object> data) {
        private static final Map<Identifier, StructEndec<SyncLoaderDataPacket>> CACHED_ENDECS = new HashMap<>();

        private static final StructEndec<SyncLoaderDataPacket> ENDEC = (StructEndec<SyncLoaderDataPacket>) Endec.dispatched(
                id -> {
                    var loader = getLoader(id);

                    if (loader == null) {
                        throw new IllegalStateException("Unable to get following Data Loader to handle the given sync packet: " + id);
                    }

                    return CACHED_ENDECS.computeIfAbsent(id, identifier -> {
                        return StructEndecBuilder.of(
                                MinecraftEndecs.IDENTIFIER.fieldOf("id", SyncLoaderDataPacket::id),
                                loader.mapEndec.fieldOf("data", SyncLoaderDataPacket::data),
                                SyncLoaderDataPacket::new
                        );
                    });
                },
                SyncLoaderDataPacket::id,
                MinecraftEndecs.IDENTIFIER);

        private static void handle(SyncLoaderDataPacket packet, ClientAccess access) {
            getLoader(packet.id()).handleUnsafeSync(packet.data());
        }
    }
}
