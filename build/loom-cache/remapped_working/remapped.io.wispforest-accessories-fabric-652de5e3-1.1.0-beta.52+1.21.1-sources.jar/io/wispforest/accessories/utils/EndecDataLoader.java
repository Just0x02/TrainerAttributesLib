package io.wispforest.accessories.utils;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.mojang.logging.LogUtils;
import io.wispforest.endec.Endec;
import io.wispforest.endec.SerializationContext;
import io.wispforest.endec.format.gson.GsonDeserializer;
import io.wispforest.owo.serialization.RegistriesAttribute;
import org.slf4j.Logger;

import java.util.Map;
import java.util.Map.Entry;
import java.util.function.BiConsumer;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.resource.JsonDataLoader;
import net.minecraft.util.Identifier;
import net.minecraft.util.profiler.Profiler;


// TODO: 1.21.4 ADJUSTMENTS SHOULD BE MADE TO USE LESS DIRECT CODE ANYWAYS
public abstract class EndecDataLoader<T> extends JsonDataLoader {

    private static final Logger LOGGER = LogUtils.getLogger();

    protected static final Gson GSON = new GsonBuilder().setLenient().setPrettyPrinting().create();

    protected final String type;

    protected final Identifier id;
    protected final Endec<T> endec;

    protected SerializationContext context;

    protected EndecDataLoader(SerializationContext context, Identifier id, String type, Endec<T> endec) {
        super(GSON, type);

        this.type = type;

        this.id = id;

        this.context = context;
        this.endec = endec;
    }

    public static <T> EndecDataLoader<T> client(Identifier id, String type, Endec<T> endec, BiConsumer<Identifier, T> handleEntry) {
        return new EndecDataLoader<T>(SerializationContext.empty(), id, type, endec) {
            @Override public void handleRawEntry(Identifier identifier, T t) { handleEntry.accept(identifier, t); }
        };
    }

    public static <T> EndecDataLoader<T> server(RegistryWrapper.WrapperLookup registries, Identifier id, String type, Endec<T> endec, BiConsumer<Identifier, T> handleEntry) {
        return new EndecDataLoader<T>(SerializationContext.attributes(RegistriesAttribute.of((DynamicRegistryManager) registries)), id, type, endec) {
            @Override public void handleRawEntry(Identifier identifier, T t) { handleEntry.accept(identifier, t); }
        };
    }

    protected abstract void handleRawEntry(Identifier identifier, T t);

    @Override
    protected void apply(Map<Identifier, JsonElement> loadedObjects, net.minecraft.resource.ResourceManager resourceManager, Profiler profiler) {
        for (var entry : loadedObjects.entrySet()) {
            var location = entry.getKey();

            try {
                var t = this.endec.decodeFully(this.context, GsonDeserializer::of, entry.getValue());

                this.handleRawEntry(location, t);
            } catch (Exception e) {
                LOGGER.error("[EndecDataLoader: {}] An issue has occurred with attempting to decode the following entry: {}", this.getLoaderId(), location, e);
            }
        }
    }

    public Identifier getLoaderId() {
        return id;
    }
}
