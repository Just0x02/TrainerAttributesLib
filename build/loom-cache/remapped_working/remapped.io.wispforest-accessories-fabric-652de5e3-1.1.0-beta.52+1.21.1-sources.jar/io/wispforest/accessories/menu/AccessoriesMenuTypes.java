package io.wispforest.accessories.menu;

import io.wispforest.accessories.Accessories;
import io.wispforest.accessories.AccessoriesInternals;
import io.wispforest.accessories.client.gui.AccessoriesExperimentalScreen;
import io.wispforest.accessories.client.gui.AccessoriesScreen;
import io.wispforest.accessories.menu.variants.AccessoriesExperimentalMenu;
import io.wispforest.accessories.menu.variants.AccessoriesMenu;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.HandledScreens;
import net.minecraft.client.gui.screen.ingame.ScreenHandlerProvider;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import org.apache.commons.lang3.function.TriFunction;

public class AccessoriesMenuTypes {

    public static ScreenHandlerType<AccessoriesMenu> ORIGINAL_MENU;
    public static ScreenHandlerType<AccessoriesExperimentalMenu> EXPERIMENTAL_MENU;

    public static void registerMenuType() {
        ORIGINAL_MENU = registerMenuType("original_menu", AccessoriesMenu::of);
        EXPERIMENTAL_MENU = registerMenuType("experimental_menu", AccessoriesExperimentalMenu::of);
    }

    private static <T extends ScreenHandler> ScreenHandlerType<T> registerMenuType(String path, TriFunction<Integer, PlayerInventory, AccessoriesMenuData, T> func) {
        return AccessoriesInternals.registerMenuType(Accessories.of(path), AccessoriesMenuData.ENDEC, func);
    }

    @Environment(EnvType.CLIENT)
    public static <M extends ScreenHandler, U extends Screen & ScreenHandlerProvider<M>> void registerClientMenuConstructors(MenuRegisterCallback callback) {
        callback.register(AccessoriesMenuTypes.ORIGINAL_MENU, AccessoriesScreen::new);
        callback.register(AccessoriesMenuTypes.EXPERIMENTAL_MENU, AccessoriesExperimentalScreen::new);
    }

    public interface MenuRegisterCallback {
        <M extends ScreenHandler, U extends Screen & ScreenHandlerProvider<M>> void register(ScreenHandlerType<? extends M> type, HandledScreens.Provider<M, U> factory);
    }
}
