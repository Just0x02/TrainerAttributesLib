package io.wispforest.accessories.menu;

import I;
import io.wispforest.accessories.pond.ItemBasedSteerable;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.passive.AbstractHorseEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.Inventory;
import net.minecraft.inventory.StackReference;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import org.jetbrains.annotations.Nullable;

public final class SlotAccessContainer implements Inventory {

    private final StackReference slotAccess;

    public SlotAccessContainer(StackReference slotAccess) {
        this.slotAccess = slotAccess;
    }

    public static Inventory ofArmor(EquipmentSlot equipmentSlot, LivingEntity livingEntity) {
        if(livingEntity instanceof PlayerEntity player) {
            return ofPlayerArmor(equipmentSlot, player);
        } else {
            return ofGenericArmor(equipmentSlot, livingEntity);
        }
    }

    public static Inventory ofGenericArmor(EquipmentSlot equipmentSlot, LivingEntity livingEntity) {
        return new SlotAccessContainer(StackReference.of(livingEntity, equipmentSlot));
    }

    @Nullable
    public static Inventory ofPlayerArmor(EquipmentSlot equipmentSlot, PlayerEntity player) {
        var index = 39 - switch (equipmentSlot) {
            case HEAD -> 0;
            case CHEST -> 1;
            case LEGS -> 2;
            case FEET -> 3;
            default -> -1;
        };

        if(index == 40) return null;

        return new SlotAccessContainer(StackReference.of(player.getInventory(), index));
    }

    //--

    @Nullable
    public static Inventory ofSaddleSlot(LivingEntity living) {
        if(living instanceof AbstractHorseEntity abstractHorse) {
            return ofHorseSaddle(abstractHorse);
        } else if(living instanceof ItemBasedSteerable saddleable) {
            return ofGenericSaddle(saddleable);
        }

        return null;
    }

    public static Inventory ofHorseSaddle(AbstractHorseEntity abstractHorse) {
        return new SlotAccessContainer(abstractHorse.getStackReference(400));
    }

    public static Inventory ofGenericSaddle(ItemBasedSteerable saddleable) {
        return new SlotAccessContainer(
                StackReference.of(
                        () -> saddleable.isSaddled() ? Items.SADDLE.getDefaultStack() : ItemStack.EMPTY,
                        stack -> {
                            if(stack.isEmpty()) {
                                saddleable.getInstance().setSaddled(false);
                            } else {
                                saddleable.saddle(stack, null);
                            }
                        }
                )
        );
    }

    //--

    @Override
    public int size() {
        return 1;
    }

    @Override
    public boolean isEmpty() {
        return getStack(0).isEmpty();
    }

    @Override
    public ItemStack getStack(int slot) {
        return this.slotAccess.get();
    }

    @Override
    public ItemStack removeStack(int slot, int amount) {
        var stack = this.getStack(0).copy();

        var removedStack = stack.split(amount);

        this.slotAccess.set(stack);

        return removedStack;
    }

    @Override
    public ItemStack removeStack(int slot) {
        var stack = this.getStack(0).copy();

        this.slotAccess.set(ItemStack.EMPTY);

        return stack;
    }

    @Override
    public void setStack(int slot, ItemStack stack) {
        this.slotAccess.set(stack);
    }

    @Override public void markDirty() {}
    @Override public boolean canPlayerUse(PlayerEntity player) { return true; }
    @Override public void clear() {}
}
