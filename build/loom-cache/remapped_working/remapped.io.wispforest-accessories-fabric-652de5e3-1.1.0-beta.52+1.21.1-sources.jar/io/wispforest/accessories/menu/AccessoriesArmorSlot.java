package io.wispforest.accessories.menu;

import io.wispforest.accessories.api.AccessoriesContainer;
import io.wispforest.accessories.api.slot.SlotType;
import io.wispforest.accessories.pond.ArmorSlotExtension;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.inventory.Inventory;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.Nullable;

public class AccessoriesArmorSlot extends class_9692 implements SlotTypeAccessible, ArmorSlotExtension {

    public final AccessoriesContainer accessoriesContainer;

    public AccessoriesArmorSlot(AccessoriesContainer accessoriesContainer, Inventory container, LivingEntity livingEntity, EquipmentSlot equipmentSlot, int slot, int x, int y, @Nullable Identifier resourceLocation) {
        super(container, livingEntity, equipmentSlot, slot, x, y, resourceLocation);

        this.accessoriesContainer = accessoriesContainer;
    }

    @Override
    public String slotName() {
        return accessoriesContainer.getSlotName();
    }

    @Override
    public SlotType slotType() {
        return accessoriesContainer.slotType();
    }

    @Override
    public AccessoriesContainer getContainer() {
        return this.accessoriesContainer;
    }
}
