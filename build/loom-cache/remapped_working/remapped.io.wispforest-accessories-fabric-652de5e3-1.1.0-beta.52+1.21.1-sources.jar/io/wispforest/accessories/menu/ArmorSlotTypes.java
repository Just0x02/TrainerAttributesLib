package io.wispforest.accessories.menu;

import io.wispforest.accessories.Accessories;
import io.wispforest.accessories.api.AccessoriesAPI;
import io.wispforest.accessories.api.AccessoriesCapability;
import io.wispforest.accessories.api.AccessoriesContainer;
import io.wispforest.accessories.api.Accessory;
import io.wispforest.accessories.api.SoundEventData;
import io.wispforest.accessories.api.slot.EntityBasedPredicate;
import io.wispforest.accessories.api.slot.SlotReference;
import io.wispforest.accessories.api.slot.SlotTypeReference;
import io.wispforest.accessories.api.slot.UniqueSlotHandling;
import it.unimi.dsi.fastutil.Pair;
import net.fabricmc.fabric.api.util.TriState;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.passive.AbstractHorseEntity;
import net.minecraft.entity.passive.LlamaEntity;
import net.minecraft.item.Equipment;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;
import org.apache.logging.log4j.util.TriConsumer;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

public class ArmorSlotTypes implements UniqueSlotHandling.RegistrationCallback {

    private static final Accessory armorAccessory = new Accessory() {
        @Override
        @Nullable
        public SoundEventData getEquipSound(ItemStack stack, SlotReference reference) {
            var sound = (stack.getItem() instanceof Equipment equipable) ? equipable.getEquipSound() : SoundEvents.ITEM_ARMOR_EQUIP_GENERIC;

            return new SoundEventData(sound, 1.0f, 1.0f);
        }
    };

    public static final Map<EquipmentSlot, Identifier> TEXTURE_EMPTY_SLOTS = Map.of(
            EquipmentSlot.FEET, Identifier.ofVanilla("item/empty_armor_slot_boots"),
            EquipmentSlot.LEGS, Identifier.ofVanilla("item/empty_armor_slot_leggings"),
            EquipmentSlot.CHEST, Identifier.ofVanilla("item/empty_armor_slot_chestplate"),
            EquipmentSlot.HEAD, Identifier.ofVanilla("item/empty_armor_slot_helmet")
    );

    public static final EquipmentSlot[] SLOT_IDS = new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

    public static final ArmorSlotTypes INSTANCE = new ArmorSlotTypes();

    private static final Identifier HEAD_PREDICATE_LOCATION = Accessories.of("head");
    private static final Identifier CHEST_PREDICATE_LOCATION = Accessories.of("chest");
    private static final Identifier LEGS_PREDICATE_LOCATION = Accessories.of("legs");
    private static final Identifier FEET_PREDICATE_LOCATION = Accessories.of("feet");
    private static final Identifier ANIMAL_BODY_PREDICATE_LOCATION  = Accessories.of("animal_body");

    private SlotTypeReference headSlotReference = null;
    private SlotTypeReference chestSlotReference = null;
    private SlotTypeReference legsSlotReference = null;
    private SlotTypeReference feetSlotReference = null;
    private SlotTypeReference animalBodySlotReference = null;

    private ArmorSlotTypes() {}

    public static boolean isArmorType(String slotType) {
        return headSlot().slotName().equals(slotType)
                || chestSlot().slotName().equals(slotType)
                || legsSlot().slotName().equals(slotType)
                || feetSlot().slotName().equals(slotType);
    }

    public static SlotTypeReference headSlot() {
        return ArmorSlotTypes.INSTANCE.headSlotReference;
    }

    public static SlotTypeReference chestSlot() {
        return ArmorSlotTypes.INSTANCE.chestSlotReference;
    }

    public static SlotTypeReference legsSlot() {
        return ArmorSlotTypes.INSTANCE.legsSlotReference;
    }

    public static SlotTypeReference feetSlot() {
        return ArmorSlotTypes.INSTANCE.feetSlotReference;
    }

    public static SlotTypeReference animalBody() {
        return ArmorSlotTypes.INSTANCE.animalBodySlotReference;
    }

    public static List<SlotTypeReference> getArmorReferences() {
        return List.of(headSlot(), chestSlot(), legsSlot(), feetSlot());
    }

    public static final Identifier SPRITE_ATLAS_LOCATION = Identifier.ofVanilla("textures/atlas/gui.png");

    private static final Identifier LLAMA_ARMOR_SLOT_SPRITE = Identifier.ofVanilla("container/horse/llama_armor_slot");
    private static final Identifier HORSE_ARMOR_SLOT_SPRITE = Identifier.ofVanilla("container/horse/armor_slot");

    @Nullable
    public static Pair<@Nullable Identifier, Identifier> getEmptyTexture(EquipmentSlot slot, LivingEntity living) {
        var texture = TEXTURE_EMPTY_SLOTS.get(slot);

        if (texture != null) return Pair.of(null, texture);


        if (living instanceof AbstractHorseEntity horse) {
            if (horse.canUseSlot(EquipmentSlot.BODY)) {
                if (horse instanceof LlamaEntity) return Pair.of(SPRITE_ATLAS_LOCATION, LLAMA_ARMOR_SLOT_SPRITE);

                return Pair.of(SPRITE_ATLAS_LOCATION, HORSE_ARMOR_SLOT_SPRITE);
            }
        }

        return null;
    }

    @Nullable
    public static SlotTypeReference getReferenceFromSlot(EquipmentSlot equipmentSlot) {
        return switch (equipmentSlot) {
            case HEAD -> headSlot();
            case CHEST -> chestSlot();
            case LEGS -> legsSlot();
            case FEET -> feetSlot();
            case BODY -> animalBody();
            default -> null;
        };
    }

    public static boolean isValidEquipable(EquipmentSlot equipmentSlot) {
        return switch (equipmentSlot) {
            case HEAD, LEGS, CHEST, FEET, BODY -> true;
            default -> false;
        };
    }

    public void init() {
        UniqueSlotHandling.EVENT.register(this);

        AccessoriesAPI.registerPredicate(HEAD_PREDICATE_LOCATION, (EntityBasedPredicate) ((level, entity, slotType, slot, stack) -> isValid(entity, stack, EquipmentSlot.HEAD)));
        AccessoriesAPI.registerPredicate(CHEST_PREDICATE_LOCATION, (EntityBasedPredicate) ((level, entity, slotType, slot, stack) -> isValid(entity, stack, EquipmentSlot.CHEST)));
        AccessoriesAPI.registerPredicate(LEGS_PREDICATE_LOCATION,  (EntityBasedPredicate) ((level, entity, slotType, slot, stack) -> isValid(entity, stack, EquipmentSlot.LEGS)));
        AccessoriesAPI.registerPredicate(FEET_PREDICATE_LOCATION,  (EntityBasedPredicate) ((level, entity, slotType, slot, stack) -> isValid(entity, stack, EquipmentSlot.FEET)));
        AccessoriesAPI.registerPredicate(ANIMAL_BODY_PREDICATE_LOCATION,  (EntityBasedPredicate) ((level, entity, slotType, slot, stack) -> isValid(entity, stack, EquipmentSlot.BODY)));
    }

    public void registerAccessories(Consumer<TriConsumer<Integer, Identifier, Item>> eventRegister) {
        Registries.ITEM.forEach(this::tryToRegisterItem);

        eventRegister.accept((integer, resourceLocation, item) -> tryToRegisterItem(item));
    }

    private void tryToRegisterItem(Item item) {
        if(item instanceof Equipment equipable && isValidEquipable(equipable.getSlotType())) {
            var accessory = AccessoriesAPI.getAccessory(item);

            if(accessory == null) AccessoriesAPI.registerAccessory(item, armorAccessory);
        }
    }

    @Override
    public void registerSlots(UniqueSlotHandling.UniqueSlotBuilderFactory factory) {
        headSlotReference = factory.create(Accessories.of("head"), 1)
                .allowTooltipInfo(false)
                .slotPredicates(HEAD_PREDICATE_LOCATION)
                .strictMode(true)
                .allowResizing(false)
                .allowEquipFromUse(false)
                .validTypes(EntityType.PLAYER, EntityType.ARMOR_STAND)
                .build();

        chestSlotReference = factory.create(Accessories.of("chest"), 1)
                .allowTooltipInfo(false)
                .slotPredicates(CHEST_PREDICATE_LOCATION)
                .strictMode(true)
                .allowResizing(false)
                .allowEquipFromUse(false)
                .validTypes(EntityType.PLAYER, EntityType.ARMOR_STAND)
                .build();

        legsSlotReference = factory.create(Accessories.of("legs"), 1)
                .allowTooltipInfo(false)
                .slotPredicates(LEGS_PREDICATE_LOCATION)
                .strictMode(true)
                .allowResizing(false)
                .allowEquipFromUse(false)
                .validTypes(EntityType.PLAYER, EntityType.ARMOR_STAND)
                .build();

        feetSlotReference = factory.create(Accessories.of("feet"), 1)
                .allowTooltipInfo(false)
                .slotPredicates(FEET_PREDICATE_LOCATION)
                .strictMode(true)
                .allowResizing(false)
                .allowEquipFromUse(false)
                .validTypes(EntityType.PLAYER, EntityType.ARMOR_STAND)
                .build();

        animalBodySlotReference = factory.create(Accessories.of("animal_body"), 1)
                .allowTooltipInfo(false)
                .slotPredicates(ANIMAL_BODY_PREDICATE_LOCATION)
                .strictMode(true)
                .allowResizing(false)
                .allowEquipFromUse(false)
                .validTypes(EntityType.HORSE, EntityType.WOLF)
                .build();
    }

    private static TriState isValid(LivingEntity livingEntity, ItemStack stack, EquipmentSlot equipmentSlot) {
        EquipmentSlot stackEquipmentSlot = null;

        if(livingEntity == null) {
            var equipable = Equipment.fromStack(stack);

            if(equipable != null) stackEquipmentSlot = equipable.getSlotType();
        } else {
            stackEquipmentSlot = livingEntity.getPreferredEquipmentSlot(stack);
        }

        return equipmentSlot.equals(stackEquipmentSlot) ? TriState.TRUE : TriState.DEFAULT;
    }

    @Nullable
    public static ItemStack getAlternativeStack(LivingEntity instance, EquipmentSlot equipmentSlot) {
        var capability = instance.accessoriesCapability();

        if (capability != null) {
            var reference = ArmorSlotTypes.getReferenceFromSlot(equipmentSlot);

            if (reference != null) {
                var container = capability.getContainer(reference);

                if (container != null) {
                    if(!container.shouldRender(0)) return ItemStack.EMPTY;

                    var stack = container.getCosmeticAccessories().method_5438(0);

                    if (!stack.method_7960() && Accessories.config().clientOptions.showCosmeticAccessories()) return stack;
                }
            }
        }

        return null;
    }
}
