package io.wispforest.accessories.menu;

import I;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.Inventory;
import net.minecraft.inventory.StackReference;
import net.minecraft.item.ItemStack;

public interface EquipmentSlotBasedContainer extends Inventory {

    static Inventory of(EquipmentSlot equipmentSlot, LivingEntity livingEntity) {
        if(livingEntity instanceof PlayerEntity player) {
            return ofPlayer(equipmentSlot, player);
        } else {
            return ofLiving(equipmentSlot, livingEntity);
        }
    }

    static Inventory ofLiving(EquipmentSlot equipmentSlot, LivingEntity livingEntity) {
        var slotAccess = StackReference.of(
                () -> livingEntity.getEquippedStack(equipmentSlot),
                stack -> livingEntity.equipStack(equipmentSlot, stack)
        );

        return new SlotAccessContainer(slotAccess);
    }

    static Inventory ofPlayer(EquipmentSlot equipmentSlot, PlayerEntity player) {
        var slotAccess = StackReference.of(
                () -> {
                    var inv = player.getInventory();

                    var index = switch (equipmentSlot) {
                        case HEAD -> 3;
                        case CHEST -> 2;
                        case LEGS -> 1;
                        case FEET -> 0;
                        default -> -1;
                    };

                    if(index == -1) return ItemStack.EMPTY;

                    return inv.getArmorStack(index);
                },
                stack -> {
                    var inv = player.getInventory();

                    var index = switch (equipmentSlot) {
                        case HEAD -> 0;
                        case CHEST -> 1;
                        case LEGS -> 2;
                        case FEET -> 3;
                        default -> -1;
                    };

                    if(index == -1) return;


                    inv.setStack(39 - index, stack);
                }
        );

        return new SlotAccessContainer(slotAccess);
    }

    EquipmentSlot equipmentSlot();

    ItemStack getEquipmentStack(EquipmentSlot equipmentSlot);

    void setEquipmentStack(EquipmentSlot equipmentSlot, ItemStack stack);

    @Override
    default int size() {
        return 1;
    }

    @Override
    default boolean isEmpty() {
        return getStack(0).isEmpty();
    }

    @Override
    default ItemStack getStack(int slot) {
        return this.getEquipmentStack(equipmentSlot());
    }

    @Override
    default ItemStack removeStack(int slot, int amount) {
        var stack = this.getStack(0).copy();

        var removedStack = stack.split(amount);

        this.setEquipmentStack(equipmentSlot(), stack);

        return removedStack;
    }

    @Override
    default ItemStack removeStack(int slot) {
        var stack = this.getStack(0).copy();

        this.setEquipmentStack(equipmentSlot(), ItemStack.EMPTY);

        return stack;
    }

    @Override
    default void setStack(int slot, ItemStack stack) {
        this.setEquipmentStack(equipmentSlot(), stack);
    }

    @Override
    default void markDirty() {}

    @Override
    default boolean canPlayerUse(PlayerEntity player) {
        return true;
    }

    @Override
    default void clear() {}
}
