package io.wispforest.accessories.menu;

import io.wispforest.accessories.compat.config.ScreenType;
import io.wispforest.accessories.menu.variants.AccessoriesExperimentalMenu;
import io.wispforest.accessories.menu.variants.AccessoriesMenu;
import io.wispforest.accessories.menu.variants.AccessoriesMenuBase;
import org.jetbrains.annotations.Nullable;

import java.util.function.Supplier;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.ScreenHandlerType;

public enum AccessoriesMenuVariant {
    ORIGINAL(() -> AccessoriesMenuTypes.ORIGINAL_MENU),
    EXPERIMENTAL_V1(() -> AccessoriesMenuTypes.EXPERIMENTAL_MENU);

    public final Supplier<ScreenHandlerType<? extends AccessoriesMenuBase>> supplier;

    AccessoriesMenuVariant(Supplier<ScreenHandlerType<? extends AccessoriesMenuBase>> supplier) {
        this.supplier = supplier;
    }

    @Nullable
    public static AccessoriesMenuVariant getVariant(ScreenType screenType) {
        return switch (screenType) {
            case ORIGINAL -> ORIGINAL;
            case EXPERIMENTAL_V1 -> EXPERIMENTAL_V1;
            default -> null;
        };
    }

    public static AccessoriesMenuVariant getVariant(ScreenHandlerType<? extends AccessoriesMenuBase> menuType) {
        for (var value : AccessoriesMenuVariant.values()) {
            if(value.supplier.get().equals(menuType)) return value;
        }

        throw new IllegalArgumentException("Unknown MenuType passed to get Accessories Menu Variant! [Type: " + Registries.SCREEN_HANDLER.getId(menuType) + "]");
    }

    public static ScreenHandler openMenu(int i, PlayerInventory inv, AccessoriesMenuVariant variant, @Nullable LivingEntity target, @Nullable ItemStack carriedStack) {
        var menu = switch (variant) {
            case AccessoriesMenuVariant.EXPERIMENTAL_V1 -> new AccessoriesExperimentalMenu(i, inv, target);
            case ORIGINAL -> new AccessoriesMenu(i, inv, target);
            default -> throw new IllegalArgumentException("Unknown AccessoriesMenuVariant passed to construct Menu! [Variant: " + variant.name() + "]");
        };

        if(carriedStack != null) menu.setCursorStack(carriedStack);

        return menu;
    }
}
