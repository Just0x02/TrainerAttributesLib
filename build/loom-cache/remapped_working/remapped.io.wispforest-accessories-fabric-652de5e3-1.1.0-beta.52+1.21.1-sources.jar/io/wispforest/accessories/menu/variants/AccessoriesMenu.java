package io.wispforest.accessories.menu.variants;

import I;
import com.google.common.collect.ImmutableSet;
import com.mojang.datafixers.util.Pair;
import com.mojang.logging.LogUtils;
import io.wispforest.accessories.Accessories;
import io.wispforest.accessories.api.AccessoriesAPI;
import io.wispforest.accessories.api.AccessoriesCapability;
import io.wispforest.accessories.api.AccessoriesContainer;
import io.wispforest.accessories.api.AccessoriesHolder;
import io.wispforest.accessories.api.slot.SlotGroup;
import io.wispforest.accessories.api.slot.SlotType;
import io.wispforest.accessories.data.SlotGroupLoader;
import io.wispforest.accessories.data.SlotTypeLoader;
import io.wispforest.accessories.menu.AccessoriesInternalSlot;
import io.wispforest.accessories.menu.AccessoriesMenuData;
import io.wispforest.accessories.menu.AccessoriesMenuTypes;
import io.wispforest.accessories.menu.ArmorSlotTypes;
import io.wispforest.accessories.mixin.SlotAccessor;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;

import java.util.*;
import java.util.stream.Stream;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.Slot;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

public final class AccessoriesMenu extends AccessoriesMenuBase {

    private static final Logger LOGGER = LogUtils.getLogger();

    public static final Identifier BLOCK_ATLAS = Identifier.ofVanilla("textures/atlas/blocks.png");
    public static final Identifier EMPTY_ARMOR_SLOT_SHIELD = Identifier.ofVanilla("item/empty_armor_slot_shield");

    public int totalSlots = 0;
    public boolean overMaxVisibleSlots = false;

    public int scrolledIndex = 0;

    public float smoothScroll = 0;

    private int maxScrollableIndex = 0;

    private int accessoriesSlotStartIndex = 0;
    private int cosmeticSlotStartIndex = 0;

    private final Set<SlotGroup> validGroups = new HashSet<>();

    private final Map<Integer, Boolean> slotToView = new HashMap<>();

    private Runnable onScrollToEvent = () -> {};

    @Nullable
    private Set<SlotType> usedSlots = null;

    private Map<AccessoriesInternalSlot, Integer> slotToPageIndex = new HashMap<>();

    public AccessoriesMenu(int containerId, PlayerInventory inventory, @Nullable LivingEntity targetEntity) {
        super(AccessoriesMenuTypes.ORIGINAL_MENU, containerId, inventory, targetEntity);

        var accessoryTarget = targetEntity != null ? targetEntity : owner;

        var capability = AccessoriesCapability.get(accessoryTarget);

        if (capability == null) return;

        //-- Vanilla Slot Setup

        for (int i = 0; i < 4; i++) {
            var equipmentSlot = ArmorSlotTypes.SLOT_IDS[i];
            Identifier resourceLocation = ArmorSlotTypes.TEXTURE_EMPTY_SLOTS.get(equipmentSlot);
            this.addSlot(new class_9692(inventory, owner, equipmentSlot, 39 - i, 8, 8 + i * 18, resourceLocation));
        }

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 9; j++) {
                this.addSlot(new Slot(inventory, j + (i + 1) * 9, 8 + j * 18, 84 + i * 18));
            }
        }

        for (int i = 0; i < 9; i++) {
            this.addSlot(new Slot(inventory, i, 8 + i * 18, 142));
        }

        this.addSlot(new Slot(inventory, 40, 152, 62) {
            @Override
            public void setStack(ItemStack newStack, ItemStack oldStack) {
                owner.onEquipStack(EquipmentSlot.OFFHAND, oldStack, newStack);
                super.setStack(newStack, oldStack);
            }

            @Override
            public Pair<Identifier, Identifier> getBackgroundSprite() {
                return Pair.of(BLOCK_ATLAS, EMPTY_ARMOR_SLOT_SHIELD);
            }
        });

        //--

        if(!this.areUnusedSlotsShown()) {
            this.usedSlots = ImmutableSet.copyOf(AccessoriesAPI.getUsedSlotsFor(targetEntity != null ? targetEntity : owner, owner.getInventory()));
        }

        int minX = -46, maxX = 60, minY = 8, maxY = 152;

        int yIndex = 0;

        this.accessoriesSlotStartIndex = this.slots.size();

        var slotVisibility = new HashMap<Slot, Boolean>();

        var accessoriesSlots = new ArrayList<AccessoriesInternalSlot>();
        var cosmeticSlots = new ArrayList<AccessoriesInternalSlot>();

        var groups = SlotGroupLoader.getGroups(inventory.player.getWorld(), true);

        var containers = capability.getContainers();

        var slotTypes = groups.stream().sorted(Comparator.comparingInt(SlotGroup::order).reversed())
                .flatMap(slotGroup -> {
                    if(slotGroup.name().equals(Accessories.MODID)) return Stream.of();

                    return slotGroup.slots().stream()
                            .map(s -> {
                                var slotType = SlotTypeLoader.getSlotType(owner.getWorld(), s);

                                if(this.usedSlots != null && !this.usedSlots.contains(slotType)) return null;

                                this.validGroups.add(slotGroup);

                                return slotType;
                            })
                            .filter(Objects::nonNull)
                            .sorted(Comparator.comparingInt(SlotType::order).reversed());
                }).toList();

        //LOGGER.info("SlotTypes for [{}] Screen: {}", (owner.level().isClientSide() ? "client" : "server"), slotTypes);
        //LOGGER.info("Containers for [{}] Screen: {}", (owner.level().isClientSide() ? "client" : "server"), containers.keySet());

        for (var slot : slotTypes) {
            var accessoryContainer = containers.get(slot.name());

            if (accessoryContainer == null || accessoryContainer.slotType() == null) continue;

            var size = accessoryContainer.getSize();

            for (int i = 0; i < size; i++) {
                int currentY = (yIndex * 18) + minY + 8;

                int currentX = minX;

                var cosmeticSlot = new AccessoriesInternalSlot(accessoryContainer, true, i, currentX, currentY)
                                .isActive((slot1) -> this.isCosmeticsOpen() && this.slotToView.getOrDefault(slot1.id, true))
                                .isAccessible(slot1 -> slot1.isCosmetic && isCosmeticsOpen());

                slotToPageIndex.put(cosmeticSlot, yIndex);

                    cosmeticSlots.add(cosmeticSlot);

                slotVisibility.put(cosmeticSlot, !this.overMaxVisibleSlots);

                currentX += 18 + 2;

                var baseSlot = new AccessoriesInternalSlot(accessoryContainer, false, i, currentX, currentY)
                                .isActive(slot1 -> this.slotToView.getOrDefault(slot1.id, true));

                slotToPageIndex.put(baseSlot, yIndex);

                    accessoriesSlots.add(baseSlot);

                slotVisibility.put(baseSlot, !this.overMaxVisibleSlots);

                yIndex++;

                if (!this.overMaxVisibleSlots && currentY + 18 > maxY) this.overMaxVisibleSlots = true;
            }
        }

        for (var accessoriesSlot : accessoriesSlots) {
            this.addSlot(accessoriesSlot);

            slotToView.put(accessoriesSlot.id, slotVisibility.getOrDefault(accessoriesSlot, false));
        }

        this.cosmeticSlotStartIndex = this.slots.size();

        for (var cosmeticSlot : cosmeticSlots) {
            this.addSlot(cosmeticSlot);

            this.slotToView.put(cosmeticSlot.id, slotVisibility.getOrDefault(cosmeticSlot, false));
        }

        this.totalSlots = yIndex;

        this.maxScrollableIndex = this.totalSlots - 8;

        this.slotAmountAdded = this.slots.size() - this.accessoriesSlotStartIndex;
    }

    public void setScrollEvent(Runnable event) {
        this.onScrollToEvent = event;
    }

    public boolean scrollTo(int i, boolean smooth) {
        var index = Math.min(Math.max(i, 0), this.maxScrollableIndex);

        if (index == this.scrolledIndex) return false;

        var diff = this.scrolledIndex - index;

        if (!smooth) this.smoothScroll = MathHelper.clamp(index / (float) this.maxScrollableIndex, 0.0f, 1.0f);

        for (Slot slot : this.slots) {
            if (!(slot instanceof AccessoriesInternalSlot accessoriesSlot)) continue;

            ((SlotAccessor) accessoriesSlot).accessories$setY(accessoriesSlot.y + (diff * 18));

            var menuIndex = slotToPageIndex.get(accessoriesSlot);

            this.slotToView.put(accessoriesSlot.id, (menuIndex >= index && menuIndex < index + 8));
        }

        this.scrolledIndex = index;

        this.onScrollToEvent.run();

        return true;
    }

    public int maxScrollableIndex(){
        return this.maxScrollableIndex;
    }

    public static AccessoriesMenu of(int containerId, PlayerInventory inventory, AccessoriesMenuData data) {
        var targetEntity = data.targetEntityId().map(i -> {
            var entity = inventory.player.getWorld().getEntityById(i);

            if(entity instanceof LivingEntity livingEntity) return livingEntity;

            return null;
        }).orElse(null);

        var menu = new AccessoriesMenu(containerId, inventory, targetEntity)
                .isSyncedWithServer(data.slotAmountAdded());

        return (AccessoriesMenu) menu;
    }

    public boolean showingSlots() {
        return this.usedSlots == null || !this.usedSlots.isEmpty();
    }

    @Nullable
    public Set<SlotType> usedSlots() {
        return this.usedSlots;
    }

    public Set<SlotGroup> validGroups() {
        return this.validGroups;
    }

    public boolean isCosmeticsOpen() {
        return Optional.ofNullable(AccessoriesHolder.get(owner)).map(AccessoriesHolder::cosmeticsShown).orElse(false);
    }

    public boolean areUnusedSlotsShown() {
        return Optional.ofNullable(AccessoriesHolder.get(owner)).map(AccessoriesHolder::showUnusedSlots).orElse(false);
    }

    //--

    @Override
    public boolean canUse(PlayerEntity player) {
        return true;
    }

    @Override
    public ItemStack quickMove(PlayerEntity player, int clickedIndex) {
        final var slots = this.slots;
        final var clickedSlot = slots.get(clickedIndex);
        if (!clickedSlot.hasStack()) return ItemStack.EMPTY;

        ItemStack clickedStack = clickedSlot.getStack();
        var oldStack = clickedStack.copy();
        EquipmentSlot equipmentSlot = player.getPreferredEquipmentSlot(oldStack);

        int armorSlots = 4;
        int hotbarSlots = 9;
        int invSlots = 27;

        int armorStart = 0;
        int armorEnd = armorStart - 1 + armorSlots;
        int invStart = armorEnd + 1;
        int invEnd = invStart - 1 + invSlots;
        int hotbarStart = invEnd + 1;
        int hotbarEnd = hotbarStart - 1 + hotbarSlots;
        int offhand = hotbarEnd + 1;

        // If the clicked slot isn't an accessory slot
        if (clickedIndex < this.accessoriesSlotStartIndex) {
            // Try to move to accessories
            if (!this.insertItem(clickedStack, this.accessoriesSlotStartIndex, this.slots.size(), false)) {
                // If the clicked slot is one of the armor slots
                if (clickedIndex >= armorStart && clickedIndex <= armorEnd) {
                    // Try to move to the inventory or hotbar
                    if (!this.insertItem(clickedStack, invStart, hotbarEnd, false)) {
                        return ItemStack.EMPTY;
                    }
                    // If the clicked slot can go into an armor slot and said armor slot is empty
                } else if (equipmentSlot.getType() == EquipmentSlot.Type.HUMANOID_ARMOR && !this.slots.get(armorEnd - equipmentSlot.getEntitySlotId()).hasStack()) {
                    // Try to move to the armor slot
                    int targetArmorSlotIndex = armorEnd - equipmentSlot.getEntitySlotId();
                    if (!this.insertItem(clickedStack, targetArmorSlotIndex, targetArmorSlotIndex + 1, false)) {
                        return ItemStack.EMPTY;
                    }
                    // If the clicked slot can go into the offhand slot and the offhand slot is empty
                } else if (equipmentSlot == EquipmentSlot.OFFHAND && !this.slots.get(offhand).hasStack()) {
                    // Try to move to the offhand slot
                    if (!this.insertItem(clickedStack, offhand, offhand + 1, false)) {
                        return ItemStack.EMPTY;
                    }
                    // If the clicked slot is in the hotbar
                } else if (clickedIndex >= hotbarStart && clickedIndex <= hotbarEnd) {
                    // Try to move to the inventory
                    if (!this.insertItem(clickedStack, invStart, invEnd, false)) {
                        return ItemStack.EMPTY;
                    }
                    // If the clicked slot is in the inventory
                } else if (clickedIndex >= invStart && clickedIndex <= invEnd) {
                    // Try to move to the hotbar
                    if (!this.insertItem(clickedStack, hotbarStart, hotbarEnd, false)) {
                        return ItemStack.EMPTY;
                    }
                    // Try to move to the inventory or hotbar
                } else if (!this.insertItem(clickedStack, invStart, hotbarEnd, false)) {
                    return ItemStack.EMPTY;
                }
            }
        } else if (!this.insertItem(clickedStack, invStart, hotbarEnd, false)) {
            return ItemStack.EMPTY;
        }

        if (clickedStack.isEmpty()) {
            clickedSlot.setStack(ItemStack.EMPTY, oldStack);
        } else {
            clickedSlot.markDirty();
        }

        if (clickedStack.getCount() == oldStack.getCount()) {
            return ItemStack.EMPTY;
        }

        clickedSlot.onTakeItem(player, clickedStack);

        return oldStack;
    }

    @Override
    protected boolean insertItem(ItemStack stack, int startIndex, int endIndex, boolean reverseDirection) {
        boolean bl = false;
        int i = startIndex;
        if (reverseDirection) {
            i = endIndex - 1;
        }

        if (stack.isStackable()) {
            while(!stack.isEmpty() && (reverseDirection ? i >= startIndex : i < endIndex)) {
                Slot slot = this.slots.get(i);
                ItemStack itemStack = slot.getStack();

                //Check if the slot does not permit the given amount
                if(slot.getMaxItemCount(itemStack) < itemStack.getCount()) {
                    if (!itemStack.isEmpty() && ItemStack.areItemsAndComponentsEqual(stack, itemStack)) {
                        int j = itemStack.getCount() + stack.getCount();
                        if (j <= stack.getMaxCount()) {
                            stack.setCount(0);
                            itemStack.setCount(j);
                            slot.markDirty();
                            bl = true;
                        } else if (itemStack.getCount() < stack.getMaxCount()) {
                            stack.decrement(stack.getMaxCount() - itemStack.getCount());
                            itemStack.setCount(stack.getMaxCount());
                            slot.markDirty();
                            bl = true;
                        }
                    }
                }

                if (reverseDirection) {
                    --i;
                } else {
                    ++i;
                }
            }
        }

        if (!stack.isEmpty()) {
            if (reverseDirection) {
                i = endIndex - 1;
            } else {
                i = startIndex;
            }

            while(reverseDirection ? i >= startIndex : i < endIndex) {
                Slot slot = this.slots.get(i);

                ItemStack itemStack = slot.getStack();
                if (itemStack.isEmpty() && slot.canInsert(stack)) {
                    //Use Stack aware form of getMaxStackSize
                    if (stack.getCount() > slot.getMaxItemCount(stack)) {
                        slot.setStack(stack.split(slot.getMaxItemCount(stack)));
                    } else {
                        slot.setStack(stack.split(stack.getCount()));
                    }

                    slot.markDirty();
                    bl = true;
                    break;
                }

                if (reverseDirection) {
                    --i;
                } else {
                    ++i;
                }
            }
        }

        return bl;
    }

    //--
}