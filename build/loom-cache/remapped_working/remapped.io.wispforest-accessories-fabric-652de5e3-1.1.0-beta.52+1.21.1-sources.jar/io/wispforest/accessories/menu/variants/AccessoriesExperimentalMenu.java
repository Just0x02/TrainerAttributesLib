package io.wispforest.accessories.menu.variants;

import I;
import Z;
import com.mojang.datafixers.util.Pair;
import io.wispforest.accessories.api.AccessoriesAPI;
import io.wispforest.accessories.api.AccessoriesCapability;
import io.wispforest.accessories.api.AccessoriesContainer;
import io.wispforest.accessories.api.AccessoriesHolder;
import io.wispforest.accessories.api.menu.AccessoriesBasedSlot;
import io.wispforest.accessories.api.slot.SlotGroup;
import io.wispforest.accessories.api.slot.SlotType;
import io.wispforest.accessories.api.slot.SlotTypeReference;
import io.wispforest.accessories.api.slot.UniqueSlotHandling;
import io.wispforest.accessories.data.SlotGroupLoader;
import io.wispforest.accessories.menu.*;
import io.wispforest.accessories.menu.networking.ToggledSlots;
import io.wispforest.owo.client.screens.SlotGenerator;
import io.wispforest.owo.util.pond.OwoSlotExtension;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.passive.LlamaEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SaddleItem;
import net.minecraft.screen.PlayerScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.util.Identifier;

public class AccessoriesExperimentalMenu extends AccessoriesMenuBase {

    private final Set<SlotType> usedSlots = new HashSet<>();

    private final Set<SlotGroup> selectedGroups = new HashSet<>();

    private final List<AccessoriesBasedSlot> accessoriesSpecificSlots = new ArrayList<>();

    private int addedArmorSlots = 0;

    private int startArmorSlots = 0;
    private int startingAccessoriesSlot = 0;

    private boolean includeSaddle = false;

    public static AccessoriesExperimentalMenu of(int containerId, PlayerInventory inventory, AccessoriesMenuData data) {
        var targetEntity = data.targetEntityId()
                .map(i -> (inventory.player.getWorld().getEntityById(i) instanceof LivingEntity livingEntity)
                        ? livingEntity
                        : null
                ).orElse(null);

        var menu = new AccessoriesExperimentalMenu(containerId, inventory, targetEntity)
                .isSyncedWithServer(data.slotAmountAdded());

        return (AccessoriesExperimentalMenu) menu;
    }

    public AccessoriesExperimentalMenu(int containerId, PlayerInventory inventory, @Nullable LivingEntity targetEntity) {
        super(AccessoriesMenuTypes.EXPERIMENTAL_MENU, containerId, inventory, targetEntity);

        var accessoryTarget = targetEntity != null ? targetEntity : owner;

        var capability = AccessoriesCapability.get(accessoryTarget);

        if (capability == null) return;

        this.updateUsedSlots();

        //--

        SlotGenerator.begin(this::addSlot, -300, -300)
                .playerInventory(inventory);

        //--

        this.addSlot(new Slot(inventory, 40, -300, -300) {
            @Override
            public void setStack(ItemStack itemStack, ItemStack itemStack2) {
                inventory.player.onEquipStack(EquipmentSlot.OFFHAND, itemStack2, itemStack);
                super.setStack(itemStack, itemStack2);
            }

            @Override
            public Pair<Identifier, Identifier> getBackgroundSprite() {
                return Pair.of(PlayerScreenHandler.BLOCK_ATLAS_TEXTURE, PlayerScreenHandler.EMPTY_OFFHAND_ARMOR_SLOT);
            }
        });

        var saddleInv = SlotAccessContainer.ofSaddleSlot(accessoryTarget);

        if(saddleInv != null) {
            this.includeSaddle = true;

            var iconPath = targetEntity instanceof LlamaEntity ? "container/horse/llama_armor_slot" : "container/horse/saddle_slot" ;

            this.addSlot(
                    new Slot(saddleInv, 0, -300, -300){
                        @Override
                        public boolean canInsert(ItemStack stack) {
                            return stack.getItem() instanceof SaddleItem && super.canInsert(stack);
                        }

                        @Override
                        public Pair<Identifier, Identifier> getBackgroundSprite() {
                            return Pair.of(ArmorSlotTypes.SPRITE_ATLAS_LOCATION, Identifier.ofVanilla(iconPath));
                        }
                    }
            );
        }

        this.startArmorSlots = this.slots.size();

        var containers = capability.getContainers();

        var validEquipmentSlots = new ArrayList<EquipmentSlot>();

        for (var value : EquipmentSlot.values()) {
            if (!accessoryTarget.canUseSlot(value)) continue;

            var armorRef = ArmorSlotTypes.getReferenceFromSlot(value);

            if (armorRef == null || containers.get(armorRef.slotName()) == null) continue;

            validEquipmentSlots.add(value);
        }

        for (var equipmentSlot : validEquipmentSlots.reversed()) {
            if (addArmorSlot(equipmentSlot, accessoryTarget, ArmorSlotTypes.getReferenceFromSlot(equipmentSlot), containers)) {
                addedArmorSlots += 2;
            }
        }

        this.startingAccessoriesSlot = this.slots.size();

        //--

        var validGroupData = SlotGroupLoader.getValidGroups(accessoryTarget);

        var slotTypes = validGroupData.values()
                .stream()
                .flatMap(Collection::stream)
                .toList();

        for (var slot : slotTypes) {
            var accessoryContainer = containers.get(slot.name());

            if (accessoryContainer == null || accessoryContainer.slotType() == null) continue;

            for (int i = 0; i < accessoryContainer.getSize(); i++) {
                var cosmeticSlot = new AccessoriesInternalSlot(accessoryContainer, true, i, -300, -300)
                        .useCosmeticIcon(false);

                this.addSlot(cosmeticSlot);
                this.accessoriesSpecificSlots.add(cosmeticSlot);

                var baseSlot = new AccessoriesInternalSlot(accessoryContainer, false, i, -300, -300);

                this.addSlot(baseSlot);
                this.accessoriesSpecificSlots.add(baseSlot);
            }
        }

        ToggledSlots.initMenu(this);

        this.slotAmountAdded = this.slots.size() - this.startArmorSlots;
    }

    private boolean addArmorSlot(EquipmentSlot equipmentSlot, LivingEntity targetEntity, SlotTypeReference armorReference, Map<String, AccessoriesContainer> containers) {
        var location = ArmorSlotTypes.getEmptyTexture(equipmentSlot, targetEntity);

        var armorContainer = containers.get(armorReference.slotName());

        if(armorContainer == null) return false;

        var armorSlot = new AccessoriesArmorSlot(armorContainer, SlotAccessContainer.ofArmor(equipmentSlot, targetEntity), targetEntity, equipmentSlot, 0, -300, -300, location != null ? location.second() : null)
                .setAtlasLocation(location != null ? location.first() : null); // 39 - i

        this.addSlot(armorSlot);

        var cosmeticSlot = new AccessoriesInternalSlot(armorContainer, true, 0, -300, -300){
            @Override
            public @Nullable Pair<Identifier, Identifier> getBackgroundSprite() {
                if(location == null) return null;

                var atlasLocation = location.first();

                if(atlasLocation == null) atlasLocation = Identifier.ofVanilla("textures/atlas/blocks.png");

                return Pair.of(atlasLocation, location.second());
            }
        };

        this.addSlot(cosmeticSlot);

        return true;
    }

    public final LivingEntity targetEntityDefaulted() {
        var targetEntity = this.targetEntity();

        return (targetEntity != null) ? targetEntity : this.owner();
    }

    public int startingAccessoriesSlot() {
        return this.startArmorSlots;
    }

    public List<AccessoriesBasedSlot> getAccessoriesSlots() {
        return this.accessoriesSpecificSlots;
    }

    public List<Slot> getVisibleAccessoriesSlots() {
        var filteredList = new ArrayList<Slot>();

        var groups = SlotGroupLoader.getValidGroups(this.targetEntityDefaulted());

        var usedSlots = this.getUsedSlots();

        if (usedSlots != null) {
            groups.forEach((group, groupSlots) -> {
                if (groupSlots.stream().noneMatch(usedSlots::contains)) this.removeSelectedGroup(group);
            });
        }

        var selectedGroupedSlots = SlotGroupLoader.getValidGroups(this.targetEntityDefaulted()).entrySet()
                .stream()
                .filter(entry -> this.selectedGroups.isEmpty() || this.selectedGroups.contains(entry.getKey()))
                .flatMap(entry -> entry.getValue().stream())
                .toList();

        for (int i = 0; i < (this.accessoriesSpecificSlots.size() / 2); i++) {
            var cosmetic = (i * 2);
            var accessory = cosmetic + 1;

            var cosmeticSlot = this.accessoriesSpecificSlots.get(cosmetic);
            var accessorySlot = this.accessoriesSpecificSlots.get(accessory);

            var slotType = accessorySlot.slotType();

            var isVisible = (this.usedSlots.isEmpty() || this.usedSlots.contains(slotType))
                    && (selectedGroupedSlots.isEmpty() || selectedGroupedSlots.contains(slotType));

            if(isVisible){
                filteredList.add(cosmeticSlot);
                filteredList.add(accessorySlot);
            }
        }

        return filteredList;
    }

    @Nullable
    public Set<SlotType> getUsedSlots() {
        return this.areUnusedSlotsShown() ? null : this.usedSlots;
    }

    public void updateUsedSlots() {
        this.usedSlots.clear();

        if(!this.areUnusedSlotsShown()) {
            var currentlyUsedSlots = AccessoriesAPI.getUsedSlotsFor(this.targetEntity != null ? this.targetEntity : this.owner, this.owner.getInventory());

            if(!currentlyUsedSlots.isEmpty()) {
                this.usedSlots.addAll(currentlyUsedSlots);
            } else {
                this.usedSlots.add(null);
            }
        }
    }

    public Set<SlotGroup> usedGroups() {
        var groups = SlotGroupLoader.getValidGroups(this.targetEntityDefaulted()).entrySet().stream();

        var usedSlots = this.getUsedSlots();

        groups = groups
                .filter(entry -> {
                    var groupSlots = entry.getValue()
                            .stream()
                            .filter(slotType -> {
                                if (UniqueSlotHandling.isUniqueSlot(slotType.name())) return false;

                                var capability = this.targetEntityDefaulted().accessoriesCapability();

                                if (capability == null) return false;

                                var container = capability.getContainer(slotType);

                                if (container == null) return false;

                                return container.getSize() > 0;
                            })
                            .collect(Collectors.toSet());

                    return !groupSlots.isEmpty() && (usedSlots == null || groupSlots.stream().anyMatch(usedSlots::contains));
                });

        return groups.map(Map.Entry::getKey).collect(Collectors.toSet());
    }

    public Set<SlotGroup> selectedGroups() {
        return this.selectedGroups;
    }

    public boolean isGroupSelected(SlotGroup slotGroup) {
        return this.selectedGroups.contains(slotGroup);
    }

    public void addSelectedGroup(SlotGroup slotGroup) {
        this.selectedGroups.add(slotGroup);

        if (this.selectedGroups.containsAll(usedGroups())) {
            this.selectedGroups.clear();
        }
    }

    public void removeSelectedGroup(SlotGroup slotGroup) {
        this.selectedGroups.remove(slotGroup);
    }

    public int addedArmorSlots() {
        return this.addedArmorSlots;
    }

    public boolean includeSaddle() {
        return this.includeSaddle;
    }

    public boolean areUnusedSlotsShown() {
        return Optional.ofNullable(AccessoriesHolder.get(owner)).map(AccessoriesHolder::showUnusedSlots).orElse(false);
    }

    @Override
    public ItemStack quickMove(PlayerEntity player, int index) {
        var slot = this.slots.get(index);

        if(!slot.hasStack()) return ItemStack.EMPTY;

        var itemStack2 = slot.getStack();
        var itemStack = itemStack2.copy();

        // 0 1 2 3 : 6 - 7 / 4 - 5 / 2 - 3 / 0 - 1
        var equipmentSlot = player.getPreferredEquipmentSlot(itemStack);
        int bottomArmorIndex = 42 + (8 - ((equipmentSlot.getEntitySlotId() + 1) * 2));
        int topArmorIndex = bottomArmorIndex + 1;

        var upperInventorySize = this.startingAccessoriesSlot;

        /*
         * Player Indies
         *       0: Result slot
         *  1 -  5: Crafting Grid
         *  5 - 41: Player Inv
         *      41: Offhand Slot
         * 41 - 49: Armor Slots
         * 49 -   : Accessories Slots
         */

        if (index == 0) { // If from Crafting Result move to player inventory
            if (!this.insertItem(itemStack2, 5, 41, true)) return ItemStack.EMPTY;

            slot.onQuickTransfer(itemStack2, itemStack);
        }
        else if ((index >= 1 && index < 5) || (index >= upperInventorySize) || Objects.equals(41, index) || (index >= 43)) { // If from Crafting Grid move to player inventory
            if (!this.insertItem(itemStack2, 5, 41, false)) return ItemStack.EMPTY;
        }
        else if (equipmentSlot.isArmorSlot() && !this.slots.get(bottomArmorIndex).hasStack()) {
            if(!this.insertItem(itemStack2, bottomArmorIndex, topArmorIndex, false)) return ItemStack.EMPTY;
        }
        else if (equipmentSlot == EquipmentSlot.OFFHAND && !this.slots.get(41).hasStack()) {
            if(!this.insertItem(itemStack2, 41, 42, false)) return ItemStack.EMPTY;
        }
        else {
            boolean changeOccured = false;

            if (canMoveToAccessorySlot(itemStack2, this.targetEntityDefaulted())) {
                insertItem(itemStack2, upperInventorySize, slots.size(), false);

                if (itemStack2.getCount() != itemStack.getCount() || itemStack2.isEmpty()) {
                    changeOccured = true;
                }
            }

            if(!changeOccured) {
                if (index >= 5 && index < 32) {
                    if (!this.insertItem(itemStack2, 32, 41, false)) return ItemStack.EMPTY;
                } else if (index >= 32 && index < 41) {
                    if (!this.insertItem(itemStack2, 5, 32, false)) return ItemStack.EMPTY;
                }
            }
        }

        if (itemStack2.getCount() == itemStack.getCount()) return ItemStack.EMPTY;

        if (itemStack2.isEmpty()) {
            slot.setStack(ItemStack.EMPTY, itemStack);
        } else {
            slot.markDirty();
        }

        if (itemStack2.getCount() == itemStack.getCount()) return ItemStack.EMPTY;

        slot.onTakeItem(player, itemStack2);

        if (index == 0) player.dropItem(itemStack2, false);

        return itemStack;
    }

    @Override
    public boolean canUse(PlayerEntity player) {
        return true;
    }

    protected boolean canMoveToAccessorySlot(ItemStack stack, LivingEntity living) {
        var capability = living.accessoriesCapability();

        if (capability == null) return false;

        var validSlotTypes = AccessoriesAPI.getStackSlotTypes(living, stack);

        for (var slot : this.slots.subList(this.startingAccessoriesSlot, this.slots.size())) {
            if (slot instanceof SlotTypeAccessible accessible && validSlotTypes.contains(accessible.slotType())) return true;
        }

        return false;
    }

    protected boolean insertItem(ItemStack stack, int startIndex, int endIndex, boolean reverseDirection) {
        boolean bl = false;
        int i = reverseDirection ? endIndex - 1 : startIndex;

        if (stack.isStackable()) {
            while (!stack.isEmpty() && (reverseDirection ? i >= startIndex : i < endIndex)) {
                var slot = this.slots.get(i);

                if (slot.isEnabled()) {
                    var itemStack = slot.getStack();

                    if (!itemStack.isEmpty() && ItemStack.areItemsAndComponentsEqual(stack, itemStack)) {
                        int j = itemStack.getCount() + stack.getCount();
                        int k = slot.getMaxItemCount(itemStack);

                        if (j <= k) {
                            stack.setCount(0);
                            itemStack.setCount(j);
                            slot.markDirty();
                            bl = true;
                        } else if (itemStack.getCount() < k) {
                            stack.decrement(k - itemStack.getCount());
                            itemStack.setCount(k);
                            slot.markDirty();
                            bl = true;
                        }
                    }
                }

                i += (reverseDirection) ? -1 : 1;
            }
        }

        if (!stack.isEmpty()) {
            i = reverseDirection ? endIndex - 1 : startIndex;

            while (reverseDirection ? i >= startIndex : i < endIndex) {
                var slot = this.slots.get(i);

                if(slot.isEnabled()) {
                    var itemStack = slot.getStack();

                    if (itemStack.isEmpty() && slot.canInsert(stack)) {
                        int j = slot.getMaxItemCount(stack);

                        slot.setStack(stack.split(Math.min(stack.getCount(), j)));
                        slot.markDirty();

                        bl = true;
                        break;
                    }
                }

                i += (reverseDirection) ? -1 : 1;
            }
        }

        return bl;
    }

    // REQUIRED TO PREVENT THE MENU FROM RESETTING THE CACHE WITH STACKS THAT ARE ALREADY SYNCED TO THE CLIENT
    // SINCE ACCESSORIES CONTAINERS ARE FULLY SYNCED
    @Override
    public void updateSlotStacks(int stateId, List<ItemStack> items, ItemStack carried) {
        if (!this.isValidMenu()) return;

        for(int i = 0; i < items.size(); ++i) {
            var slot = this.getSlot(i);

            if (slot instanceof SlotTypeAccessible) continue;

            slot.setStackNoCallbacks(items.get(i));
        }

        super.updateSlotStacks(stateId, List.of(), carried);
    }
}
