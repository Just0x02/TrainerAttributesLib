package io.wispforest.accessories.menu;

import io.wispforest.accessories.Accessories;
import io.wispforest.accessories.api.AccessoriesAPI;
import io.wispforest.accessories.api.AccessoriesContainer;
import io.wispforest.accessories.api.menu.AccessoriesBasedSlot;
import io.wispforest.accessories.api.slot.SlotReference;
import io.wispforest.accessories.api.slot.SlotType;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;

public class AccessoriesInternalSlot extends AccessoriesBasedSlot {

    public final boolean isCosmetic;
    public boolean useCosmeticIcon = true;

    private Function<AccessoriesInternalSlot, Boolean> isActive = (slot) -> true;
    private Function<AccessoriesInternalSlot, Boolean> isAccessible = (slot) -> true;

    public AccessoriesInternalSlot(AccessoriesContainer container, boolean isCosmetic, int slot, int x, int y) {
        super(container, isCosmetic ? container.getCosmeticAccessories() : container.getAccessories(), slot, x, y);

        this.isCosmetic = isCosmetic;
    }

    public AccessoriesInternalSlot isActive(Function<AccessoriesInternalSlot, Boolean> isActive){
        this.isActive = isActive;

        return this;
    }

    public AccessoriesInternalSlot isAccessible(Function<AccessoriesInternalSlot, Boolean> isAccessible){
        this.isAccessible = isAccessible;

        return this;
    }

    public AccessoriesInternalSlot useCosmeticIcon(boolean value) {
        this.useCosmeticIcon = value;

        return this;
    }

    @Override
    public boolean isCosmeticSlot() {
        return this.isCosmetic;
    }

    @Override
    protected Identifier icon() {
        return (this.isCosmetic && useCosmeticIcon) ? Accessories.of("gui/slot/cosmetic") : super.icon();
    }

    public List<Text> getTooltipData() {
        List<Text> tooltipData = new ArrayList<>();

        var key = this.isCosmetic ? "cosmetic_" : "";

        var slotType = this.accessoriesContainer.slotType();

        tooltipData.add(Text.translatable(Accessories.translationKey(key + "slot.tooltip.singular"))
                .formatted(Formatting.GRAY)
                .append(Text.translatable(slotType.translation()).formatted(Formatting.BLUE)));

        return tooltipData;
    }

    @Override
    public void setStackNoCallbacks(ItemStack stack) {
        var prevStack = this.getStack();

        super.setStackNoCallbacks(stack);

        // TODO: SHOULD THIS BE HERE?
//        if(isCosmetic) {
//            var reference = new SlotReference(container.getSlotName(), entity, getContainerSlot());
//
//            AccessoriesAPI.getAccessory(prevStack)
//                    .ifPresent(prevAccessory1 -> prevAccessory1.onUnequip(prevStack, reference));
//
//            AccessoriesAPI.getAccessory(stack)
//                    .ifPresent(accessory1 -> accessory1.onEquip(stack, reference));
//        }
    }

    @Override
    public boolean canInsert(ItemStack stack) {
        if (!this.isAccessible.apply(this)) return false;

        if (!this.isCosmeticSlot()) return super.canInsert(stack);

        var slotType = this.accessoriesContainer.slotType();

        return AccessoriesAPI.getPredicateResults(slotType.validators(), this.entity.getWorld(), this.entity, slotType, 0, stack);
    }

    @Override
    public boolean canTakeItems(PlayerEntity player) {
        return this.isAccessible.apply(this) && (isCosmetic || super.canTakeItems(player));
    }

    @Override
    public boolean canTakePartial(PlayerEntity player) {
        return this.isAccessible.apply(this) && super.canTakePartial(player);
    }

    @Override
    public boolean isEnabled() {
        return this.isActive.apply(this) && super.isEnabled();
    }
}
