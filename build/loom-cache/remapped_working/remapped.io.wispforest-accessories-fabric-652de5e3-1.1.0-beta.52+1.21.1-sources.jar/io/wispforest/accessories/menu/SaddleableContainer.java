package io.wispforest.accessories.menu;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Saddleable;
import net.minecraft.entity.passive.AbstractHorseEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.Inventory;
import net.minecraft.inventory.StackReference;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.sound.SoundCategory;
import org.jetbrains.annotations.Nullable;

public interface SaddleableContainer extends Inventory {

    @Nullable
    static Inventory of(LivingEntity living) {
        if(living instanceof AbstractHorseEntity abstractHorse) {
            return ofHorse(abstractHorse);
        } else if(living instanceof Saddleable saddleable) {
            return ofSaddleable(saddleable);
        }

        return null;
    }

    static Inventory ofHorse(AbstractHorseEntity abstractHorse) {
        return new SlotAccessContainer(abstractHorse.getStackReference(400));

//        return new SaddleableContainer() {
//            private final SlotAccess slotAccess = abstractHorse.getSlot(400);
//
//            @Override
//            public Saddleable saddleable() {
//                return abstractHorse;
//            }
//
//            @Override
//            public ItemStack getSaddle() {
//                return this.slotAccess.get();
//            }
//
//            @Override
//            public ItemStack removeSaddle() {
//                this.slotAccess.set(ItemStack.EMPTY);
//
//                return this.slotAccess.get().copy();
//            }
//        };
    }

    static Inventory ofSaddleable(Saddleable saddleable) {
        return new SlotAccessContainer(
                StackReference.of(
                        () -> saddleable.isSaddled() ? Items.SADDLE.getDefaultStack() : ItemStack.EMPTY,
                        stack -> saddleable.saddle(stack, SoundCategory.NEUTRAL)
                )
        );

//        return new SaddleableContainer() {
//            @Override
//            public Saddleable saddleable() {
//                return saddleable;
//            }
//
//            @Override
//            public ItemStack getSaddle() {
//                return saddleable.isSaddled() ? Items.SADDLE.getDefaultInstance() : ItemStack.EMPTY;
//            }
//
//            @Override
//            public ItemStack removeSaddle() {
//                saddleable.equipSaddle(ItemStack.EMPTY, null);
//
//                return ItemStack.EMPTY;
//            }
//        };
    }

    Saddleable saddleable();

    ItemStack getSaddle();

    ItemStack removeSaddle();

    @Override
    default int size() {
        return 1;
    }

    @Override
    default boolean isEmpty() {
        return getStack(0).isEmpty();
    }

    @Override
    default ItemStack getStack(int slot) {
        return getSaddle();
    }

    @Override
    default ItemStack removeStack(int slot, int amount) {
        if(amount <= 0) return ItemStack.EMPTY;

        return removeSaddle();
    }

    @Override
    default ItemStack removeStack(int slot) {
        return removeSaddle();
    }

    @Override
    default void setStack(int slot, ItemStack stack) {
        saddleable().saddle(stack, SoundCategory.NEUTRAL);
    }

    @Override
    default void markDirty() {}

    @Override
    default boolean canPlayerUse(PlayerEntity player) {
        return true;
    }

    @Override
    default void clear() {}
}
