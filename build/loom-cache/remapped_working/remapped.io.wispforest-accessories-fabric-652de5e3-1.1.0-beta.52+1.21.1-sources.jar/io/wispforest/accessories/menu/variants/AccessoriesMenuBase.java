package io.wispforest.accessories.menu.variants;

import I;
import io.wispforest.accessories.menu.AccessoriesMenuVariant;
import io.wispforest.accessories.mixin.CraftingMenuAccessor;
import io.wispforest.accessories.networking.AccessoriesNetworking;
import io.wispforest.accessories.networking.server.ScreenOpen;
import io.wispforest.endec.StructEndec;
import it.unimi.dsi.fastutil.Pair;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.CraftingInventory;
import net.minecraft.inventory.CraftingResultInventory;
import net.minecraft.inventory.Inventory;
import net.minecraft.inventory.RecipeInputInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.recipe.CraftingRecipe;
import net.minecraft.recipe.RecipeEntry;
import net.minecraft.recipe.RecipeMatcher;
import net.minecraft.recipe.book.RecipeBookCategory;
import net.minecraft.recipe.input.CraftingRecipeInput;
import net.minecraft.screen.AbstractRecipeScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.slot.CraftingResultSlot;
import net.minecraft.screen.slot.Slot;
import net.minecraft.world.inventory.*;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public abstract class AccessoriesMenuBase extends AbstractRecipeScreenHandler<CraftingRecipeInput, CraftingRecipe> {

    @Nullable protected final RecipeInputInventory craftSlots;
    @Nullable protected final CraftingResultInventory resultSlots = new CraftingResultInventory();

    protected final PlayerEntity owner;

    @Nullable
    protected final LivingEntity targetEntity;

    protected boolean sendCarriedStackToInventory = false;

    protected int slotAmountAdded = -1;
    protected boolean isValid = true;

    protected AccessoriesMenuBase(ScreenHandlerType<? extends AccessoriesMenuBase> menuType, int containerId, PlayerInventory inventory, @Nullable LivingEntity targetEntity) {
        super(menuType, containerId);

        this.owner = inventory.player;
        this.targetEntity = targetEntity;

        if (this instanceof AccessoriesExperimentalMenu) {
            this.craftSlots = new CraftingInventory(this, 2, 2);

            this.addSlot(new CraftingResultSlot(inventory.player, this.craftSlots, this.resultSlots, 0, 154, 28));

            for (int y = 0; y < 2; ++y) {
                for (int x = 0; x < 2; ++x) {
                    this.addSlot(new Slot(this.craftSlots, x + y * 2, 98 + x * 18, 18 + y * 18));
                }
            }
        } else {
            this.craftSlots = new CraftingInventory(this, 0, 0);
        }

        this.addServerboundMessage(SetTransferFlag.class, StructEndec.unit(SetTransferFlag::new), setTransferFlag -> {
            this.sendCarriedStackToInventory = true;
        });
    }

    public final AccessoriesMenuVariant menuVariant() {
        return AccessoriesMenuVariant.getVariant((ScreenHandlerType<? extends AccessoriesMenuBase>) this.getType());
    }

    @Nullable
    public final LivingEntity targetEntity() {
        return this.targetEntity;
    }

    public final PlayerEntity owner() {
        return this.owner;
    }

    public final void reopenMenu() {
        AccessoriesNetworking.sendToServer(ScreenOpen.of(this.targetEntity(), this.menuVariant()));
    }

    public void transferAndClose(Runnable setupCall) {
        this.sendMessage(new SetTransferFlag());

        setupCall.run();

        this.player().method_7346();
    }

    public int slotAmountAdded() {
        return slotAmountAdded;
    }

    public AccessoriesMenuBase isSyncedWithServer(int serverSlotAmountAdded) {
        this.isValid = slotAmountAdded == serverSlotAmountAdded;

        return this;
    }

    public boolean isValidMenu() {
        return this.isValid;
    }

    @Override
    public void updateSlotStacks(int stateId, List<ItemStack> items, ItemStack carried) {
        if (!this.isValidMenu()) return;

        super.updateSlotStacks(stateId, items, carried);
    }

    //--

    @Nullable
    public Pair<ItemStack, ItemStack> quickMoveStackCrafting(int index) {
        var slot = this.slots.get(index);

        if (slot.hasStack()) {
            var itemStack2 = slot.getStack();
            var itemStack = itemStack2.copy();

            var endIndex = 5 + (4 * 9);

            if (index == 0) {
                if (!this.insertItem(itemStack2, 5, endIndex, true)) return Pair.of(ItemStack.EMPTY, null);

                slot.onQuickTransfer(itemStack2, itemStack);
            } else if (index >= 1 && index < 5) {
                if (!this.insertItem(itemStack2, 5, endIndex, false)) return Pair.of(ItemStack.EMPTY, null);
            }

            if (itemStack2.getCount() == itemStack.getCount()) return null;

            return Pair.of(itemStack, itemStack2);
        }

        return null;
    }

    public void populateRecipeFinder(RecipeMatcher itemHelper) {
        this.craftSlots.provideRecipeInputs(itemHelper);
    }

    public void clearCraftingSlots() {
        this.resultSlots.clear();
        this.craftSlots.clear();
    }

    public boolean matches(RecipeEntry<CraftingRecipe> recipe) {
        return recipe.value().matches(this.craftSlots.createRecipeInput(), this.owner.getWorld());
    }

    public void onContentChanged(Inventory container) {
        CraftingMenuAccessor.accessories$slotChangedCraftingGrid(this, this.owner.getWorld(), this.owner, this.craftSlots, this.resultSlots, (RecipeEntry) null);
    }

    public void onClosed(PlayerEntity player) {
        if (player.playerScreenHandler.getCursorStack().isEmpty() && this.sendCarriedStackToInventory) {
            player.playerScreenHandler.setCursorStack(this.getCursorStack());
            this.setCursorStack(ItemStack.EMPTY);
        }

        super.onClosed(player);
        this.resultSlots.clear();
        if (!player.getWorld().isClient) {
            this.dropInventory(player, this.craftSlots);
        }
    }

    public boolean canInsertIntoSlot(ItemStack stack, Slot slot) {
        return slot.inventory != this.resultSlots && super.canInsertIntoSlot(stack, slot);
    }

    public int getCraftingResultSlotIndex() {
        return -1;
    }

    public int getCraftingWidth() {
        return this.craftSlots.getWidth();
    }

    public int getCraftingHeight() {
        return this.craftSlots.getHeight();
    }

    public int getCraftingSlotCount() {
        return this.craftSlots.getWidth() * this.craftSlots.getHeight() + 1;
    }

    public RecipeBookCategory getCategory() {
        return RecipeBookCategory.CRAFTING;
    }

    public boolean canInsertIntoSlot(int slotIndex) {
        return slotIndex != this.getCraftingResultSlotIndex();
    }

    private record SetTransferFlag() {}
}
