package io.wispforest.accessories.mixin.client;

import io.wispforest.accessories.Accessories;
import io.wispforest.accessories.api.AccessoriesCapability;
import io.wispforest.accessories.api.AccessoriesContainer;
import io.wispforest.accessories.api.client.AccessoriesRendererRegistry;
import io.wispforest.accessories.api.client.AccessoryRenderer;
import io.wispforest.accessories.api.client.EmptyRenderer;
import io.wispforest.accessories.api.slot.SlotReference;
import io.wispforest.accessories.client.AccessoryRendererErrorCache;
import io.wispforest.accessories.impl.ExpandedSimpleContainer;
import java.util.Map.Entry;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

@Mixin(PlayerEntityRenderer.class)
public abstract class PlayerRendererMixin {

    @Shadow public abstract void render(AbstractClientPlayerEntity entity, float entityYaw, float partialTicks, MatrixStack poseStack, VertexConsumerProvider buffer, int packedLight);

    @Unique
    private static Arm currentArm = null;

//    @WrapWithCondition(method = "renderHand", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/model/geom/ModelPart;render(Lcom/mojang/blaze3d/vertex/PoseStack;Lcom/mojang/blaze3d/vertex/VertexConsumer;II)V"))
//    private boolean accessories$fixOverridenInvisibility(ModelPart instance, PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay) {
//        var returned = AccessoriesClient.IS_PLAYER_INVISIBLE;
//        AccessoriesClient.IS_PLAYER_INVISIBLE = false;
//        return returned;
//    }

    @Inject(method = "renderHand", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/model/geom/ModelPart;render(Lcom/mojang/blaze3d/vertex/PoseStack;Lcom/mojang/blaze3d/vertex/VertexConsumer;II)V", ordinal = 1, shift = At.Shift.AFTER), locals = LocalCapture.CAPTURE_FAILHARD)
    private void accessories$firstPersonAccessories(MatrixStack poseStack, VertexConsumerProvider buffer, int combinedLight, AbstractClientPlayerEntity player, ModelPart rendererArm, ModelPart rendererArmwear, CallbackInfo ci, PlayerEntityModel playerModel, Identifier resourceLocation) {
        if (currentArm != null) {
            var capability = AccessoriesCapability.get(player);

            if (capability == null) return;

            for (var entry : capability.getContainers().entrySet()) {
                var container = entry.getValue();

                var accessories = container.getAccessories();
                var cosmetics = container.getCosmeticAccessories();

                for (int i = 0; i < accessories.size(); i++) {
                    var stack = accessories.getStack(i);
                    var cosmeticStack = cosmetics.getStack(i);

                    if (!cosmeticStack.isEmpty() && Accessories.config().clientOptions.showCosmeticAccessories()) stack = cosmeticStack;

                    if (stack.isEmpty()) continue;

                    var renderer = AccessoriesRendererRegistry.getRenderer(stack);

                    if(renderer.isEmpty() || !renderer.shouldRender(container.shouldRender(i))) continue;

                    poseStack.push();

                    try {
                        renderer.renderOnFirstPerson(
                                currentArm,
                                stack,
                                SlotReference.of(player, container.getSlotName(), i),
                                poseStack,
                                playerModel,
                                buffer,
                                combinedLight
                        );
                    } catch (Throwable e) {
                        AccessoryRendererErrorCache.logIfTimeAllotted(player, stack, renderer, e);
                    }

                    poseStack.pop();
                }
            }
        }
        currentArm = null;
    }

    @Inject(method = "renderRightHand", at = @At("HEAD"))
    private void accessories$firstPersonRightAccessories(MatrixStack poseStack, VertexConsumerProvider buffer, int combinedLight, AbstractClientPlayerEntity player, CallbackInfo ci) {
        currentArm = Arm.RIGHT;
    }

    @Inject(method = "renderLeftHand", at = @At("HEAD"))
    private void accessories$firstPersonLeftAccessories(MatrixStack poseStack, VertexConsumerProvider buffer, int combinedLight, AbstractClientPlayerEntity player, CallbackInfo ci) {
        currentArm = Arm.LEFT;
    }
}