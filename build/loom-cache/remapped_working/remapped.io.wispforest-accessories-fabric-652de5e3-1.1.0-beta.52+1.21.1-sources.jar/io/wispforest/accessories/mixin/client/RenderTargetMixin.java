package io.wispforest.accessories.mixin.client;

import io.wispforest.accessories.client.AccessoriesClient;
import io.wispforest.accessories.pond.AccessoriesFrameBufferExtension;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gl.ShaderProgram;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(Framebuffer.class)
public abstract class RenderTargetMixin implements AccessoriesFrameBufferExtension {

    @Unique
    private boolean useHighlightShader = false;

    @ModifyVariable(method = "_blitToScreen", at = @At(value = "CONSTANT", args = "stringValue=DiffuseSampler", shift = At.Shift.BEFORE))
    private ShaderProgram gliscoLikesShaders(ShaderProgram value) {
        if (this.useHighlightShader) return AccessoriesClient.BLIT_SHADER;
        return value;
    }

    @Override
    public void accessories$setUseHighlightShader(boolean useHighlightShader) {
        this.useHighlightShader = useHighlightShader;
    }
}
