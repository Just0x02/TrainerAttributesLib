package io.wispforest.accessories.mixin;

import class_9692;
import com.mojang.datafixers.util.Pair;
import io.wispforest.accessories.pond.ArmorSlotExtension;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_9692.class)
public abstract class ArmorSlotMixin implements ArmorSlotExtension {

    @Shadow
    @Final
    @Nullable
    private Identifier emptyIcon;

    @Nullable
    private Identifier accessories$atlasLocation = null;

    @Override
    public class_9692 setAtlasLocation(Identifier atlasLocation) {
        this.accessories$atlasLocation = atlasLocation;

        return (class_9692)(Object)this;
    }

    @Override
    @Nullable
    public Identifier getAtlasLocation() {
        return accessories$atlasLocation;
    }

    @Inject(method = "getNoItemIcon", at = @At(value = "HEAD"), cancellable = true)
    private void accessories$useAlternativeAtlas(CallbackInfoReturnable<Pair<Identifier, Identifier>> cir) {
        if(accessories$atlasLocation == null) return;

        cir.setReturnValue(Pair.of(accessories$atlasLocation, this.emptyIcon));
    }
}
