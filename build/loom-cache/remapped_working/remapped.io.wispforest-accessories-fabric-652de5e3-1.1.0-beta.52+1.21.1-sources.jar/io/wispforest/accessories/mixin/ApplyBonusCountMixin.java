package io.wispforest.accessories.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import io.wispforest.accessories.api.events.extra.ExtraEventHandler;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.loot.context.LootContext;
import net.minecraft.loot.function.ApplyBonusLootFunction;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Mixin(ApplyBonusLootFunction.class)
public abstract class ApplyBonusCountMixin {

    @Shadow @Final private RegistryEntry<Enchantment> enchantment;

    @ModifyArg(method = "run", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/storage/loot/functions/ApplyBonusCount$Formula;calculateNewCount(Lnet/minecraft/util/RandomSource;II)I"), index = 2)
    private int test(int value, @Local(argsOnly = true) LootContext context){
        return (this.enchantment.value() == context.getWorld().getRegistryManager().getOptional(RegistryKeys.ENCHANTMENT).orElseThrow().entryOf(Enchantments.FORTUNE).value())
                ? ExtraEventHandler.fortuneAdjustment(context, value)
                : value;
    }
}
