package io.wispforest.accessories.mixin;

import com.google.common.collect.HashMultimap;
import io.wispforest.accessories.AccessoriesInternals;
import net.minecraft.enchantment.effect.AttributeEnchantmentEffect;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.registry.entry.RegistryEntry;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(AttributeEnchantmentEffect.class)
public abstract class EnchantmentAttributeEffectMixin {

    @Inject(method = "makeAttributeMap", at = @At("HEAD"), cancellable = true)
    private void returnEmptyIfAccessoriesSlot(int i, EquipmentSlot equipmentSlot, CallbackInfoReturnable<HashMultimap<RegistryEntry<EntityAttribute>, EntityAttributeModifier>> cir) {
        if(equipmentSlot.equals(AccessoriesInternals.INTERNAL_SLOT)) cir.setReturnValue(HashMultimap.create());
    }
}
