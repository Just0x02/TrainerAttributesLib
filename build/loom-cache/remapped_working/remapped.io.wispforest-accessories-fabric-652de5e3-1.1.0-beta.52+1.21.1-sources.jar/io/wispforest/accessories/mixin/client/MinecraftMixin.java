package io.wispforest.accessories.mixin.client;

import io.wispforest.accessories.client.AccessoriesClient;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.function.Function;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.util.Window;
import net.minecraft.util.Identifier;

@Mixin(MinecraftClient.class)
public abstract class MinecraftMixin {
    @Shadow @Final private Window window;

    @Inject(method = "resizeDisplay", at = @At(value = "TAIL"))
    private void captureResize(CallbackInfo ci){
        AccessoriesClient.WINDOW_RESIZE_CALLBACK_EVENT.invoker().onResized(((MinecraftClient) ((Object) this)), this.window);
    }

    @Unique
    private static final Identifier SPRITE_ATLAS_LOCATION = Identifier.ofVanilla("textures/atlas/gui.png");

    @Inject(method = "getTextureAtlas", at = @At(value = "HEAD"), cancellable = true)
    private void allowForGuiSprites(Identifier location, CallbackInfoReturnable<Function<Identifier, Sprite>> cir) {
        if(location.equals(SPRITE_ATLAS_LOCATION)) {
            cir.setReturnValue(MinecraftClient.getInstance().getGuiAtlasManager()::getSprite);
        }
    }
}