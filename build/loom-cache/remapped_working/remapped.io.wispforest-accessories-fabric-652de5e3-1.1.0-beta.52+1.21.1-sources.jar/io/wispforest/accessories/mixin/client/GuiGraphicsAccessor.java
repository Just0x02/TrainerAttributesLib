package io.wispforest.accessories.mixin.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.texture.Sprite;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(DrawContext.class)
public interface GuiGraphicsAccessor {
    @Invoker("blitSprite") void callBlitSprite(Sprite sprite, int x, int y, int blitOffset, int width, int height);
}
