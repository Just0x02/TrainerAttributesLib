package io.wispforest.accessories.mixin;

import com.mojang.serialization.MapCodec;
import net.minecraft.state.State;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(State.class)
public interface StateHolderAccessor<O, S> {
    @Accessor("owner")
    O accessories$owner();
    
    @Accessor("propertiesCodec")
    MapCodec<S> accessories$propertiesCodec();
}
