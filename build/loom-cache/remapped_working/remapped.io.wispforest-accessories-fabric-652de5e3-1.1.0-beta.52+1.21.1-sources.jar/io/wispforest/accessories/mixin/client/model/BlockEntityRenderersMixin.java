package io.wispforest.accessories.mixin.client.model;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import io.wispforest.accessories.pond.ModelPartLoadingHelper;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.render.block.entity.BlockEntityRenderer;
import net.minecraft.client.render.block.entity.BlockEntityRendererFactories;
import net.minecraft.client.render.block.entity.BlockEntityRendererFactory;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(BlockEntityRendererFactories.class)
public abstract class BlockEntityRenderersMixin {

    @WrapOperation(method = "method_32145", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/blockentity/BlockEntityRendererProvider;create(Lnet/minecraft/client/renderer/blockentity/BlockEntityRendererProvider$Context;)Lnet/minecraft/client/renderer/blockentity/BlockEntityRenderer;"))
    private static <T extends BlockEntity> BlockEntityRenderer<T> accessories$attemptToSaveRoot(BlockEntityRendererFactory<T> instance, BlockEntityRendererFactory.Context context, Operation<BlockEntityRenderer<T>> original) {
        var renderer = original.call(instance, context);

        // Attempts to clear queue in case issues with saving root model part goes wrong
        ((ModelPartLoadingHelper) context.getLayerRenderDispatcher()).accessories$clearQueue();

        return renderer;
    }
}
