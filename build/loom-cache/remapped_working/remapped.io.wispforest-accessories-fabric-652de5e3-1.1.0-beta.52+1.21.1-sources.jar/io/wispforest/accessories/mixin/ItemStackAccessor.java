package io.wispforest.accessories.mixin;

import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

import java.util.function.Consumer;
import net.minecraft.component.ComponentMapImpl;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.text.Text;

@Mixin(ItemStack.class)
public interface ItemStackAccessor {
    @Invoker("addModifierTooltip")
    void accessories$addModifierTooltip(Consumer<Text> consumer, @Nullable PlayerEntity player, RegistryEntry<EntityAttribute> holder, EntityAttributeModifier attributeModifier);

    @Accessor("components")
    ComponentMapImpl accessories$components();
}
