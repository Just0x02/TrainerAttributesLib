package io.wispforest.accessories.mixin;

import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.server.DataPackContents;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(DataPackContents.ConfigurableWrapperLookup.class)
public interface ConfigurableRegistryLookupAccessor {
    @Accessor("registryAccess")
    DynamicRegistryManager getRegistryAccess();
}
