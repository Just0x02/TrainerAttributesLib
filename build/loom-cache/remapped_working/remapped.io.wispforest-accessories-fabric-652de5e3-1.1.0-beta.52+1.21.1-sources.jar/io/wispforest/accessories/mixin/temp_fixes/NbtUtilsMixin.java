package io.wispforest.accessories.mixin.temp_fixes;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ;
import java.util.UUID;
import net.minecraft.nbt.AbstractNbtNumber;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtHelper;
import net.minecraft.nbt.NbtList;
import net.minecraft.util.Uuids;

// TODO: REMOVE IN THE FUTURE 1.21.5?
@Mixin(NbtHelper.class)
public abstract class NbtUtilsMixin {
    @Inject(method = "loadUUID", at = @At(value = "HEAD"), cancellable = true)
    private static void adjustLoadToAllowListVariant(NbtElement tag, CallbackInfoReturnable<UUID> cir) {
        if(tag instanceof NbtList listTag && listTag.getHeldType() == NbtElement.INT_TYPE) {
            if(listTag.size() != 4) {
                throw new IllegalArgumentException("Expected UUID-Array to be of length 4, but found " + listTag.size() + ".");
            }

            var array = new int[listTag.size()];

            for (int i = 0; i < listTag.size(); i++) {
                var tagEntry = listTag.get(i);

                array[i] = ((AbstractNbtNumber) tagEntry).intValue();
            }

            cir.setReturnValue(Uuids.toUuid(array));
        }
    }
}
