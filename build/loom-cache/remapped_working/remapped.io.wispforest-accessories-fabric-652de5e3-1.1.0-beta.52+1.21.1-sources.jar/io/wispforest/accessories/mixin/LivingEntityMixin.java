package io.wispforest.accessories.mixin;

import Z;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import com.llamalad7.mixinextras.sugar.Share;
import com.llamalad7.mixinextras.sugar.ref.LocalRef;
import io.wispforest.accessories.AccessoriesInternals;
import io.wispforest.accessories.api.AccessoriesAPI;
import io.wispforest.accessories.api.AccessoriesCapability;
import io.wispforest.accessories.api.AccessoriesHolder;
import io.wispforest.accessories.api.SoundEventData;
import io.wispforest.accessories.api.events.extra.ExtraEventHandler;
import io.wispforest.accessories.api.slot.SlotReference;
import io.wispforest.accessories.data.EntitySlotLoader;
import io.wispforest.accessories.impl.AccessoriesCapabilityImpl;
import io.wispforest.accessories.pond.AccessoriesAPIAccess;
import io.wispforest.accessories.pond.AccessoriesLivingEntityExtension;
import java.util.Map;
import net.fabricmc.fabric.api.util.TriState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import net.minecraft.world.event.GameEvent;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin extends Entity implements AccessoriesAPIAccess, AccessoriesLivingEntityExtension {

    @Unique
    private AccessoriesCapabilityImpl capability = null;

    protected LivingEntityMixin(EntityType<?> entityType, World level) {
        super(entityType, level);
    }

    @Unique
    private AccessoriesCapability getOrCreateAccessoriesCapability() {
        if (capability == null) {
            this.capability = new AccessoriesCapabilityImpl((LivingEntity) (Object) this);
        }

        return capability;
    }

    @Override
    @Nullable
    public AccessoriesCapability accessoriesCapability() {
        var slots = EntitySlotLoader.getEntitySlots((LivingEntity) (Object) this);

        if(slots.isEmpty()) return null;

        var capability = getOrCreateAccessoriesCapability();

        // Used to init some functions behind the scene
        capability.getHolder();

        return capability;
    }

    @Override
    @Nullable
    public AccessoriesHolder accessoriesHolder() {
        var capability = getOrCreateAccessoriesCapability();

        return capability != null ? capability.getHolder() : null;
    }

    //--

    @Inject(method = "onEquippedItemBroken", at = @At("HEAD"), cancellable = true)
    private void sendAccessoriesBreakInstead(Item item, EquipmentSlot slot, CallbackInfo ci){
        if(slot.equals(AccessoriesInternals.INTERNAL_SLOT)) ci.cancel();
    }

    @Inject(method = "entityEventForEquipmentBreak", at = @At("HEAD"), cancellable = true)
    private static void preventMatchExceptionForAccessories(EquipmentSlot slot, CallbackInfoReturnable<Byte> cir) {
        if(slot.equals(AccessoriesInternals.INTERNAL_SLOT)) cir.setReturnValue((byte) -1);
    }

    public void onEquipItem(SlotReference slotReference, ItemStack oldItem, ItemStack newItem) {
        var level = this.getWorld();

        if (!ItemStack.areItemsAndComponentsEqual(oldItem, newItem) && !this.firstUpdate && !level.isClient() && !this.isSpectator()) {
            var isEquitableFor = newItem.isEmpty() || AccessoriesAPI.canInsertIntoSlot(newItem, slotReference);

            if (!this.isSilent() && !newItem.isEmpty()) {
                var sound = AccessoriesAPI.getOrDefaultAccessory(newItem).getEquipSound(newItem, slotReference);

                if(sound != null) level.playSound(null, this.getX(), this.getY(), this.getZ(), sound.event().value(), this.getSoundCategory(), sound.volume(), sound.pitch(), this.random.nextLong());
            }

            if (isEquitableFor) this.emitGameEvent(!newItem.isEmpty() ? GameEvent.EQUIP : GameEvent.UNEQUIP);
        }
    }

    //--

    @ModifyReturnValue(method = "canFreeze", at = @At(value = "RETURN", ordinal = 1))
    private boolean canFreezeAccessoriesCheck(boolean bl) {
        var state = ExtraEventHandler.canFreezeEntity((LivingEntity) (Object) this);

        return state.orElse(bl);
    }

//    @WrapOperation(method = "getDamageAfterMagicAbsorb", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/LivingEntity;getArmorAndBodyArmorSlots()Ljava/lang/Iterable;"))
//    private Iterable<ItemStack> addAccessories(LivingEntity instance, Operation<Iterable<ItemStack>> original){
//        var iterable = original.call(instance);
//
//        if((Object) this instanceof LivingEntity livingEntity) {
//            var capability = livingEntity.accessoriesCapability();
//
//            if(capability != null) iterable = Iterables.concat(iterable, capability.getAllEquipped().stream().map(SlotEntryReference::stack).toList());
//        }
//
//        return iterable;
//    }

    // TODO: SEEM IF THIS IS STILL SOMETHING TO HAVE WITHIN THE FUTURE! BUGS OCCUR THOUGH WITH INV HUD+
//    @ModifyReturnValue(method = "getAllSlots", at = @At("RETURN"))
//    private Iterable<ItemStack> addAccessories(Iterable<ItemStack> original){
//        if((Object) this instanceof LivingEntity livingEntity && !livingEntity.isRemoved()) {
//            var capability = livingEntity.accessoriesCapability();
//
//            if(capability != null) return Iterables.concat(original, capability.getAllEquipped().stream().map(SlotEntryReference::stack).toList());
//        }
//
//        return original;
//    }
}
