package io.wispforest.accessories.mixin;

import Z;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import io.wispforest.accessories.pond.stack.PatchedDataComponentMapExtension;
import io.wispforest.accessories.utils.ItemStackMutation;
import io.wispforest.owo.util.EventStream;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.component.ComponentChanges;
import net.minecraft.component.ComponentMapImpl;
import net.minecraft.component.ComponentType;
import net.minecraft.item.ItemStack;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

@Mixin(ComponentMapImpl.class)
public abstract class PatchedDataComponentMapMixin implements PatchedDataComponentMapExtension {

    @Unique
    private boolean changeCheckStack = false;

    @Nullable
    private ItemStack itemStack = null;

    @Nullable
    private EventStream<ItemStackMutation> mutationEvent = null;

    @Override
    public EventStream<ItemStackMutation> accessories$getMutationEvent(ItemStack itemStack) {
        Objects.requireNonNull(itemStack);

        this.itemStack = itemStack;

        if (mutationEvent == null) {
            mutationEvent = new EventStream<>(invokers -> (stack, types) -> {
                invokers.forEach(itemStackMutation -> itemStackMutation.onMutation(stack, types));
            });
        }

        return mutationEvent;
    }

    @Override
    public boolean accessories$hasChanged() {
        var bl = changeCheckStack;

        this.changeCheckStack = false;

        return bl;
    }

    @Inject(method = "set", at = @At("HEAD"))
    private <T> void accessories$updateChangeValue_set(ComponentType<? super T> component, @Nullable T value, CallbackInfoReturnable<T> cir){
        this.changeCheckStack = true;

        this.accessories$handleMutationEvent(List.of(component));
    }

    @Inject(method = "remove", at = @At("HEAD"))
    private <T> void accessories$updateChangeValue_remove(ComponentType<? super T> component, CallbackInfoReturnable<T> cir){
        this.changeCheckStack = true;

        this.accessories$handleMutationEvent(List.of(component));
    }

    @Unique
    private boolean inApplyPatchLock = false;

    @Inject(method = "applyPatch(Lnet/minecraft/core/component/DataComponentPatch;)V", at = @At("HEAD"))
    private void accessories$updateChangeValue_applyPatchHead(ComponentChanges patch, CallbackInfo ci){
        this.changeCheckStack = true;

        this.inApplyPatchLock = true;
    }

    @Inject(method = "applyPatch(Lnet/minecraft/core/component/DataComponentPatch;)V", at = @At("TAIL"))
    private void accessories$updateChangeValue_applyPatchTail(ComponentChanges patch, CallbackInfo ci){
        this.inApplyPatchLock = false;

        var changedDataTypes = (List<ComponentType<?>>) (List) patch.entrySet().stream().map(Map.Entry::getKey).toList();

        this.accessories$handleMutationEvent(changedDataTypes);
    }

    @Inject(method = "applyPatch(Lnet/minecraft/core/component/DataComponentType;Ljava/util/Optional;)V", at = @At("HEAD"))
    private void accessories$updateChangeValue_applyPatch(ComponentType<?> component, Optional<?> value, CallbackInfo ci){
        this.changeCheckStack = true;

        if (!this.inApplyPatchLock) {
            this.accessories$handleMutationEvent(List.of(component));
        }
    }

    @Inject(method = "restorePatch", at = @At("HEAD"))
    private void accessories$updateChangeValue_restorePatch(ComponentChanges patch, CallbackInfo ci){
        this.changeCheckStack = true;

        var changedDataTypes = (List<ComponentType<?>>) (List) patch.entrySet().stream().map(Map.Entry::getKey).toList();

        this.accessories$handleMutationEvent(changedDataTypes);
    }

    @Unique
    private void accessories$handleMutationEvent(List<ComponentType<?>> changedDataTypes) {
        if(this.mutationEvent == null) return;

        this.mutationEvent.sink().onMutation(this.itemStack, changedDataTypes);
    }
}
