package io.wispforest.accessories.mixin.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.List;
import java.util.Map;
import net.minecraft.client.model.ModelPart;

@Mixin(ModelPart.class)
public interface ModelPartAccessor {
    @Accessor("cubes") List<ModelPart.Cuboid> getCubes();

    @Accessor("children") Map<String, ModelPart> getChildren();
}
