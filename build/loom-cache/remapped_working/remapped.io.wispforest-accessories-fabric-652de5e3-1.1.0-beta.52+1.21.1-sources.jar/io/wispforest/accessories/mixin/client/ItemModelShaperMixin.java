package io.wispforest.accessories.mixin.client;

import io.wispforest.accessories.api.components.AccessoriesDataComponents;
import net.minecraft.client.render.item.ItemModels;
import net.minecraft.client.render.model.BakedModel;
import net.minecraft.client.render.model.BakedModelManager;
import net.minecraft.client.util.ModelIdentifier;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ItemModels.class)
public abstract class ItemModelShaperMixin {
    @Shadow @Final private BakedModelManager modelManager;

    @Inject(method = "getItemModel(Lnet/minecraft/world/item/ItemStack;)Lnet/minecraft/client/resources/model/BakedModel;", at = @At("HEAD"), cancellable = true)
    private void accessories$adjustModelFromComponent(ItemStack stack, CallbackInfoReturnable<BakedModel> cir) {
        if (!stack.contains(AccessoriesDataComponents.ITEM_MODEL_OVERRIDE)) return;

        var model = this.modelManager.getModel(ModelIdentifier.ofInventoryVariant(stack.get(AccessoriesDataComponents.ITEM_MODEL_OVERRIDE).id()));

        cir.setReturnValue(model);
    }
}
