package io.wispforest.accessories.mixin;

import io.wispforest.accessories.pond.DroppedStacksExtension;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

import java.util.Collection;
import java.util.List;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;

@Mixin(PlayerEntity.class)
public abstract class PlayerMixin implements DroppedStacksExtension {

    @Unique
    private Collection<ItemStack> toBeDroppedStacks = List.of();

    @Override
    public void addToBeDroppedStacks(Collection<ItemStack> list) {
        this.toBeDroppedStacks = list;
    }

    @Override
    public Collection<ItemStack> toBeDroppedStacks() {
        return this.toBeDroppedStacks;
    }
}
