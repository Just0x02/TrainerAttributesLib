package io.wispforest.accessories.mixin;

import io.wispforest.accessories.pond.ItemBasedSteerable;
import net.minecraft.entity.SaddledComponent;
import net.minecraft.entity.passive.StriderEntity;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(StriderEntity.class)
public abstract class StriderMixin implements ItemBasedSteerable {

    @Shadow
    @Final
    private SaddledComponent steering;

    @Override
    public SaddledComponent getInstance() {
        return steering;
    }
}
