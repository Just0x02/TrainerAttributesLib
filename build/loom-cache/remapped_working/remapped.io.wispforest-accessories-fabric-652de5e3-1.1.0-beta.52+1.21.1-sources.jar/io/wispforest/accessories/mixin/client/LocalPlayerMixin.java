package io.wispforest.accessories.mixin.client;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import io.wispforest.accessories.pond.CloseContainerTransfer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(ClientPlayerEntity.class)
public abstract class LocalPlayerMixin implements CloseContainerTransfer {

    @Unique
    private Screen transferedScreen = null;

    @WrapOperation(method = "clientSideCloseContainer", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/Minecraft;setScreen(Lnet/minecraft/client/gui/screens/Screen;)V"))
    private void test(MinecraftClient instance, Screen screen, Operation<Void> original) {
        original.call(instance, transferedScreen != null ? transferedScreen : screen);

        this.transferedScreen = null;
    }

    @Override
    public void accessories$setScreenTransfer(Screen screen) {
        this.transferedScreen = screen;
    }
}
