package io.wispforest.accessories;

import com.google.common.collect.Multimap;
import com.google.gson.JsonObject;
import com.mojang.brigadier.arguments.ArgumentType;
import dev.architectury.injectables.annotations.ExpectPlatform;
import io.wispforest.accessories.api.AccessoriesHolder;
import io.wispforest.accessories.menu.AccessoriesMenuVariant;
import io.wispforest.accessories.utils.ManagedEndecDataLoader;
import io.wispforest.endec.Endec;
import org.apache.commons.lang3.function.TriFunction;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;
import java.util.Optional;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.UnaryOperator;
import net.minecraft.command.argument.serialize.ArgumentSerializer;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/**
 * Util Class implemented though Architectury Plugin allowing for various access to platform specific way
 * of getting class instances
 */
@ApiStatus.Internal
public class AccessoriesInternals {

    @Nullable
    public static EquipmentSlot INTERNAL_SLOT = null;

    @Nullable
    public static EquipmentSlot.Type ACCESSORIES_TYPE = null;

    /**
     * @return {@link AccessoriesHolder} attached to a given {@link LivingEntity} based on the Platforms method for getting it
     */
    @ExpectPlatform
    public static AccessoriesHolder getHolder(LivingEntity livingEntity) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void modifyHolder(LivingEntity livingEntity, UnaryOperator<AccessoriesHolder> modifier) {
        throw new AssertionError();
    }

    //--

    @ExpectPlatform
    public static <T> Optional<Collection<RegistryEntry<T>>> getHolder(TagKey<T> tagKey) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void giveItemToPlayer(ServerPlayerEntity player, ItemStack stack) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static boolean isValidOnConditions(JsonObject object, String dataType, Identifier key, @Nullable RegistryWrapper.WrapperLookup registryLookup) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static <T extends ScreenHandler, D> ScreenHandlerType<T> registerMenuType(Identifier location, Endec<D> endec, TriFunction<Integer, PlayerInventory, D, T> func) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static <A extends ArgumentType<?>, T extends ArgumentSerializer.ArgumentTypeProperties<A>, I extends ArgumentSerializer<A, T>> I registerCommandArgumentType(Identifier location, Class<A> clazz, I info) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void openAccessoriesMenu(PlayerEntity player, AccessoriesMenuVariant variant, @Nullable LivingEntity targetEntity, @Nullable ItemStack carriedStack) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void addAttributeTooltips(@Nullable PlayerEntity player, ItemStack stack, Multimap<RegistryEntry<EntityAttribute>, EntityAttributeModifier> multimap, Consumer<Text> tooltipAddCallback, Item.TooltipContext context, TooltipType flag) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void registerLoader(ManagedEndecDataLoader<?> loader, Consumer<RegistryWrapper.WrapperLookup> registrySetCall) {
        throw new AssertionError();
    }
}
