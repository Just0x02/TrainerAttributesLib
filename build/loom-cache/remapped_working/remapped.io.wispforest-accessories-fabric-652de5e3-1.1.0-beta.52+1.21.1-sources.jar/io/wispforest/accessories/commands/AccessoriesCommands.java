package io.wispforest.accessories.commands;

import I;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.LiteralMessage;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.Dynamic3CommandExceptionType;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import com.mojang.logging.LogUtils;
import io.wispforest.accessories.Accessories;
import io.wispforest.accessories.AccessoriesInternals;
import io.wispforest.accessories.api.client.rendering.CustomDataRenderer;
import io.wispforest.accessories.api.components.*;
import io.wispforest.accessories.api.slot.SlotGroup;
import io.wispforest.accessories.api.slot.SlotType;
import io.wispforest.accessories.data.CustomRendererLoader;
import io.wispforest.accessories.data.EntitySlotLoader;
import io.wispforest.accessories.data.SlotGroupLoader;
import io.wispforest.accessories.data.SlotTypeLoader;
import org.apache.commons.lang3.mutable.MutableBoolean;
import org.slf4j.Logger;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.command.CommandRegistryAccess;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.command.argument.IdentifierArgumentType;
import net.minecraft.command.argument.ItemStackArgumentType;
import net.minecraft.command.argument.TextArgumentType;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class AccessoriesCommands {

    public static final SimpleCommandExceptionType NON_LIVING_ENTITY_TARGET = new SimpleCommandExceptionType(Text.translatable("argument.livingEntities.nonLiving"));

    public static final SimpleCommandExceptionType INVALID_SLOT_TYPE = new SimpleCommandExceptionType(new LiteralMessage("Invalid Slot Type"));

    public static final Logger LOGGER = LogUtils.getLogger();

    public static void registerCommandArgTypes() {
        AccessoriesInternals.registerCommandArgumentType(Accessories.of("slot_type"), SlotArgumentType.class, RecordArgumentTypeInfo.of(ctx -> SlotArgumentType.INSTANCE));
        AccessoriesInternals.registerCommandArgumentType(Accessories.of("resource"), ResourceExtendedArgument.class, RecordArgumentTypeInfo.of(ResourceExtendedArgument::attributes));
    }

    public static LivingEntity getOrThrowLivingEntity(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        var entity = EntityArgumentType.getEntity(ctx, "entity");

        if(!(entity instanceof LivingEntity livingEntity)) {
            throw NON_LIVING_ENTITY_TARGET.create();
        }

        return livingEntity;
    }

    //accessories edit {}
    public static void registerCommands(CommandDispatcher<ServerCommandSource> dispatcher, CommandRegistryAccess context) {
        var base = CommandManager.literal("accessories")
                .requires(commandSourceStack -> commandSourceStack.hasPermissionLevel(CommandManager.field_31839));

        if (Accessories.DEBUG) {
            base.then(
                    CommandManager.literal("create-renderer-stack")
                            .then(
                                    CommandManager.argument("custom_name", TextArgumentType.text(context))
                                            .then(
                                                    CommandManager.argument("renderer_id", IdentifierArgumentType.identifier())
                                                            .then(
                                                                    CommandManager.argument("item_model_id", IdentifierArgumentType.identifier())
                                                                            .then(
                                                                                    CommandManager.argument("is_bundle", BoolArgumentType.bool())
                                                                                            .executes(AccessoriesCommands::createRenderStack)
                                                                            )
                                                                            .executes(AccessoriesCommands::createRenderStack)
                                                            )
                                            )
                            )
            ).then(
                    CommandManager.literal("listen-to-renderer")
                            .then(
                                    CommandManager.argument("id", IdentifierArgumentType.identifier())
                                            .executes(ctx -> {
                                                var id = ctx.getArgument("id", Identifier.class);

                                                CustomRendererLoader.constantFileResolving(ctx.getSource().getServer(), id);

                                                return 1;
                                            })
                            )
                            .executes(ctx -> {
                                CustomRendererLoader.constantFileResolving(ctx.getSource().getServer(), null);

                                return 1;
                            })

            );
        }

        dispatcher.register(
                base
                        .then(
                                CommandManager.literal("edit")
                                        .then(
                                                CommandManager.argument("entity", EntityArgumentType.entity())
                                                        .executes((ctx) -> {
                                                            Accessories.askPlayerForVariant(ctx.getSource().getPlayerOrThrow(), getOrThrowLivingEntity(ctx));

                                                            return 1;
                                                        })
                                        )
                                        .executes(ctx -> {
                                            Accessories.askPlayerForVariant(ctx.getSource().getPlayerOrThrow());


                                            return 1;
                                        })
                        )
                        .then(
                                CommandManager.literal("nest")
                                        .then(
                                                CommandManager.argument("item", ItemStackArgumentType.itemStack(context))
                                                        .executes((ctx) -> {
                                                            var player = ctx.getSource().getPlayerOrThrow();

                                                            var stack = player.getMainHandStack();

                                                            var innerStack = ItemStackArgumentType.getItemStackArgument(ctx, "item").createStack(1, false);

                                                            stack.apply(
                                                                    AccessoriesDataComponents.NESTED_ACCESSORIES,
                                                                    AccessoryNestContainerContents.EMPTY,
                                                                    data -> data.addStack(innerStack));

                                                            return 1;
                                                        })
                                        )
                        )
                        .then(
                                CommandManager.literal("slot")
                                        .then(
                                                CommandManager.literal("add")
                                                        .then(
                                                                CommandManager.literal("valid")
                                                                        .then(CommandManager.argument("slot", SlotArgumentType.INSTANCE)
                                                                                .executes(ctx -> adjustSlotValidationOnStack(0, ctx.getSource().getPlayerOrThrow(), ctx))
                                                                        ))
                                                        .then(
                                                                CommandManager.literal("invalid")
                                                                        .then(CommandManager.argument("slot", SlotArgumentType.INSTANCE)
                                                                                .executes(ctx -> adjustSlotValidationOnStack(1, ctx.getSource().getPlayerOrThrow(), ctx))
                                                                        ))

                                        ).then(
                                                CommandManager.literal("remove")
                                                        .then(
                                                                CommandManager.literal("valid")
                                                                        .then(CommandManager.argument("slot", SlotArgumentType.INSTANCE)
                                                                                .executes(ctx -> adjustSlotValidationOnStack(2, ctx.getSource().getPlayerOrThrow(), ctx))
                                                                        ))
                                                        .then(
                                                                CommandManager.literal("invalid")
                                                                        .then(CommandManager.argument("slot", SlotArgumentType.INSTANCE)
                                                                                .executes(ctx -> adjustSlotValidationOnStack(3, ctx.getSource().getPlayerOrThrow(), ctx))
                                                                        ))
                                        )
                        )
                        .then(
                                CommandManager.literal("stack-sizing")
                                        .then(
                                                CommandManager.literal("useStackSize")
                                                        .then(
                                                                CommandManager.argument("value", BoolArgumentType.bool())
                                                                        .executes(ctx -> {
                                                                            var player = ctx.getSource().getPlayerOrThrow();

                                                                            var bl = ctx.getArgument("value", Boolean.class);

                                                                            player.getMainHandStack().apply(AccessoriesDataComponents.STACK_SIZE,
                                                                                    AccessoryStackSizeComponent.DEFAULT,
                                                                                    component -> component.useStackSize(bl));

                                                                            return 1;
                                                                        })
                                                        )
                                        ).then(
                                                CommandManager.argument("value", IntegerArgumentType.integer())
                                                        .executes(ctx -> {
                                                            var player = ctx.getSource().getPlayerOrThrow();

                                                            var size = ctx.getArgument("value", Integer.class);

                                                            player.getMainHandStack().apply(AccessoriesDataComponents.STACK_SIZE,
                                                                    AccessoryStackSizeComponent.DEFAULT,
                                                                    component -> component.sizeOverride(size));

                                                            return 1;
                                                        })
                                        )
                        )
                        .then(
                                CommandManager.literal("attribute")
                                        .then(
                                                CommandManager.literal("modifier")
                                                        .then(
                                                                CommandManager.literal("add")
                                                                        .then(
                                                                                CommandManager.argument("attribute", ResourceExtendedArgument.attributes(context))
                                                                                        .then(
                                                                                                CommandManager.argument("id", IdentifierArgumentType.identifier())
                                                                                                        .then(CommandManager.argument("value", DoubleArgumentType.doubleArg())
                                                                                                                        .then(createAddLiteral("add_value"))
                                                                                                                        .then(createAddLiteral("add_multiplied_base"))
                                                                                                                        .then(createAddLiteral("add_multiplied_total"))
                                                                                                        )
                                                                                        )
                                                                        )
                                                        )
                                                        .then(
                                                                CommandManager.literal("remove")
                                                                        .then(
                                                                                CommandManager.argument("attribute", ResourceExtendedArgument.attributes(context))
                                                                                        .then(
                                                                                                CommandManager.argument("id", IdentifierArgumentType.identifier())
                                                                                                        .executes(
                                                                                                                ctx -> removeModifier(
                                                                                                                        ctx.getSource(),
                                                                                                                        ctx.getSource().getPlayerOrThrow(),
                                                                                                                        ResourceExtendedArgument.getAttribute(ctx, "attribute"),
                                                                                                                        IdentifierArgumentType.getIdentifier(ctx, "id")
                                                                                                                )
                                                                                                        )
                                                                                        )
                                                                        )
                                                        )
                                                        .then(
                                                                CommandManager.literal("get")
                                                                        .then(
                                                                                CommandManager.argument("attribute", ResourceExtendedArgument.attributes(context))
                                                                                        .then(
                                                                                                CommandManager.argument("id", IdentifierArgumentType.identifier())
                                                                                                        .executes(
                                                                                                                ctx -> getAttributeModifier(
                                                                                                                        ctx.getSource(),
                                                                                                                        ctx.getSource().getPlayerOrThrow(),
                                                                                                                        ResourceExtendedArgument.getAttribute(ctx, "attribute"),
                                                                                                                        IdentifierArgumentType.getIdentifier(ctx, "id"),
                                                                                                                        1.0
                                                                                                                )
                                                                                                        )
                                                                                                        .then(
                                                                                                                CommandManager.argument("scale", DoubleArgumentType.doubleArg())
                                                                                                                        .executes(
                                                                                                                                ctx -> getAttributeModifier(
                                                                                                                                        ctx.getSource(),
                                                                                                                                        ctx.getSource().getPlayerOrThrow(),
                                                                                                                                        ResourceExtendedArgument.getAttribute(ctx, "attribute"),
                                                                                                                                        IdentifierArgumentType.getIdentifier(ctx, "id"),
                                                                                                                                        DoubleArgumentType.getDouble(ctx, "scale")
                                                                                                                                )
                                                                                                                        )
                                                                                                        )
                                                                                        )
                                                                        )
                                                        )
                                        )
                        ).then(
                                CommandManager.literal("log")
                                        .then(
                                                CommandManager.literal("slots")
                                                        .executes(ctx -> {
                                                            LOGGER.info("All given Slots registered:");

                                                            for (var slotType : SlotTypeLoader.getSlotTypes(ctx.getSource().getWorld()).values()) {
                                                                LOGGER.info(slotType.toString());
                                                            }

                                                            return 1;
                                                        })
                                        )
                                        .then(
                                                CommandManager.literal("groups")
                                                        .executes(ctx -> {
                                                            LOGGER.info("All given Slot Groups registered:");

                                                            for (var group : SlotGroupLoader.getGroups(ctx.getSource().getWorld())) {
                                                                LOGGER.info(group.toString());
                                                            }

                                                            return 1;
                                                        })
                                        )
                                        .then(
                                                CommandManager.literal("entity_bindings")
                                                        .executes(ctx -> {
                                                            LOGGER.info("All given Entity Bindings registered:");

                                                            EntitySlotLoader.INSTANCE.getEntitySlotData(false).forEach((type, slots) -> {
                                                                LOGGER.info("[{}]: {}", type, slots.keySet());
                                                            });

                                                            return 1;
                                                        })
                                        )
                        )
        );
    }

    private static LiteralArgumentBuilder<ServerCommandSource> createAddLiteral(String literal) {
        var selectedValue = Arrays.stream(EntityAttributeModifier.Operation.values())
                .filter(value -> value.asString().equals(literal))
                .findFirst()
                .orElse(null);

        if(selectedValue == null) throw new IllegalStateException("Unable to handle the given literal as its not a valid AttributeModifier Operation! [Literal: " + literal + "]");

        return CommandManager.literal(literal)
                .then(
                        CommandManager.argument("slot", SlotArgumentType.INSTANCE)
                                .then(
                                        CommandManager.argument("isStackable", BoolArgumentType.bool())
                                                .executes(
                                                        ctx -> addModifier(
                                                                ctx.getSource(),
                                                                ctx.getSource().getPlayerOrThrow(),
                                                                ResourceExtendedArgument.getAttribute(ctx, "attribute"),
                                                                IdentifierArgumentType.getIdentifier(ctx, "id"),
                                                                DoubleArgumentType.getDouble(ctx, "value"),
                                                                selectedValue,
                                                                SlotArgumentType.getSlot(ctx, "slot"),
                                                                BoolArgumentType.getBool(ctx, "isStackable")
                                                        )
                                                )
                                )
                );
    }

    private static int getAttributeModifier(ServerCommandSource commandSourceStack, LivingEntity livingEntity, RegistryEntry<EntityAttribute> holder, Identifier resourceLocation, double d) throws CommandSyntaxException {
        var stack = livingEntity.getMainHandStack();

        var component = stack.getOrDefault(AccessoriesDataComponents.ATTRIBUTES, AccessoryItemAttributeModifiers.EMPTY);

        var modifier = component.getModifier(holder, resourceLocation);

        if (modifier == null) {
            throw ERROR_NO_SUCH_MODIFIER.create(stack.toHoverableText(), getAttributeDescription(holder), resourceLocation);
        }

        double e = modifier.value();

        commandSourceStack.sendFeedback(
                () -> Text.translatable(
                        "commands.attribute.modifier.value.get.success_itemstack", Text.of(resourceLocation), getAttributeDescription(holder), stack.toHoverableText(), e
                ),
                false
        );

        return (int)(e * d);
    }

    private static final Dynamic3CommandExceptionType ERROR_MODIFIER_ALREADY_PRESENT = new Dynamic3CommandExceptionType(
            (var1, var2, var3) -> Text.stringifiedTranslatable("commands.attribute.failed.modifier_already_present_itemstack", var1, var2, var3)
    );

    private static int addModifier(ServerCommandSource commandSourceStack, LivingEntity livingEntity, RegistryEntry<EntityAttribute> holder, Identifier resourceLocation, double d, EntityAttributeModifier.Operation operation, String slotName, boolean isStackable) throws CommandSyntaxException {
        var stack = livingEntity.getMainHandStack();

        var component = stack.getOrDefault(AccessoriesDataComponents.ATTRIBUTES, AccessoryItemAttributeModifiers.EMPTY);

        if (component.hasModifier(holder, resourceLocation)) {
            throw ERROR_MODIFIER_ALREADY_PRESENT.create(resourceLocation, getAttributeDescription(holder), stack.toHoverableText());
        }

        stack.set(AccessoriesDataComponents.ATTRIBUTES, component.withModifierAdded(holder, new EntityAttributeModifier(resourceLocation, d, operation), slotName, isStackable));

        commandSourceStack.sendFeedback(
                () -> Text.translatable(
                        "commands.attribute.modifier.add.success_itemstack", Text.of(resourceLocation), getAttributeDescription(holder), stack.toHoverableText()
                ),
                false
        );

        return 1;
    }

    private static final Dynamic3CommandExceptionType ERROR_NO_SUCH_MODIFIER = new Dynamic3CommandExceptionType(
            (var1, var2, var3) -> Text.stringifiedTranslatable("commands.attribute.failed.no_modifier_itemstack", var1, var2, var3)
    );

    private static int removeModifier(ServerCommandSource commandSourceStack, LivingEntity livingEntity, RegistryEntry<EntityAttribute> holder, Identifier location) throws CommandSyntaxException {
        MutableBoolean removedModifier = new MutableBoolean(false);

        var stack = livingEntity.getMainHandStack();

        stack.apply(AccessoriesDataComponents.ATTRIBUTES, AccessoryItemAttributeModifiers.EMPTY, component -> {
            var size = component.modifiers().size();

            component = component.withoutModifier(holder, location);

            if(size != component.modifiers().size()) removedModifier.setTrue();

            return component;
        });

        if(!removedModifier.getValue()) {
            throw ERROR_NO_SUCH_MODIFIER.create(location, getAttributeDescription(holder), stack.toHoverableText());
        }

        commandSourceStack.sendFeedback(
                () -> Text.translatable(
                        "commands.attribute.modifier.remove.success_itemstack", Text.of(location), getAttributeDescription(holder), stack.toHoverableText()
                ),
                false
        );

        return 1;
    }

    private static Text getAttributeDescription(RegistryEntry<EntityAttribute> attribute) {
        return Text.translatable(attribute.value().getTranslationKey());
    }

    private static int adjustSlotValidationOnStack(int operation, LivingEntity player, CommandContext<ServerCommandSource> ctx) {
        var slotName = SlotArgumentType.getSlot(ctx, "slot");

        player.getMainHandStack().apply(AccessoriesDataComponents.SLOT_VALIDATION, AccessorySlotValidationComponent.EMPTY, component -> {
            return switch (operation) {
                case 0 -> component.addValidSlot(slotName);
                case 1 -> component.addInvalidSlot(slotName);
                case 2 -> component.removeValidSlot(slotName);
                case 3 -> component.removeInvalidSlot(slotName);
                default -> throw new IllegalStateException("Unexpected value: " + operation);
            };
        });

        return 1;
    }

    private static int createRenderStack(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        var rendererId = ctx.getArgument("renderer_id", Identifier.class);
        var modelId = ctx.getArgument("item_model_id", Identifier.class);
        var component = TextArgumentType.getTextArgument(ctx, "custom_name");

        Item item = Items.STICK;

        try {
            if (ctx.getArgument("is_bundle", Boolean.class)) item = Items.BUNDLE;
        } catch (Throwable ignored) {}

        var itemStack = item.getDefaultStack();

        itemStack.set(DataComponentTypes.ITEM_NAME, component);

        itemStack.set(
                AccessoriesDataComponents.CUSTOM_RENDERER,
                new AccessoryCustomRendererComponent(List.of(
                        new CustomDataRenderer(rendererId, Map.of(), List.of(), null)))
        );

        itemStack.set(
                AccessoriesDataComponents.ITEM_MODEL_OVERRIDE,
                new AccessoryItemCosmeticOverride(modelId)
        );

        itemStack.set(
                AccessoriesDataComponents.SLOT_VALIDATION,
                new AccessorySlotValidationComponent(Set.of("any"), Set.of())
        );

        ctx.getSource().getPlayerOrThrow()
                .giveItemStack(itemStack);

        return 1;
    }

}
