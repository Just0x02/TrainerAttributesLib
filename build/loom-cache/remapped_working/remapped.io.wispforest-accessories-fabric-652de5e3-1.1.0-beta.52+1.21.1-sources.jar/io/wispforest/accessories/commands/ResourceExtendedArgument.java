package io.wispforest.accessories.commands;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.Dynamic2CommandExceptionType;
import com.mojang.brigadier.exceptions.Dynamic3CommandExceptionType;
import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import io.wispforest.accessories.Accessories;
import io.wispforest.accessories.api.attributes.SlotAttribute;
import io.wispforest.accessories.api.slot.SlotType;
import io.wispforest.accessories.data.SlotTypeLoader;
import org.jetbrains.annotations.Nullable;

import java.util.Arrays;
import java.util.Collection;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Stream;
import net.minecraft.command.CommandRegistryAccess;
import net.minecraft.command.CommandSource;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class ResourceExtendedArgument<T> implements ArgumentType<RegistryEntry<T>> {

    private static final Collection<String> EXAMPLES = Arrays.asList("foo", "foo:bar", "012");

    private static final DynamicCommandExceptionType ERROR_NOT_SUMMONABLE_ENTITY = new DynamicCommandExceptionType(
            object -> Text.stringifiedTranslatable("entity.not_summonable", object)
    );
    public static final Dynamic2CommandExceptionType ERROR_UNKNOWN_RESOURCE = new Dynamic2CommandExceptionType(
            (object, object2) -> Text.stringifiedTranslatable("argument.resource.not_found", object, object2)
    );
    public static final Dynamic3CommandExceptionType ERROR_INVALID_RESOURCE_TYPE = new Dynamic3CommandExceptionType(
            (object, object2, object3) -> Text.stringifiedTranslatable("argument.resource.invalid_type", object, object2, object3)
    );

    final RegistryKey<? extends Registry<T>> registryKey;
    private final RegistryWrapper<T> registryLookup;

    private final Function<Identifier, @Nullable RegistryEntry<T>> additionalLookup;
    private final Supplier<Stream<Identifier>> additionalSuggestions;

    public ResourceExtendedArgument(CommandRegistryAccess context, RegistryKey<? extends Registry<T>> registryKey, Function<Identifier, @Nullable RegistryEntry<T>> additionalLookup, Supplier<Stream<Identifier>> additionalSuggestions) {
        this.registryKey = registryKey;
        this.registryLookup = context.getWrapperOrThrow(registryKey);

        this.additionalLookup = additionalLookup;
        this.additionalSuggestions = additionalSuggestions;
    }

    public static <T> ResourceExtendedArgument<T> resource(CommandRegistryAccess context, RegistryKey<? extends Registry<T>> registryKey, Function<Identifier, @Nullable RegistryEntry<T>> additionalLookup, Supplier<Stream<Identifier>> additionalSuggestions) {
        return new ResourceExtendedArgument<>(context, registryKey, additionalLookup, additionalSuggestions);
    }

    public static ResourceExtendedArgument<EntityAttribute> attributes(CommandRegistryAccess context) {
        return new ResourceExtendedArgument<>(context, RegistryKeys.ATTRIBUTE, location -> {
            String possibleSlotName;

            if (location.getNamespace().equals(Accessories.MODID)) {
                possibleSlotName = location.getPath();
            } else {
                possibleSlotName = location.toString();
            }

            var slotType = SlotTypeLoader.INSTANCE.getSlotTypes(false).get(possibleSlotName);

            return (slotType != null) ? SlotAttribute.getAttributeHolder(possibleSlotName) : null;
        }, () -> {
            return SlotTypeLoader.INSTANCE.getSlotTypes(false).values()
                    .stream()
                    .map(SlotType::name)
                    .map(s -> s.contains(":") ? Identifier.of(s) : Accessories.of(s));
        });
    }

    public static RegistryEntry<EntityAttribute> getAttribute(CommandContext<ServerCommandSource> commandContext, String string){
        return getResource(commandContext, string);
    }

    public static <T> RegistryEntry<T> getResource(CommandContext<ServerCommandSource> context, String argument){
        return (RegistryEntry<T>) context.getArgument(argument, RegistryEntry.class);
    }

    public RegistryEntry<T> parse(StringReader builder) throws CommandSyntaxException {
        Identifier resourceLocation = Identifier.fromCommandInput(builder);
        RegistryKey<T> resourceKey = RegistryKey.of(this.registryKey, resourceLocation);

        var entry = this.registryLookup.getOptional(resourceKey)
                .map(tReference -> (RegistryEntry<T>) tReference)
                .or(() -> Optional.ofNullable(this.additionalLookup.apply(resourceLocation)));

        return entry.orElseThrow(() -> ERROR_UNKNOWN_RESOURCE.createWithContext(builder, resourceLocation, this.registryKey.getValue()));
    }

    @Override
    public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> commandContext, SuggestionsBuilder suggestionsBuilder) {
        var registryKeys = this.registryLookup.streamKeys().map(RegistryKey::getValue);
        var extraEntries = this.additionalSuggestions.get();

        return CommandSource.suggestIdentifiers(Stream.concat(registryKeys, extraEntries), suggestionsBuilder);
    }

    @Override
    public Collection<String> getExamples() {
        return EXAMPLES;
    }
}
