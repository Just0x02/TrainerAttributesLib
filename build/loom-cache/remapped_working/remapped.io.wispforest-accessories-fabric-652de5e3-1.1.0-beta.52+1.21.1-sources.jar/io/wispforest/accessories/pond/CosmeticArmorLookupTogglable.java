package io.wispforest.accessories.pond;

import io.wispforest.accessories.menu.ArmorSlotTypes;
import java.util.function.Consumer;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;

public interface CosmeticArmorLookupTogglable {
    default void setLookupToggle(boolean value) {
        throw new IllegalStateException("Interface injected method not implemented!");
    }

    default boolean getLookupToggle() {
        throw new IllegalStateException("Interface injected method not implemented!");
    }

    static void getAlternativeStack(LivingEntity livingEntity, EquipmentSlot equipmentSlot, Consumer<ItemStack> consumer) {
        if(!((CosmeticArmorLookupTogglable)livingEntity).getLookupToggle()) return;

        var cosmetic = ArmorSlotTypes.getAlternativeStack(livingEntity, equipmentSlot);

        if(cosmetic == null) return;

        consumer.accept(cosmetic);
    }
}
