package io.wispforest.accessories.pond;

import class_9692;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.Nullable;

public interface ArmorSlotExtension {

    default class_9692 setAtlasLocation(Identifier atlasLocation) {
        throw new IllegalStateException("Extension method not implemented!");
    }

    @Nullable
    default Identifier getAtlasLocation(){
        throw new IllegalStateException("Extension method not implemented!");
    }
}
