package io.wispforest.accessories.pond;

import java.util.Collection;
import net.minecraft.item.ItemStack;

public interface DroppedStacksExtension {
    void addToBeDroppedStacks(Collection<ItemStack> list);

    Collection<ItemStack> toBeDroppedStacks();
}
