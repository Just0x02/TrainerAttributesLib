package io.wispforest.accessories.pond;

import io.wispforest.accessories.api.slot.SlotReference;
import net.minecraft.item.ItemStack;

public interface AccessoriesLivingEntityExtension {
    void onEquipItem(SlotReference slotReference, ItemStack oldItem, ItemStack newItem);
}
