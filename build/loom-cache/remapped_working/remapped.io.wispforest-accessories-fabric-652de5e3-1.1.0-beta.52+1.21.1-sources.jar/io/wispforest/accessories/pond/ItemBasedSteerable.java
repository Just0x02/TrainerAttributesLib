package io.wispforest.accessories.pond;

import net.minecraft.entity.Saddleable;
import net.minecraft.entity.SaddledComponent;

public interface ItemBasedSteerable extends Saddleable {
    SaddledComponent getInstance();
}
