package io.wispforest.accessories.data;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.mojang.logging.LogUtils;
import io.wispforest.accessories.AccessoriesInternals;
import io.wispforest.accessories.api.slot.ExtraSlotTypeProperties;
import io.wispforest.accessories.api.slot.SlotType;
import io.wispforest.accessories.api.slot.UniqueSlotHandling;
import io.wispforest.accessories.impl.AccessoriesCapabilityImpl;
import it.unimi.dsi.fastutil.Pair;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;

import java.util.*;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.resource.ResourceManager;
import net.minecraft.util.Identifier;
import net.minecraft.util.JsonHelper;
import net.minecraft.util.profiler.Profiler;
import net.minecraft.world.World;

/**
 * Resource Reload in which handles the loading of {@link SlotType}'s bindings
 * to the targeted {@link EntityType} though a {@link TagKey} or {@link Identifier}
 */
public class EntitySlotLoader extends ReplaceableJsonResourceReloadListener {

    private static final Logger LOGGER = LogUtils.getLogger();
    private static final Gson GSON = new GsonBuilder().setLenient().setPrettyPrinting().create();

    public static final EntitySlotLoader INSTANCE = new EntitySlotLoader();

    private SequencedMap<EntityType<?>, SequencedMap<String, SlotType>> server = new LinkedHashMap<>();
    private SequencedMap<EntityType<?>, SequencedMap<String, SlotType>> client = new LinkedHashMap<>();

    protected EntitySlotLoader() {
        super(GSON, LOGGER, "accessories/entity");
    }

    //--

    /**
     * @return The valid {@link SlotType}'s for given {@link LivingEntity} based on its {@link EntityType}
     */
    public static Map<String, SlotType> getEntitySlots(LivingEntity livingEntity){
        return getEntitySlots(livingEntity.getWorld(), livingEntity.getType());
    }

    /**
     * @return The valid {@link SlotType}'s for given {@link EntityType}
     */
    public static Map<String, SlotType> getEntitySlots(World level, EntityType<?> entityType){
        var map = EntitySlotLoader.INSTANCE.getSlotTypes(level.isClient, entityType);

        return map != null ? map : Map.of();
    }

    //--

    @Nullable
    public final Map<String, SlotType> getSlotTypes(boolean isClientSide, EntityType<?> entityType){
        return this.getEntitySlotData(isClientSide).get(entityType);
    }

    @ApiStatus.Internal
    public final Map<EntityType<?>, Map<String, SlotType>> getEntitySlotData(boolean isClientSide){
        return (Map) (isClientSide ? this.client : this.server);
    }

    @ApiStatus.Internal
    public final void setEntitySlotData(SequencedMap<EntityType<?>, SequencedMap<String, SlotType>> data){
        this.client = Collections.unmodifiableSequencedMap(data);

        AccessoriesCapabilityImpl.clearValidationCache(true);
    }

    //--

    @Override
    protected void apply(Map<Identifier, JsonObject> data, ResourceManager resourceManager, Profiler profiler) {
        var allSlotTypes = SlotTypeLoader.INSTANCE.getSlotTypes(false);

        var tempMap = new LinkedHashMap<EntityType<?>, SequencedMap<String, SlotType>>();

        for (var resourceEntry : data.entrySet()) {
            var location = resourceEntry.getKey();
            var jsonObject = resourceEntry.getValue();

            if(!AccessoriesInternals.isValidOnConditions(jsonObject, this.directory, location, null)) continue;

            var slots = new LinkedHashMap<String, SlotType>();

            var slotElements = this.safeHelper(JsonHelper::getArray, jsonObject, "slots", new JsonArray(), location);

            this.decodeJsonArray(slotElements, "slot", location, element -> {
                var slotName = element.getAsString();

                return Pair.of(slotName, allSlotTypes.get(slotName));
            }, slotInfo -> {
                var slotType = slotInfo.right();

                if(slotType != null) {
                    if(!ExtraSlotTypeProperties.getProperty(slotInfo.left(), false).strictMode()) {
                        slots.put(slotType.name(), slotType);
                    } else {
                        LOGGER.warn("Unable to add the given slot to the given group due to it being in strict mode! [Slot: {}]", slotInfo.left());
                    }
                } else if (slotType == null) {
                    LOGGER.warn("Unable to locate a given slot to add to a given entity('s) as it was not registered: [Slot: {}]", slotInfo.first());
                }
            });

            //--

            var entities = new ArrayList<EntityType<?>>();

            var entityElements = this.safeHelper(JsonHelper::getArray, jsonObject, "entities", new JsonArray(), location);

            this.decodeJsonArray(entityElements, "entity", location, element -> {
                var string = element.getAsString();

                if(string.contains("#")){
                    var entityTypeTagLocation = Identifier.tryParse(string.replace("#", ""));

                    var entityTypeTag = TagKey.of(RegistryKeys.ENTITY_TYPE, entityTypeTagLocation);

                    return AccessoriesInternals.getHolder(entityTypeTag)
                            .map(holders -> holders.stream().map(RegistryEntry::value).collect(Collectors.toSet()))
                            .orElseGet(() -> {
                                LOGGER.warn("[EntitySlotLoader]: Unable to locate the given EntityType Tag used within a slot entry: [Location: {}]", string);
                                return Set.of();
                            });
                } else {
                    return Optional.ofNullable(Identifier.tryParse(string))
                            .map(location1 -> Registries.ENTITY_TYPE.getOrEmpty(location1).map(Set::of).orElse(Set.of()))
                            .orElseGet(() -> {
                                LOGGER.warn("[EntitySlotLoader]: Unable to locate the given EntityType within the registries for a slot entry: [Location: {}]", string);
                                return Set.of();
                            });
                }
            }, entities::addAll);

            for (EntityType<?> entityType : entities) {
                tempMap.computeIfAbsent(entityType, entityType1 -> new LinkedHashMap<>())
                        .putAll(slots);
            }
        }

        for (var entry : UniqueSlotHandling.getSlotToEntities().entrySet()) {
            var slotType = SlotTypeLoader.INSTANCE.getSlotTypes(false).get(entry.getKey());

            for (var entityType : entry.getValue()) {
                tempMap.computeIfAbsent(entityType, entityType1 -> new LinkedHashMap<>())
                        .put(slotType.name(), slotType);
            }
        }

        this.server = Collections.unmodifiableSequencedMap(tempMap);

        AccessoriesCapabilityImpl.clearValidationCache(false);
    }
}
