package io.wispforest.accessories.data;

import ;
import Z;
import com.google.gson.*;
import com.mojang.logging.LogUtils;
import io.wispforest.accessories.AccessoriesInternals;
import io.wispforest.accessories.api.slot.SlotGroup;
import io.wispforest.accessories.api.slot.SlotType;
import io.wispforest.accessories.api.slot.UniqueSlotHandling;
import io.wispforest.accessories.impl.SlotGroupImpl;
import io.wispforest.accessories.utils.CollectionUtils;
import org.jetbrains.annotations.ApiStatus;
import org.slf4j.Logger;

import java.util.*;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import net.minecraft.entity.LivingEntity;
import net.minecraft.resource.ResourceManager;
import net.minecraft.util.Identifier;
import net.minecraft.util.JsonHelper;
import net.minecraft.util.profiler.Profiler;
import net.minecraft.world.World;

public class SlotGroupLoader extends ReplaceableJsonResourceReloadListener {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().setLenient().create();
    private static final Logger LOGGER = LogUtils.getLogger();

    public static final SlotGroupLoader INSTANCE = new SlotGroupLoader();

    private SequencedMap<String, SlotGroup> server = new LinkedHashMap<>();
    private SequencedMap<String, SlotGroup> client = new LinkedHashMap<>();

    protected SlotGroupLoader() {
        super(GSON, LOGGER, "accessories/group");
    }

    //--

    public static List<SlotGroup> getGroups(World level){
        return INSTANCE.getGroups(level.isClient(), true);
    }

    public static List<SlotGroup> getGroups(World level, boolean filterUniqueGroups){
        return INSTANCE.getGroups(level.isClient(), filterUniqueGroups);
    }

    public static Map<SlotGroup, List<SlotType>> getValidGroups(LivingEntity living) {
        var entitySpecificSlots = EntitySlotLoader.getEntitySlots(living);

        var groups = SlotGroupLoader.getGroups(living.getWorld(), false);

        return groups.stream()
                .map(slotGroup -> {
                    if(UniqueSlotHandling.isUniqueGroup(slotGroup.name(), living.getWorld().isClient())) return null;

                    var slots = slotGroup.slots()
                            .stream()
                            .filter(entitySpecificSlots::containsKey)
                            .map(slot -> SlotTypeLoader.getSlotType(living.getWorld(), slot))
                            .toList();

                    return slots.isEmpty() ? null : Map.entry(slotGroup, slots);
                })
                .filter(Objects::nonNull)
                .collect(CollectionUtils.toLinkedMap());
    }

    public static Optional<SlotGroup> getGroup(World level, String group){
        return Optional.ofNullable(INSTANCE.getGroup(level.isClient(), group));
    }

    //--

    @ApiStatus.Internal
    public final Map<String, SlotGroup> getGroupMap(boolean isClientSide) {
        return (isClientSide ? this.client : this.server);
    }

    public final List<SlotGroup> getGroups(boolean isClientSide, boolean filterUniqueGroups){
        var groups = getGroupMap(isClientSide).values();

        if(filterUniqueGroups) groups = groups.stream().filter(group -> !UniqueSlotHandling.isUniqueGroup(group.name(), isClientSide)).toList();

        return List.copyOf(groups);
    }

    public final SlotGroup getGroup(boolean isClientSide, String group){
        return getGroupMap(isClientSide).get(group);
    }

    public final Optional<SlotGroup> findGroup(boolean isClientSide, String slot){
        for (var entry : getGroups(isClientSide, false)) {
            if(entry.slots().contains(slot)) return Optional.of(entry);
        }

        return Optional.empty();
    }

    public final SlotGroup getOrDefaultGroup(boolean isClientSide, String slot){
        var groups = getGroupMap(isClientSide);

        for (var entry : groups.values()) {
            if(entry.slots().contains(slot)) return entry;
        }

        return groups.get("any");
    }

    @ApiStatus.Internal
    public final void setGroups(SequencedMap<String, SlotGroup> groups){
        this.client = Collections.unmodifiableSequencedMap(groups);
    }

    @Override
    protected void apply(Map<Identifier, JsonObject> data, ResourceManager resourceManager, Profiler profiler) {
        var slotGroups = new HashMap<String, SlotGroupBuilder>();

        slotGroups.put("unsorted", new SlotGroupBuilder("unsorted").order(30));

        var allSlots = new HashMap<>(SlotTypeLoader.INSTANCE.getSlotTypes(false));

        for (var resourceEntry : data.entrySet()) {
            var location = resourceEntry.getKey();
            var jsonObject = resourceEntry.getValue();

            if(!AccessoriesInternals.isValidOnConditions(jsonObject, this.directory, location, null)) continue;

            var pathParts = location.getPath().split("/");

            String groupName = pathParts[pathParts.length - 1];
            String namespace = pathParts.length > 1 ? pathParts[0] + ":" : "";

            var isShared = namespace.isBlank();

            if(!isShared) groupName = namespace + ":" + groupName;

            var group = slotGroups.computeIfAbsent(groupName, SlotGroupBuilder::new);

            if(isShared) {
                var slotElements = safeHelper(JsonHelper::getArray, jsonObject, "slots", new JsonArray(), location);

                decodeJsonArray(slotElements, "slot", location, JsonElement::getAsString, s -> {
                    for (var builderEntry : slotGroups.entrySet()) {
                        if (builderEntry.getValue().slots.contains(s)) {
                            LOGGER.error("Unable to assign a give slot [{}] to the group [{}] as it already exists within the group [{}]", s, group, builderEntry.getKey());
                            return;
                        }
                    }

                    var slotType = allSlots.remove(s);

                    if (slotType == null) {
                        LOGGER.warn("SlotType added to a given group without being in the main map for slots! [Name: {}]", s);
                    } else {
                        group.addSlot(slotType);
                    }
                });

                group.order(safeHelper(JsonHelper::getInt, jsonObject, "order", 100, location));
            }

            var icon = safeHelper(JsonHelper::getString, jsonObject, "icon", location);

            if(icon != null){
                var iconLocation = Identifier.tryParse(icon);

                if(iconLocation != null){
                    group.icon(iconLocation);
                } else {
                    LOGGER.warn("A given SlotGroup was found to have a invalid Icon Location. [Location: {}]", location);
                }
            }
        }

        var remainSlots = new HashSet<SlotType>();

        for (var value : allSlots.values()) {
            var slotName = value.name();

            if(!UniqueSlotHandling.isUniqueSlot(slotName)) {
                remainSlots.add(value);

                continue;
            }

            var group = slotName.split(":")[0];

            slotGroups.computeIfAbsent(group, SlotGroupBuilder::new)
                    .order(5)
                    .addSlot(value);

            UniqueSlotHandling.addGroup(group);
        }

        slotGroups.get("unsorted").addSlots(remainSlots);

        var tempMap = new HashMap<String, SlotGroup>();

        slotGroups.forEach((s, builder) -> tempMap.put(s, builder.build()));

        this.server = Collections.unmodifiableSequencedMap(
            tempMap.entrySet().stream()
                .sorted(Map.Entry.<String, SlotGroup>comparingByValue().reversed())
                .collect(CollectionUtils.toLinkedMap())
        );
    }

    public static class SlotGroupBuilder {
        private final String name;

        private Integer order = null;
        private final Set<SlotType> slots = new HashSet<>();

        private Identifier iconLocation = SlotGroup.UNKNOWN;

        public SlotGroupBuilder(String name){
            this.name = name;
        }

        public SlotGroupBuilder order(Integer value){
            this.order = value;

            return this;
        }

        public SlotGroupBuilder addSlot(SlotType value){
            this.slots.add(value);

            return this;
        }

        public SlotGroupBuilder addSlots(Collection<SlotType> values){
            this.slots.addAll(values);

            return this;
        }

        public SlotGroupBuilder icon(Identifier location) {
            this.iconLocation = location;

            return this;
        }

        public SlotGroup build(){
            return new SlotGroupImpl(
                    name,
                    Optional.ofNullable(order).orElse(0),
                    slots.stream().sorted(Comparator.<SlotType>naturalOrder().reversed()).map(SlotType::name).collect(Collectors.toCollection(LinkedHashSet::new)),
                    iconLocation
            );
        }
    }
}
