package io.wispforest.accessories.networking.client;

import com.mojang.logging.LogUtils;
import io.wispforest.accessories.api.AccessoriesCapability;
import io.wispforest.accessories.impl.AccessoriesHolderImpl;
import io.wispforest.accessories.impl.caching.AccessoriesHolderLookupCache;
import io.wispforest.endec.Endec;
import io.wispforest.endec.StructEndec;
import io.wispforest.endec.impl.StructEndecBuilder;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import org.slf4j.Logger;

public record InvalidateEntityCache(int entityId) {

    private static final Logger LOGGER = LogUtils.getLogger();

    public static final StructEndec<InvalidateEntityCache> ENDEC = StructEndecBuilder.of(
            Endec.VAR_INT.fieldOf("entityId", InvalidateEntityCache::entityId),
            InvalidateEntityCache::new
    );

    @Environment(EnvType.CLIENT)
    public static void handlePacket(InvalidateEntityCache packet, PlayerEntity player) {
        var level = player.getWorld();
        var entity = level.getEntityById(packet.entityId());

        if(entity == null) {
            LOGGER.error("Unable to Sync Container Data for a given Entity as it is null on the Client! [EntityId: {}]", packet.entityId());

            return;
        }

        if(!(entity instanceof LivingEntity livingEntity)) return;

        var capability = AccessoriesCapability.get(livingEntity);

        if(capability == null) {
            LOGGER.error("Unable to Sync Container Data for a given Entity as its Capability is null on the Client! [EntityId: {}]", packet.entityId());

            return;
        }

        var cache = ((AccessoriesHolderImpl) capability.getHolder()).getLookupCache();

        if(cache != null) cache.clearCache();
    }
}
