package io.wispforest.accessories.networking.server;

import io.wispforest.accessories.Accessories;
import io.wispforest.accessories.menu.AccessoriesMenuVariant;
import io.wispforest.endec.Endec;
import io.wispforest.endec.StructEndec;
import io.wispforest.endec.impl.StructEndecBuilder;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.server.network.ServerPlayerEntity;
import org.jetbrains.annotations.Nullable;

public record ScreenOpen(int entityId, boolean targetLookEntity, AccessoriesMenuVariant variant) {

    public static final StructEndec<ScreenOpen> ENDEC = StructEndecBuilder.of(
            Endec.VAR_INT.fieldOf("entityId", ScreenOpen::entityId),
            Endec.BOOLEAN.fieldOf("targetLookEntity", ScreenOpen::targetLookEntity),
            Endec.forEnum(AccessoriesMenuVariant.class).fieldOf("screenType", ScreenOpen::variant),
            ScreenOpen::new
    );

    public static ScreenOpen of(@Nullable LivingEntity livingEntity, AccessoriesMenuVariant variant){
        return new ScreenOpen(livingEntity != null ? livingEntity.getId() : -1, false, variant);
    }

    public static ScreenOpen of(boolean targetLookEntity, AccessoriesMenuVariant variant){
        return new ScreenOpen(-1, targetLookEntity, variant);
    }

    public static void handlePacket(ScreenOpen packet, PlayerEntity player) {
        LivingEntity livingEntity = null;

        if(packet.entityId() != -1) {
            var entity = player.getWorld().getEntityById(packet.entityId());

            if(entity instanceof LivingEntity living) livingEntity = living;
        } else if(packet.targetLookEntity()) {
            Accessories.attemptOpenScreenPlayer((ServerPlayerEntity) player, packet.variant());

            return;
        }

        ItemStack carriedStack = null;

        if(player.currentScreenHandler instanceof ScreenHandler oldMenu) {
            var currentCarriedStack = oldMenu.getCursorStack();

            if(!currentCarriedStack.isEmpty()) {
                carriedStack = currentCarriedStack;

                oldMenu.setCursorStack(ItemStack.EMPTY);
            }
        }

        Accessories.openAccessoriesMenu(player, packet.variant(), livingEntity, carriedStack);
    }
}