package io.wispforest.accessories.networking.holder;

import io.wispforest.accessories.client.gui.AccessoriesScreenBase;
import io.wispforest.accessories.networking.AccessoriesNetworking;
import io.wispforest.endec.*;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import java.util.function.Function;

public record SyncHolderChange(HolderProperty<?> property, Object data) {

    public static final StructEndec<SyncHolderChange> ENDEC = new StructEndec<>() {
        @Override
        public void encodeStruct(SerializationContext ctx, Serializer<?> serializer, Serializer.Struct struct, SyncHolderChange value) {
            struct.field("property", ctx, HolderProperty.ENDEC, value.property());
            struct.field("value", ctx, (Endec) value.property().endec(), value.data());
        }

        @Override
        public SyncHolderChange decodeStruct(SerializationContext ctx, Deserializer<?> deserializer, Deserializer.Struct struct) {
            var prop = struct.field("property", ctx, HolderProperty.ENDEC);

            return new SyncHolderChange(prop, struct.field("value", ctx, prop.endec()));
        }
    };

    public static <T> SyncHolderChange of(HolderProperty<T> property, T data) {
        return new SyncHolderChange(property, data);
    }

    public static <T> SyncHolderChange of(HolderProperty<T> property, PlayerEntity player, Function<T, T> operation) {
        return new SyncHolderChange(property, operation.apply(property.getter().apply(player.accessoriesHolder())));
    }

    public static void handlePacket(SyncHolderChange packet, PlayerEntity player) {
        packet.property().setData(player, packet.data());

        if(player.getWorld().isClient()) {
            handleClient(packet, player);
        } else {
            AccessoriesNetworking.sendToPlayer((ServerPlayerEntity) player, SyncHolderChange.of((HolderProperty<Object>) packet.property(), (Object) packet.property().getter().apply(player.accessoriesHolder())));
        }
    }

    @Environment(EnvType.CLIENT)
    public static void handleClient(SyncHolderChange packet, PlayerEntity player) {
        if(MinecraftClient.getInstance().currentScreen instanceof AccessoriesScreenBase accessoriesScreen) {
            accessoriesScreen.onHolderChange(packet.property().name());
        }
    }
}