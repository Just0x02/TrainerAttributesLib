package io.wispforest.accessories.networking;

import io.wispforest.accessories.Accessories;
import io.wispforest.accessories.mixin.EntityTrackerAccessor;
import io.wispforest.accessories.mixin.ServerChunkLoadingManagerAccessor;
import io.wispforest.accessories.networking.client.*;
import io.wispforest.accessories.networking.holder.SyncHolderChange;
import io.wispforest.accessories.networking.server.MenuScroll;
import io.wispforest.accessories.networking.server.NukeAccessories;
import io.wispforest.accessories.networking.server.ScreenOpen;
import io.wispforest.accessories.networking.server.SyncCosmeticToggle;
import io.wispforest.owo.network.ClientAccess;
import io.wispforest.owo.network.OwoNetChannel;
import io.wispforest.owo.network.ServerAccess;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.PlayerAssociatedNetworkHandler;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerChunkManager;
import java.util.ArrayList;
import java.util.function.BiConsumer;
import java.util.stream.Collectors;

public class AccessoriesNetworking {

    public static final OwoNetChannel CHANNEL = OwoNetChannel.create(Accessories.of("main"));

    public static void init() {
        CHANNEL.registerServerbound(ScreenOpen.class, ScreenOpen.ENDEC, serverHandler(ScreenOpen::handlePacket));
        CHANNEL.registerServerbound(NukeAccessories.class, NukeAccessories.ENDEC, serverHandler(NukeAccessories::handlePacket));
        CHANNEL.registerServerbound(SyncCosmeticToggle.class, SyncCosmeticToggle.ENDEC, serverHandler(SyncCosmeticToggle::handlePacket));

        CHANNEL.registerServerbound(MenuScroll.class, MenuScroll.ENDEC, serverHandler(MenuScroll::handlePacket));
        CHANNEL.registerServerbound(SyncHolderChange.class, SyncHolderChange.ENDEC, serverHandler(SyncHolderChange::handlePacket));

        //--

        CHANNEL.registerClientboundDeferred(SyncEntireContainer.class, SyncEntireContainer.ENDEC);
        CHANNEL.registerClientboundDeferred(SyncContainerData.class, SyncContainerData.ENDEC);
        CHANNEL.registerClientboundDeferred(SyncData.class, SyncData.ENDEC);
        CHANNEL.registerClientboundDeferred(AccessoryBreak.class, AccessoryBreak.ENDEC);
        CHANNEL.registerClientboundDeferred(InvalidateEntityCache.class, InvalidateEntityCache.ENDEC);

        CHANNEL.registerClientboundDeferred(MenuScroll.class, MenuScroll.ENDEC);
        CHANNEL.registerClientboundDeferred(SyncHolderChange.class, SyncHolderChange.ENDEC);

        CHANNEL.registerClientboundDeferred(ScreenVariantPing.class, ScreenVariantPing.ENDEC);
    }

    @Environment(EnvType.CLIENT)
    public static void initClient() {
        CHANNEL.registerClientbound(SyncEntireContainer.class, SyncEntireContainer.ENDEC, clientHandler(SyncEntireContainer::handlePacket));
        CHANNEL.registerClientbound(SyncContainerData.class, SyncContainerData.ENDEC, clientHandler(SyncContainerData::handlePacket));
        CHANNEL.registerClientbound(SyncData.class, SyncData.ENDEC, clientHandler(SyncData::handlePacket));
        CHANNEL.registerClientbound(AccessoryBreak.class, AccessoryBreak.ENDEC, clientHandler(AccessoryBreak::handlePacket));
        CHANNEL.registerClientbound(InvalidateEntityCache.class, InvalidateEntityCache.ENDEC, clientHandler(InvalidateEntityCache::handlePacket));

        CHANNEL.registerClientbound(MenuScroll.class, MenuScroll.ENDEC, clientHandler(MenuScroll::handlePacket));
        CHANNEL.registerClientbound(SyncHolderChange.class, SyncHolderChange.ENDEC, clientHandler(SyncHolderChange::handlePacket));

        CHANNEL.registerClientbound(ScreenVariantPing.class, ScreenVariantPing.ENDEC, clientHandler(ScreenVariantPing::handlePacket));
    }

    @Environment(EnvType.CLIENT)
    public static <R extends Record> OwoNetChannel.ChannelHandler<R, ClientAccess> clientHandler(BiConsumer<R, PlayerEntity> consumer) {
        return (r, access) -> consumer.accept(r, access.player());
    }

    public static <R extends Record> OwoNetChannel.ChannelHandler<R, ServerAccess> serverHandler(BiConsumer<R, PlayerEntity> consumer) {
        return (r, access) -> consumer.accept(r, access.player());
    }

    @Environment(EnvType.CLIENT)
    public static <R extends Record> void sendToServer(R packet) {
        CHANNEL.clientHandle().send(packet);
    }

    public static <R extends Record> void sendToPlayer(ServerPlayerEntity player, R packet) {
        CHANNEL.serverHandle(player).send(packet);
    }

    public static <R extends Record> void sendToAllPlayers(MinecraftServer server, R packet){
        for (var player : server.getPlayerManager().getPlayerList()) sendToPlayer(player, packet);
    }

    public static <R extends Record> void sendToTrackingAndSelf(Entity entity, R packet) {
        var targets = new ArrayList<ServerPlayerEntity>();

        if (entity.getWorld().getChunkManager() instanceof ServerChunkManager chunkCache) {
            var chunkLoadingManager = chunkCache.chunkLoadingManager;
            var tracker = ((ServerChunkLoadingManagerAccessor) chunkLoadingManager).accessories$getEntityMap().get(entity.getId());

            // return an immutable collection to guard against accidental removals.
            if (tracker != null) {
                targets.addAll(
                    tracker.accessories$getSeenBy().stream()
                        .map(PlayerAssociatedNetworkHandler::getPlayer)
                        .collect(Collectors.toUnmodifiableSet())
                );
            }
        }

        if (entity instanceof ServerPlayerEntity serverPlayer) targets.add(serverPlayer);

        CHANNEL.serverHandle(targets).send(packet);
    }
}
