package io.wispforest.accessories;

import com.mojang.logging.LogUtils;
import org.slf4j.Logger;

import java.util.Optional;
import net.minecraft.resource.ResourceReloader;

public class DataLoaderBase {

    public static final Logger LOGGER = LogUtils.getLogger();

    public static DataLoaderBase INSTANCE = new DataLoaderBase();

    public void registerListeners() {
        // NO-OP
        LOGGER.info("Registering Listeners!");
    }

    protected Optional<ResourceReloader> getIdentifiedSlotLoader(){
        return Optional.empty();
    }

    protected Optional<ResourceReloader> getIdentifiedEntitySlotLoader(){
        return Optional.empty();
    }
}
