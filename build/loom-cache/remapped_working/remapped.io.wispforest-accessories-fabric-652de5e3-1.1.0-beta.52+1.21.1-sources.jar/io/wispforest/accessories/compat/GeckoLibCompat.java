package io.wispforest.accessories.compat;

import org.jetbrains.annotations.ApiStatus;
import software.bernie.geckolib.util.InternalUtil;

import java.util.function.BiConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;

@ApiStatus.Internal
public class GeckoLibCompat {
    public static <T extends LivingEntity, M extends BipedEntityModel<T>, A extends BipedEntityModel<T>> boolean renderGeckoArmor(MatrixStack poseStack, VertexConsumerProvider bufferSource, T entity, ItemStack stack, EquipmentSlot equipmentSlot, M parentModel, A baseModel, float partialTicks, int light, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, BiConsumer<A, EquipmentSlot> partVisibilitySetter) {
        return InternalUtil.tryRenderGeoArmorPiece(poseStack, bufferSource, entity, stack, equipmentSlot, parentModel, baseModel, partialTicks, light, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, partVisibilitySetter);
    }
}
