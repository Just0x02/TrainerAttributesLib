package io.wispforest.accessories.api.caching;

import java.util.Arrays;
import java.util.Objects;
import net.minecraft.component.ComponentMap;
import net.minecraft.component.ComponentType;
import net.minecraft.item.ItemStack;

public class DataComponentMapPredicate extends ItemStackBasedPredicate {

    public final ComponentMap dataComponentMap;

    public DataComponentMapPredicate(String name, ComponentMap dataComponentMap){
        super(name);

        this.dataComponentMap = dataComponentMap;
    }

    @Override
    public boolean test(ItemStack stack) {
        for (var typedDataComponent : dataComponentMap) {
            if (!typedDataComponent.equals(stack.get(typedDataComponent.type()))) return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return Arrays.hashCode(dataComponentMap.stream().toArray());
    }

    @Override
    protected boolean isEqual(Object other) {
        var dataComponentMapPredicate = (DataComponentMapPredicate) other;

        return Objects.equals(this.dataComponentMap, dataComponentMapPredicate.dataComponentMap);
    }

    @Override
    public String extraStringData() {
        return "DataComponents: " + this.dataComponentMap.toString();
    }

    public interface ComponentAddCallback {
        <T> void add(ComponentType<T> type, T t);
    }
}