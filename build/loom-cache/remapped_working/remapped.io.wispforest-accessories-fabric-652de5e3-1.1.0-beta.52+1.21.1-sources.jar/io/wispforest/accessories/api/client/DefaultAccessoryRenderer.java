package io.wispforest.accessories.api.client;

import I;
import com.mojang.logging.LogUtils;
import io.wispforest.accessories.Accessories;
import io.wispforest.accessories.api.Accessory;
import io.wispforest.accessories.api.client.rendering.ClientTransformationUtils;
import io.wispforest.accessories.api.client.rendering.ModelTransformUtils;
import io.wispforest.accessories.api.components.AccessoriesDataComponents;
import io.wispforest.accessories.api.components.AccessoryRenderTransformations;
import io.wispforest.accessories.api.slot.SlotReference;
import org.slf4j.Logger;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.render.model.json.ModelTransformationMode;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Arm;
import net.minecraft.util.math.RotationAxis;

/**
 * Default Renderer for any {@link Accessory} that doesn't have a renderer registered.
 */
public class DefaultAccessoryRenderer implements AccessoryRenderer {

    private static final Logger LOGGER = LogUtils.getLogger();

    //--

    public static final DefaultAccessoryRenderer INSTANCE;

    private final Map<String, RenderHelper> slotToHelpers = new HashMap<>();

    public DefaultAccessoryRenderer(){
        slotToHelpers.putAll(DEFAULT_HELPERS);
    }

    /**
     * Registers a {@link RenderHelper} for a given slot name if not already registered
     */
    public static void registerHelper(String slotType, RenderHelper helper){
        var helpers = INSTANCE.slotToHelpers;

        if(!helpers.containsKey(slotType)){
            helpers.put(slotType, helper);
        } else {
            LOGGER.warn("[DefaultAccessoryRenderer] Unable to add to the main renderer instance due to a duplicate helper already exists!");
        }
    }

    @Override
    public <M extends LivingEntity> void render(ItemStack stack, SlotReference reference, MatrixStack matrices, EntityModel<M> model, VertexConsumerProvider multiBufferSource, int light, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
        if (!(model instanceof BipedEntityModel<? extends LivingEntity> humanoidModel)) return;

        var disabledTargetType = Accessories.config().clientOptions.disabledDefaultRenders();

        for (var target : disabledTargetType) {
            if(reference.slotName().equals(target.slotType) && target.targetType.isValid(stack.getItem())) return;
        }

        Consumer<MatrixStack> render = (poseStack) -> MinecraftClient.getInstance().getItemRenderer().renderItem(stack, ModelTransformationMode.FIXED, light, OverlayTexture.DEFAULT_UV, poseStack, multiBufferSource, reference.entity().getWorld(), 0);

        var translationData = stack.getOrDefault(AccessoriesDataComponents.RENDER_TRANSFORMATIONS, AccessoryRenderTransformations.EMPTY);

        Consumer<MatrixStack> translationAndRender = poseStack -> {
            ClientTransformationUtils.transformStack(translationData.transformations(), poseStack, reference.entity(), humanoidModel, () -> {
                render.accept(poseStack);
            });
        };

        if(!translationData.disableDefaultTranslations()) {
            var helper = slotToHelpers.get(reference.slotName());

            if (helper != null) {
                helper.render(translationAndRender, matrices, humanoidModel, reference);
            }
        } else {
            translationAndRender.accept(matrices);
        }
    }

    @Override
    public boolean shouldRenderInFirstPerson(Arm arm, ItemStack stack, SlotReference reference) {
        var slotName = reference.slotName();

        return (slotName.equals("hand") || slotName.equals("wrist") || slotName.equals("ring")) && (reference.slot() % 2 == 0 ? arm == Arm.RIGHT : arm == Arm.LEFT);
    }

    public interface RenderHelper {
        <M extends LivingEntity> void render(Consumer<MatrixStack> renderCall, MatrixStack matrices, BipedEntityModel<M> humanoidModel, SlotReference reference);
    }

    //--

    private static final Map<String, RenderHelper> DEFAULT_HELPERS;

    static {
        DEFAULT_HELPERS = Map.ofEntries(
                Map.entry("face", new RenderHelper() {
                    @Override
                    public <M extends LivingEntity> void render(Consumer<MatrixStack> renderCall, MatrixStack matrices, BipedEntityModel<M> humanoidModel, SlotReference reference) {
                        ModelTransformUtils.transformToFace(matrices, reference.entity(), humanoidModel, "head", Side.FRONT);
                        renderCall.accept(matrices);
                    }
                }),
                Map.entry("hat", new RenderHelper() {
                    @Override
                    public <M extends LivingEntity> void render(Consumer<MatrixStack> renderCall, MatrixStack matrices, BipedEntityModel<M> humanoidModel, SlotReference reference) {
                        ModelTransformUtils.transformToFace(matrices, reference.entity(), humanoidModel, "head", Side.TOP);
                        matrices.translate(0, 0.25, 0);
                        for (int i = 0; i < reference.getStack().getCount(); i++) {
                            renderCall.accept(matrices);
                            matrices.translate(0, 0.5, 0);
                        }
                    }
                }),
                Map.entry("back", new RenderHelper() {
                    @Override
                    public <M extends LivingEntity> void render(Consumer<MatrixStack> renderCall, MatrixStack matrices, BipedEntityModel<M> humanoidModel, SlotReference reference) {
                        ModelTransformUtils.transformToFace(matrices, reference.entity(), humanoidModel, "body", Side.BACK);
                        matrices.scale(1.5f, 1.5f, 1.5f);
                        renderCall.accept(matrices);
                    }
                }),
                Map.entry("necklace", new RenderHelper() {
                    @Override
                    public <M extends LivingEntity> void render(Consumer<MatrixStack> renderCall, MatrixStack matrices, BipedEntityModel<M> humanoidModel, SlotReference reference) {
                        ModelTransformUtils.transformToModelPart(matrices, reference.entity(), humanoidModel, "body", 0, 1, 1);
                        matrices.translate(0, -0.25, 0);
                        renderCall.accept(matrices);
                    }
                }),
                Map.entry("cape", new RenderHelper() {
                    @Override
                    public <M extends LivingEntity> void render(Consumer<MatrixStack> renderCall, MatrixStack matrices, BipedEntityModel<M> humanoidModel, SlotReference reference) {
                        ModelTransformUtils.transformToModelPart(matrices, reference.entity(), humanoidModel, "body", 0, 1, -1);
                        matrices.translate(0, -0.25, 0);
                        renderCall.accept(matrices);
                    }
                }),
                Map.entry("ring", new RenderHelper() {
                    @Override
                    public <M extends LivingEntity> void render(Consumer<MatrixStack> renderCall, MatrixStack matrices, BipedEntityModel<M> humanoidModel, SlotReference reference) {
                        var modelTarget = reference.slot() % 2 == 0 ? "right_arm" : "left_arm";
                        var xPercent = reference.slot() % 2 == 0 ? 1 : -1;

                        ModelTransformUtils.transformToModelPart(
                                matrices,
                                reference.entity(),
                                humanoidModel,
                                modelTarget,
                                xPercent,
                                -1,
                                0
                        );
                        var offset = reference.slot() / 2;
                        matrices.translate(
                                (reference.slot() % 2 == 0 ? -1 : 1) * offset * -0.0001,
                                0.25 * (offset + 1),
                                0
                        );
                        matrices.scale(0.5f, 0.5f, 0.5f);
                        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(90));
                        for (int i = 0; i < reference.getStack().getCount(); i++) {
                            renderCall.accept(matrices);
                            matrices.translate(
                                    0,
                                    0,
                                    reference.slot() % 2 == 0 ? -0.5 : 0.5
                            );
                        }
                    }
                }),
                Map.entry("wrist", new RenderHelper() {
                    @Override
                    public <M extends LivingEntity> void render(Consumer<MatrixStack> renderCall, MatrixStack matrices, BipedEntityModel<M> humanoidModel, SlotReference reference) {
                        var modelTarget = reference.slot() % 2 == 0 ? "right_arm" : "left_arm";
                        ModelTransformUtils.transformToModelPart(matrices, reference.entity(), humanoidModel, modelTarget, 0, -0.5, 0);
                        matrices.scale(1.01f, 1.01f, 1.01f);
                        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(90));
                        renderCall.accept(matrices);
                    }
                }),
                Map.entry("hand", new RenderHelper() {
                    @Override
                    public <M extends LivingEntity> void render(Consumer<MatrixStack> renderCall, MatrixStack matrices, BipedEntityModel<M> humanoidModel, SlotReference reference) {
                        var modelTarget = reference.slot() % 2 == 0 ? "right_arm" : "left_arm";
                        ModelTransformUtils.transformToFace(matrices, reference.entity(), humanoidModel, modelTarget, Side.BOTTOM);
                        matrices.translate(0, 0.25, 0);
                        matrices.scale(1.02f, 1.02f, 1.02f);
                        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(90));
                        renderCall.accept(matrices);
                    }
                }),
                Map.entry("belt", new RenderHelper() {
                    @Override
                    public <M extends LivingEntity> void render(Consumer<MatrixStack> renderCall, MatrixStack matrices, BipedEntityModel<M> humanoidModel, SlotReference reference) {
                        ModelTransformUtils.transformToFace(matrices, reference.entity(), humanoidModel, "body", Side.BOTTOM);
                        matrices.scale(1.01f, 1.01f, 1.01f);
                        renderCall.accept(matrices);
                    }
                }),
                Map.entry("anklet", new RenderHelper() {
                    @Override
                    public <M extends LivingEntity> void render(Consumer<MatrixStack> renderCall, MatrixStack matrices, BipedEntityModel<M> humanoidModel, SlotReference reference) {
                        var modelTarget = reference.slot() % 2 == 0 ? "right_leg" : "left_leg";
                        ModelTransformUtils.transformToModelPart(matrices, reference.entity(), humanoidModel, modelTarget, 0, -0.5, 0);
                        matrices.scale(1.01f, 1.01f, 1.01f);
                        renderCall.accept(matrices);
                    }
                }),
                Map.entry("shoes", new RenderHelper() {
                    @Override
                    public <M extends LivingEntity> void render(Consumer<MatrixStack> renderCall, MatrixStack matrices, BipedEntityModel<M> humanoidModel, SlotReference reference) {
                        matrices.push();
                        ModelTransformUtils.transformToFace(matrices, reference.entity(), humanoidModel, "right_leg", Side.BOTTOM);
                        matrices.translate(0, 0.25, 0);
                        matrices.scale(1.02f, 1.02f, 1.02f);
                        renderCall.accept(matrices);
                        matrices.pop();
                        matrices.push();
                        ModelTransformUtils.transformToFace(matrices, reference.entity(), humanoidModel, "left_leg", Side.BOTTOM);
                        matrices.translate(0, 0.25, 0);
                        matrices.scale(1.02f, 1.02f, 1.02f);
                        renderCall.accept(matrices);
                        matrices.pop();
                    }
                })
        );

        INSTANCE = new DefaultAccessoryRenderer();
    }
}
