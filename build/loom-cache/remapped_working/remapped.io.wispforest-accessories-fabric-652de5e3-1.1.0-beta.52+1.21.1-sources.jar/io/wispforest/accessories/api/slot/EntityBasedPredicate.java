package io.wispforest.accessories.api.slot;

import net.fabricmc.fabric.api.util.TriState;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

/**
 * Similar to {@link SlotBasedPredicate} but allows for {@link LivingEntity} if such is required
 */
public interface EntityBasedPredicate extends SlotBasedPredicate {

    TriState isValid(World level, @Nullable LivingEntity entity, SlotType slotType, int slot, ItemStack stack);

    @Override
    default TriState isValid(World level, SlotType slotType, int slot, ItemStack stack) {
        return isValid(level, null, slotType, slot, stack);
    }
}
