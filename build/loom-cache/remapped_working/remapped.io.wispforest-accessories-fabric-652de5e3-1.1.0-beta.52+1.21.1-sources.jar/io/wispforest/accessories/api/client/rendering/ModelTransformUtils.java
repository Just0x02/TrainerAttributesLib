package io.wispforest.accessories.api.client.rendering;

import Z;
import com.mojang.datafixers.util.Pair;
import io.wispforest.accessories.api.client.Side;
import io.wispforest.accessories.mixin.client.ModelPartAccessor;
import io.wispforest.accessories.pond.ModelRootAccess;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.Map.Entry;
import net.minecraft.client.model.Model;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;

public class ModelTransformUtils {

    private static final Map<Identifier, ModelPartTransformer> ADDITIONAL_TRANSFORMERS = new LinkedHashMap<>();

    @ApiStatus.Experimental
    public static void registerTransformer(Identifier location, ModelPartTransformer modelTransformers) {
        if (ADDITIONAL_TRANSFORMERS.containsKey(location)) {
            throw new IllegalStateException("Already existing ModelTransformer exists!");
        }

        ADDITIONAL_TRANSFORMERS.put(location, modelTransformers);
    }

    @ApiStatus.Experimental
    public static boolean transformToFace(MatrixStack poseStack, LivingEntity livingEntity, Model model, String modelPartName, Side side) {
        return transformToModelPart(poseStack, livingEntity, model, modelPartName, side.direction.getVector().getX(), side.direction.getVector().getY(), side.direction.getVector().getZ());
    }

    @ApiStatus.Experimental
    public static boolean transformToModelPart(MatrixStack poseStack, LivingEntity livingEntity, Model model, String modelPartName) {
        return transformToModelPart(poseStack, livingEntity, model, modelPartName, 0, 0, 0);
    }

    @ApiStatus.Experimental
    public static boolean transformToModelPart(MatrixStack poseStack, LivingEntity livingEntity, Model model, String modelPartName, @Nullable Number xPercent, @Nullable Number yPercent, @Nullable Number zPercent) {
        // TODO: ADD ERRORING FOR IF IT OCCURED

        for (var entry : ADDITIONAL_TRANSFORMERS.entrySet()) {
            var result = entry.getValue().transformToPart(poseStack, livingEntity, model, modelPartName, xPercent, yPercent, zPercent);

            if (result) return true;
        }

        var modelPart = getPart(model, modelPartName);

        if (modelPart != null) {
            transformToModelPart(poseStack, modelPart, xPercent, yPercent, zPercent);

            return true;
        }

        return false;
    }

    @ApiStatus.Experimental
    @Nullable
    public static ModelPart getPart(Model model, String modelPartName) {
        if (model instanceof ModelRootAccess access) {
            var possiblePart = access.accessories$getAnyDescendantWithName(modelPartName);

            if(possiblePart.isPresent()) return possiblePart.get();
        }

        return null;
    }

    /**
     * Transforms the rendering context to a specific face on a ModelPart
     *
     * @param poseStack the pose stack to apply the transformation(s) to
     * @param part      The ModelPart to transform to
     * @param side      The side of the ModelPart to transform to
     */
    public static void transformToFace(MatrixStack poseStack, ModelPart part, Side side) {
        transformToModelPart(poseStack, part, side.direction.getVector().getX(), side.direction.getVector().getY(), side.direction.getVector().getZ());
    }

    /**
     * Transforms the rendering context to the center of a ModelPart
     *
     * @param poseStack the pose stack to apply the transformation(s) to
     * @param part      The ModelPart to transform to
     */
    public static void transformToModelPart(MatrixStack poseStack, ModelPart part) {
        transformToModelPart(poseStack, part, 0, 0, 0);
    }

    /**
     * Transforms the rendering context to a specific place relative to a ModelPart
     *
     * @param poseStack the pose stack to apply the transformation(s) to
     * @param part      The ModelPart to transform to
     * @param xPercent  The percentage of the x-axis to translate to
     *                  <p>
     *                  (-1 being the left side and 1 being the right side)
     *                  <p>
     *                  If null, will be ignored
     * @param yPercent  The percentage of the y-axis to translate to
     *                  <p>
     *                  (-1 being the bottom and 1 being the top)
     *                  <p>
     *                  If null, will be ignored
     * @param zPercent  The percentage of the z-axis to translate to
     *                  <p>
     *                  (-1 being the back and 1 being the front)
     *                  <p>
     *                  If null, will be ignored
     */
    public static void transformToModelPart(MatrixStack poseStack, ModelPart part, @Nullable Number xPercent, @Nullable Number yPercent, @Nullable Number zPercent) {
        part.rotate(poseStack);
        var aabb = getAABB(part);
        poseStack.scale(1 / 16f, 1 / 16f, 1 / 16f);
        poseStack.translate(
                xPercent != null ? MathHelper.lerp((-xPercent.doubleValue() + 1) / 2, aabb.getFirst().x, aabb.getSecond().x) : 0,
                yPercent != null ? MathHelper.lerp((-yPercent.doubleValue() + 1) / 2, aabb.getFirst().y, aabb.getSecond().y) : 0,
                zPercent != null ? MathHelper.lerp((-zPercent.doubleValue() + 1) / 2, aabb.getFirst().z, aabb.getSecond().z) : 0
        );
        poseStack.scale(8, 8, 8);
        poseStack.multiply(RotationAxis.POSITIVE_X.rotationDegrees(180));
    }

    private static Pair<Vec3d, Vec3d> getAABB(ModelPart part) {
        Vec3d min = new Vec3d(0, 0, 0);
        Vec3d max = new Vec3d(0, 0, 0);

        if (part.getClass().getSimpleName().contains("EMFModelPart")) {
            var parts = new ArrayList<ModelPart>();

            parts.add(part);
            parts.addAll(((ModelPartAccessor) (Object) part).getChildren().values());

            for (var modelPart : parts) {
                for (ModelPart.Cuboid cube : ((ModelPartAccessor) (Object) modelPart).getCubes()) {
                    min = new Vec3d(
                            Math.min(min.x, Math.min(cube.minX + modelPart.pivotX, cube.maxX + modelPart.pivotX)),
                            Math.min(min.y, Math.min(cube.minY + modelPart.pivotY, cube.maxY + modelPart.pivotY)),
                            Math.min(min.z, Math.min(cube.minZ + modelPart.pivotZ, cube.maxZ + modelPart.pivotZ))
                    );
                    max = new Vec3d(
                            Math.max(max.x, Math.max(cube.minX + modelPart.pivotX, cube.maxX + modelPart.pivotX)),
                            Math.max(max.y, Math.max(cube.minY + modelPart.pivotY, cube.maxY + modelPart.pivotY)),
                            Math.max(max.z, Math.max(cube.minZ + modelPart.pivotZ, cube.maxZ + modelPart.pivotZ))
                    );
                }
            }
        } else {
            for (ModelPart.Cuboid cube : ((ModelPartAccessor) (Object) part).getCubes()) {
                min = new Vec3d(
                        Math.min(min.x, Math.min(cube.minX, cube.maxX)),
                        Math.min(min.y, Math.min(cube.minY, cube.maxY)),
                        Math.min(min.z, Math.min(cube.minZ, cube.maxZ))
                );
                max = new Vec3d(
                        Math.max(max.x, Math.max(cube.minX, cube.maxX)),
                        Math.max(max.y, Math.max(cube.minY, cube.maxY)),
                        Math.max(max.z, Math.max(cube.minZ, cube.maxZ))
                );
            }
        }

        return Pair.of(min, max);
    }

    @ApiStatus.Experimental
    public interface ModelPartTransformer {
        boolean transformToPart(MatrixStack poseStack, LivingEntity livingEntity, Model model, String modelPartName, @Nullable Number xPercent, @Nullable Number yPercent, @Nullable Number zPercent);
    }
}
