package io.wispforest.accessories.api.components;

import io.wispforest.accessories.Accessories;
import io.wispforest.endec.SerializationAttributes;
import io.wispforest.endec.SerializationContext;
import org.jetbrains.annotations.ApiStatus;

import java.util.function.UnaryOperator;
import net.minecraft.component.ComponentType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class AccessoriesDataComponents {

    private static final SerializationContext BASE_CTX = SerializationContext.attributes(SerializationAttributes.HUMAN_READABLE);

    public static final ComponentType<AccessoryNestContainerContents> NESTED_ACCESSORIES = register(Accessories.of("nested_accessories"),
            builder -> builder.endec(AccessoryNestContainerContents.ENDEC, BASE_CTX)
    );

    public static final ComponentType<AccessoryRenderOverrideComponent> RENDER_OVERRIDE = register(Accessories.of("render_override"),
            builder -> builder.endec(AccessoryRenderOverrideComponent.ENDEC, BASE_CTX)
    );

    public static final ComponentType<AccessoryRenderTransformations> RENDER_TRANSFORMATIONS = register(Accessories.of("render_transformations"),
            builder -> builder.endec(AccessoryRenderTransformations.ENDEC, BASE_CTX)
    );

    public static final ComponentType<AccessorySlotValidationComponent> SLOT_VALIDATION = register(Accessories.of("slot_validation"),
            builder -> builder.endec(AccessorySlotValidationComponent.ENDEC, BASE_CTX)
    );

    public static final ComponentType<AccessoryItemAttributeModifiers> ATTRIBUTES = register(Accessories.of("attributes"),
            builder -> builder.endec(AccessoryItemAttributeModifiers.ENDEC, BASE_CTX)
    );

    public static final ComponentType<AccessoryStackSizeComponent> STACK_SIZE = register(Accessories.of("stack_size"),
            builder -> builder.endec(AccessoryStackSizeComponent.ENDEC, BASE_CTX)
    );

    public static final ComponentType<AccessoryCustomRendererComponent> CUSTOM_RENDERER = register(Accessories.of("custom_renderer"),
            builder -> builder.endec(AccessoryCustomRendererComponent.ENDEC, BASE_CTX)
    );

    public static final ComponentType<AccessoryItemCosmeticOverride> ITEM_MODEL_OVERRIDE = register(Accessories.of("item_cosmetic_override"),
            builder -> builder.endec(AccessoryItemCosmeticOverride.ENDEC, BASE_CTX)
    );

    private static <T> ComponentType<T> register(Identifier string, UnaryOperator<ComponentType.Builder<T>> unaryOperator) {
        return Registry.register(Registries.DATA_COMPONENT_TYPE, string, ((ComponentType.Builder)unaryOperator.apply(ComponentType.builder())).build());
    }

    @ApiStatus.Internal
    public static void init() {}
}
