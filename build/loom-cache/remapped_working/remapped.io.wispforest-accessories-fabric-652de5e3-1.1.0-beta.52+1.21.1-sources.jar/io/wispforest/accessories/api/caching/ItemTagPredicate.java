package io.wispforest.accessories.api.caching;

import java.util.Objects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.tag.TagKey;

public class ItemTagPredicate extends ItemStackBasedPredicate{

    private final TagKey<Item> itemTagKey;

    public ItemTagPredicate(String name, TagKey<Item> itemTagKey) {
        super(name);
        this.itemTagKey = itemTagKey;
    }

    @Override
    public boolean test(ItemStack stack) {
        return stack.isIn(this.itemTagKey);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.itemTagKey);
    }

    @Override
    protected boolean isEqual(Object other) {
        var itemTagPredicate = (ItemTagPredicate) other;

        return this.itemTagKey.equals(itemTagPredicate.itemTagKey);
    }

    @Override
    public String extraStringData() {
        return "ItemTag: " + this.itemTagKey.toString();
    }
}
