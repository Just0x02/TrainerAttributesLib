package io.wispforest.accessories.api.data.providers.entity;

import io.wispforest.endec.Endec;
import io.wispforest.endec.StructEndec;
import io.wispforest.endec.impl.BuiltInEndecs;
import io.wispforest.endec.impl.StructEndecBuilder;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;
import net.minecraft.entity.EntityType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.Identifier;

public record RawEntityBinding(Optional<Boolean> replace, List<TagKey<EntityType<?>>> tags, List<EntityType<?>> entityTypes, List<String> slots) {

    public static final StructEndec<RawEntityBinding> ENDEC = StructEndecBuilder.of(
            Endec.BOOLEAN.optionalOf().optionalFieldOf("replace", RawEntityBinding::replace, Optional.empty()),
            Endec.STRING.listOf().fieldOf("entities", rawEntityBinding -> {
                return Stream.concat(
                        rawEntityBinding.tags().stream().map(tag -> "#" + tag.id()),
                        rawEntityBinding.entityTypes().stream().map(entityType -> Registries.ENTITY_TYPE.getId(entityType).toString())
                ).toList();
            }),
            Endec.STRING.listOf().fieldOf("slots", RawEntityBinding::slots),
            (replace, entities, slots) -> {
                var tags = new ArrayList<TagKey<EntityType<?>>>();
                var entityTypes = new ArrayList<EntityType<?>>();

                for (var entity : entities) {
                    if(entity.charAt(0) == '#') {
                        var tag = TagKey.of(RegistryKeys.ENTITY_TYPE, Identifier.of(entity.replace("#", "")));

                        tags.add(tag);
                    } else {
                        var entityType = Registries.ENTITY_TYPE.getOrThrow(RegistryKey.of(RegistryKeys.ENTITY_TYPE, Identifier.of(entity)));

                        entityTypes.add(entityType);
                    }
                }

                return new RawEntityBinding(replace, tags, entityTypes, slots);
            }
    );
}
