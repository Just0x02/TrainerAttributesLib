package io.wispforest.accessories.api.data.providers.entity;

import com.mojang.serialization.Codec;
import io.wispforest.accessories.api.data.providers.BaseDataProvider;
import io.wispforest.owo.serialization.CodecUtils;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import net.minecraft.data.DataProvider;
import net.minecraft.data.DataWriter;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.util.Identifier;

public abstract class EntityBindingProvider extends BaseDataProvider<EntityBindingProvider.EntityBindingOutput> {

    private final Codec<RawEntityBinding> CODEC = CodecUtils.toCodec(RawEntityBinding.ENDEC);

    public EntityBindingProvider(net.minecraft.data.DataOutput packOutput, CompletableFuture<RegistryWrapper.WrapperLookup> completableFuture) {
        super(packOutput, completableFuture);
    }

    @Override
    protected abstract void buildData(RegistryWrapper.WrapperLookup provider, EntityBindingOutput output);

    public EntityBindingBuilder builder() {
        return new EntityBindingBuilder(false);
    }

    //--

    @Override
    public final String getName() {
        return "SlotGroup";
    }

    @Override
    protected final String type() {
        return "accessories/group";
    }

    @Override
    protected final net.minecraft.data.DataOutput.OutputType target() {
        return net.minecraft.data.DataOutput.OutputType.DATA_PACK;
    }

    public interface EntityBindingOutput extends BaseDataProvider.DataOutput {
        void accept(Identifier location, RawEntityBinding binding);
    }

    @Override
    protected EntityBindingOutput buildOutput(DataWriter cachedOutput, RegistryWrapper.WrapperLookup provider) {
        return new EntityBindingOutput() {

            final List<CompletableFuture<?>> list = new ArrayList<>();

            @Override
            public void accept(Identifier location, RawEntityBinding binding) {
                list.add(DataProvider.writeCodecToPath(cachedOutput, provider, CODEC, binding, EntityBindingProvider.this.pathProvider().resolveJson(location)));
            }

            @Override
            public Collection<CompletableFuture<?>> futures() {
                return List.of();
            }
        };
    }
}
