package io.wispforest.accessories.api.client;

import io.wispforest.accessories.api.slot.SlotReference;
import io.wispforest.accessories.mixin.client.LivingEntityRendererAccessor;
import java.util.Optional;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Equipment;
import net.minecraft.item.ItemStack;

public interface AccessoryArmorRenderer extends AccessoryRenderer {
    @Override
    default <M extends LivingEntity> void render(ItemStack stack, SlotReference reference, MatrixStack matrices, EntityModel<M> model, VertexConsumerProvider multiBufferSource, int light, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
        var entityRender = MinecraftClient.getInstance().getEntityRenderDispatcher().getRenderer(reference.entity());

        if (!(entityRender instanceof LivingEntityRendererAccessor<?, ?> accessor)) return;

        if (!(stack.getItem() instanceof Equipment equipable)) return;

        var equipmentSlot = equipable.getSlotType();

        var possibleLayer = accessor.getLayers().stream()
                .filter(renderLayer -> renderLayer instanceof ArmorRenderingExtension)
                .findFirst();

        possibleLayer.ifPresent(layer -> ((ArmorRenderingExtension) layer).renderEquipmentStack(stack, matrices, multiBufferSource, reference.entity(), equipmentSlot, light, limbSwing, limbSwingAmount, partialTicks, ageInTicks, netHeadYaw, headPitch));
    }
}
