package io.wispforest.accessories.api.attributes;

import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.registry.entry.RegistryEntry;
import org.jetbrains.annotations.Nullable;

public record AttributeModificationData(@Nullable String slotPath, RegistryEntry<EntityAttribute> attribute, EntityAttributeModifier modifier) {

    public AttributeModificationData(RegistryEntry<EntityAttribute> attribute, EntityAttributeModifier modifier) {
        this(null, attribute, modifier);
    }

    @Override
    public EntityAttributeModifier modifier() {
        return (this.slotPath != null)
                ? new EntityAttributeModifier(modifier.id().withPath((path) -> this.slotPath + "/" + path), modifier.value(), modifier.operation())
                : modifier;
    }

    @Override
    public String toString() {
        return "AttributeModifierInstance[" +
                "attribute=" + this.attribute + ", " +
                "modifier=" + this.modifier +
                "slotPath=" + (this.slotPath != null ? this.slotPath : "none") +
                ']';
    }
}
