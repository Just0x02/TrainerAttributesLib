package io.wispforest.accessories.api.data.providers.slot;

import com.google.common.collect.Sets;
import com.mojang.serialization.Codec;
import io.wispforest.accessories.api.data.providers.BaseDataProvider;
import io.wispforest.owo.serialization.CodecUtils;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import net.minecraft.data.DataProvider;
import net.minecraft.data.DataWriter;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.util.Identifier;

public abstract class SlotDataProvider extends BaseDataProvider<SlotDataProvider.SlotOutput> {

    private final Codec<RawSlotType> CODEC = CodecUtils.toCodec(RawSlotType.ENDEC);

    public SlotDataProvider(net.minecraft.data.DataOutput packOutput, CompletableFuture<RegistryWrapper.WrapperLookup> completableFuture) {
        super(packOutput, completableFuture);
    }

    public interface SlotOutput extends DataOutput {
        void accept(String namespace, RawSlotType slotType);
    }

    @Override
    protected abstract void buildData(RegistryWrapper.WrapperLookup provider, SlotOutput output);

    public SlotBuilder builder(Identifier uniqueLocation) {
        return builder(uniqueLocation.toString());
    }

    public SlotBuilder builder(String slotName) {
        return new SlotBuilder(slotName, false);
    }

    //--

    @Override
    public final String getName() {
        return "SlotType";
    }

    @Override
    protected final String type() {
        return "accessories/slot";
    }

    @Override
    protected final net.minecraft.data.DataOutput.OutputType target() {
        return net.minecraft.data.DataOutput.OutputType.DATA_PACK;
    }

    @Override
    protected final SlotOutput buildOutput(DataWriter cachedOutput, RegistryWrapper.WrapperLookup provider) {
        return new SlotOutput() {
            final Set<Identifier> set = Sets.newHashSet();
            final List<CompletableFuture<?>> list = new ArrayList<>();

            @Override
            public void accept(String namespace, RawSlotType rawSlotType) {
                var location = Identifier.of(namespace, rawSlotType.name().replace(":", "/"));

                if (!set.add(location)) throw new IllegalStateException("Duplicate SlotType: " + location);

                list.add(DataProvider.writeCodecToPath(cachedOutput, provider, CODEC, rawSlotType, SlotDataProvider.this.pathProvider().resolveJson(location)));
            }

            @Override
            public Collection<CompletableFuture<?>> futures() {
                return list;
            }
        };
    }
}
