package io.wispforest.accessories.api.events.extra;

import io.wispforest.accessories.api.slot.SlotReference;
import io.wispforest.accessories.impl.event.WrappedEvent;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.item.ItemStack;
import net.minecraft.loot.context.LootContext;
import net.minecraft.loot.context.LootContextParameterSet;
import net.minecraft.loot.context.LootContextParameters;
import net.minecraft.loot.context.LootContextTypes;
import net.minecraft.server.world.ServerWorld;
import java.util.Optional;

/**
 * @deprecated Use {@link io.wispforest.accessories.api.events.extra.v2.LootingAdjustment} instead!
 */
@Deprecated(forRemoval = true)
public interface LootingAdjustment {

    @Deprecated(forRemoval = true)
    Event<LootingAdjustment> EVENT = new WrappedEvent<>(
            io.wispforest.accessories.api.events.extra.v2.LootingAdjustment.EVENT,
            (adjustment) -> (stack, reference, target, context, damageSource, currentLevel) -> adjustment.getLootingAdjustment(stack, reference, target, damageSource, currentLevel),
            lootingAdjustmentEvent -> {
                return (stack, reference, target, damageSource, currentLevel) -> {
                    var contextBuilder = new LootContext.Builder(
                            new LootContextParameterSet.Builder((ServerWorld) reference.entity().getWorld())
                                    .add(LootContextParameters.THIS_ENTITY, reference.entity())
                                    .add(LootContextParameters.ORIGIN, reference.entity().getPos())
                                    .add(LootContextParameters.DAMAGE_SOURCE, damageSource)
                                    .add(LootContextParameters.ATTACKING_ENTITY, target)
                                    .build(LootContextTypes.ENTITY)
                    );

                    return lootingAdjustmentEvent.invoker().getLootingAdjustment(stack, reference, target, contextBuilder.build(Optional.empty()), damageSource, currentLevel);
                };
            }
    );

    int getLootingAdjustment(ItemStack stack, SlotReference reference, LivingEntity target, DamageSource damageSource, int currentLevel);
}
