package io.wispforest.accessories.api.data.providers.group;

import com.google.common.collect.Sets;
import com.mojang.serialization.Codec;
import io.wispforest.accessories.api.data.providers.BaseDataProvider;
import io.wispforest.accessories.api.data.providers.slot.SlotBuilder;
import io.wispforest.accessories.data.SlotGroupLoader;
import io.wispforest.owo.serialization.CodecUtils;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import net.minecraft.data.DataProvider;
import net.minecraft.data.DataWriter;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.util.Identifier;

public abstract class GroupDataProvider extends BaseDataProvider<GroupDataProvider.GroupOutput> {

    private final Codec<RawSlotGroup> CODEC = CodecUtils.toCodec(RawSlotGroup.ENDEC);

    public GroupDataProvider(net.minecraft.data.DataOutput packOutput, CompletableFuture<RegistryWrapper.WrapperLookup> completableFuture) {
        super(packOutput, completableFuture);
    }

    public interface GroupOutput extends DataOutput {
        void accept(String namespace, RawSlotGroup slotType);
    }

    @Override
    protected abstract void buildData(RegistryWrapper.WrapperLookup provider, GroupOutput output);

    public SlotGroupBuilder builder(Identifier uniqueLocation) {
        return builder(uniqueLocation.toString());
    }

    public SlotGroupBuilder builder(String groupName) {
        return new SlotGroupBuilder(groupName, false);
    }

    //--

    @Override
    public final String getName() {
        return "SlotGroup";
    }

    @Override
    protected final String type() {
        return "accessories/group";
    }

    @Override
    protected final net.minecraft.data.DataOutput.OutputType target() {
        return net.minecraft.data.DataOutput.OutputType.DATA_PACK;
    }

    @Override
    protected final GroupOutput buildOutput(DataWriter cachedOutput, RegistryWrapper.WrapperLookup provider) {
        return new GroupOutput() {
            final Set<Identifier> set = Sets.newHashSet();
            final List<CompletableFuture<?>> list = new ArrayList<>();

            @Override
            public void accept(String namespace, RawSlotGroup rawSlotType) {
                var location = Identifier.of(namespace, rawSlotType.name().replace(":", "/"));

                if (!set.add(location)) throw new IllegalStateException("Duplicate Group: " + location);

                list.add(DataProvider.writeCodecToPath(cachedOutput, provider, CODEC, rawSlotType, GroupDataProvider.this.pathProvider().resolveJson(location)));
            }

            @Override
            public Collection<CompletableFuture<?>> futures() {
                return list;
            }
        };
    }
}
