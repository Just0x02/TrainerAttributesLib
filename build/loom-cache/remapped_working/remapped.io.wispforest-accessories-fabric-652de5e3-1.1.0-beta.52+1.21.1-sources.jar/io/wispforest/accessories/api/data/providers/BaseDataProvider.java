package io.wispforest.accessories.api.data.providers;

import com.mojang.logging.LogUtils;
import org.slf4j.Logger;

import java.util.Collection;
import java.util.concurrent.CompletableFuture;
import net.minecraft.data.DataProvider;
import net.minecraft.data.DataWriter;
import net.minecraft.registry.RegistryWrapper;

public abstract class BaseDataProvider<O extends BaseDataProvider.DataOutput> implements DataProvider {

    protected static final Logger LOGGER = LogUtils.getLogger();

    private final net.minecraft.data.DataOutput.PathResolver pathProvider;
    private final CompletableFuture<RegistryWrapper.WrapperLookup> registries;

    public BaseDataProvider(net.minecraft.data.DataOutput packOutput, CompletableFuture<RegistryWrapper.WrapperLookup> completableFuture) {
        this.pathProvider = packOutput.getResolver(target(), type());
        this.registries = completableFuture;
    }

    public net.minecraft.data.DataOutput.PathResolver pathProvider() {
        return this.pathProvider;
    }

    @Override
    public final CompletableFuture<?> run(DataWriter cachedOutput) {
        return this.registries.thenCompose(provider -> this.run(cachedOutput, provider));
    }

    private CompletableFuture<?> run(DataWriter cachedOutput, RegistryWrapper.WrapperLookup provider) {
        var output = buildOutput(cachedOutput, provider);

        this.buildData(provider, output);

        return CompletableFuture.allOf(output.futures().toArray(CompletableFuture[]::new));
    }

    public abstract String getName();

    protected abstract String type();

    protected abstract net.minecraft.data.DataOutput.OutputType target();

    protected abstract O buildOutput(DataWriter cachedOutput, RegistryWrapper.WrapperLookup provider);

    protected abstract void buildData(RegistryWrapper.WrapperLookup provider, O output);

    public interface DataOutput {
        Collection<CompletableFuture<?>> futures();
    }
}
