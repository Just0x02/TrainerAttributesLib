package io.wispforest.accessories.api;

import io.wispforest.accessories.api.slot.SlotReference;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.sound.SoundEvent;

/**
 * Represents a sound event with volume and pitch data.
 *
 * @see Accessory#getEquipSound(ItemStack, SlotReference)
 */
public record SoundEventData(RegistryEntry<SoundEvent> event, float volume, float pitch) { }
