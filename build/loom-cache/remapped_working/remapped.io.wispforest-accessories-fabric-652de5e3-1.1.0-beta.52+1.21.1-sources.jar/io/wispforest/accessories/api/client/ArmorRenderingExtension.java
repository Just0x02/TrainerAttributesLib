package io.wispforest.accessories.api.client;

import io.wispforest.accessories.api.slot.SlotReference;
import io.wispforest.accessories.mixin.client.LivingEntityRendererAccessor;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;

public interface ArmorRenderingExtension<T extends LivingEntity> {

    @Deprecated
    AccessoryRenderer RENDERER = new AccessoryArmorRenderer() {};

    default void renderEquipmentStack(ItemStack stack, MatrixStack poseStack, VertexConsumerProvider multiBufferSource, T livingEntity, EquipmentSlot equipmentSlot, int light, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
        throw new IllegalStateException("Injected interface method is unimplemented!");
    }
}