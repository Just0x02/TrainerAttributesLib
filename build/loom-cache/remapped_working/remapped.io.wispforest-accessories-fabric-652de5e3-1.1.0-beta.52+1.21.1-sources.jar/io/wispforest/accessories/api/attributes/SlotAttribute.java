package io.wispforest.accessories.api.attributes;

import com.google.common.collect.Multimap;
import io.wispforest.accessories.api.AccessoriesAPI;
import io.wispforest.accessories.api.slot.SlotType;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Identifier;

/**
 * Custom Attribute used to target an accessories Slot for modification of its size
 * based on the given {@link EntityAttributeModifier} within the Accessories System
 */
public class SlotAttribute extends EntityAttribute {

    private static final Map<String, RegistryEntry<EntityAttribute>> CACHED_ATTRIBUTES = new HashMap<>();

    private final String slotName;

    protected SlotAttribute(String slotName) {
        super(slotName, 0);

        this.slotName = slotName;
    }

    public String slotName(){
        return this.slotName;
    }

    /**
     * @deprecated Use {{@link #getAttributeHolder(SlotType)}}
     */
    @Deprecated(forRemoval = true)
    public static SlotAttribute getSlotAttribute(SlotType slotType){
        return getSlotAttribute(slotType.name());
    }

    /**
     * @deprecated Use {{@link #getAttributeHolder(String)}}
     */
    @Deprecated(forRemoval = true)
    public static SlotAttribute getSlotAttribute(String slotName){
        return (SlotAttribute) getAttributeHolder(slotName).value();
    }

    public static RegistryEntry<EntityAttribute> getAttributeHolder(SlotType slotType){
        return getAttributeHolder(slotType.name());
    }

    public static RegistryEntry<EntityAttribute> getAttributeHolder(String slotName){
        return CACHED_ATTRIBUTES.computeIfAbsent(slotName, string -> RegistryEntry.of(new SlotAttribute(slotName)));
    }

    //--

    public static void addSlotModifier(Multimap<RegistryEntry<EntityAttribute>, EntityAttributeModifier> map, SlotType slotType, Identifier location, double amount, EntityAttributeModifier.Operation operation) {
        addSlotModifier(map, slotType.name(), location, amount, operation);
    }

    public static void addSlotModifier(Multimap<RegistryEntry<EntityAttribute>, EntityAttributeModifier> map, String slot, Identifier location, double amount, EntityAttributeModifier.Operation operation) {
        map.put(SlotAttribute.getAttributeHolder(slot), new EntityAttributeModifier(location, amount, operation));
    }

    public static void addSlotAttribute(AccessoryAttributeBuilder builder, String targetSlot, Identifier location, double amount, EntityAttributeModifier.Operation operation, boolean isStackable) {
        if(isStackable) {
            builder.addStackable(SlotAttribute.getAttributeHolder(targetSlot), location, amount, operation);
        } else {
            builder.addExclusive(SlotAttribute.getAttributeHolder(targetSlot), location, amount, operation);
        }
    }

    public static void addSlotAttribute(ItemStack stack, String targetSlot, String boundSlot, Identifier location, double amount, EntityAttributeModifier.Operation operation, boolean isStackable) {
        AccessoriesAPI.addAttribute(stack, boundSlot, SlotAttribute.getAttributeHolder(targetSlot), location, amount, operation, isStackable);
    }
}
