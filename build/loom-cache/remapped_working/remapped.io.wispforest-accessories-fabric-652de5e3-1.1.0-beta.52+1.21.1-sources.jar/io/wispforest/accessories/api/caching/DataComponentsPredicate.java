package io.wispforest.accessories.api.caching;

import java.util.Arrays;
import net.minecraft.component.ComponentType;
import net.minecraft.item.ItemStack;

public class DataComponentsPredicate extends ItemStackBasedPredicate {

    public final ComponentType<?>[] dataComponentTypes;

    public DataComponentsPredicate(String name, ComponentType<?>... dataComponentTypes){
        super(name);

        this.dataComponentTypes = dataComponentTypes;
    }

    @Override
    public boolean test(ItemStack stack) {
        for (var dataComponentType : this.dataComponentTypes) {
            if (!stack.contains(dataComponentType)) return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return Arrays.hashCode(dataComponentTypes);
    }

    @Override
    protected boolean isEqual(Object other) {
        var itemComponentPredicate = (DataComponentsPredicate) other;

        return Arrays.equals(this.dataComponentTypes, itemComponentPredicate.dataComponentTypes);
    }

    @Override
    public String extraStringData() {
        return "DataComponents: " + Arrays.toString(this.dataComponentTypes);
    }
}
