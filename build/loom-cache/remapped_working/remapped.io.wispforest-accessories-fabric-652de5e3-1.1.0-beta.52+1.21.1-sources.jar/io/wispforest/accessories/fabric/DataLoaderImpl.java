package io.wispforest.accessories.fabric;

import io.wispforest.accessories.Accessories;
import io.wispforest.accessories.DataLoaderBase;
import io.wispforest.accessories.data.EntitySlotLoader;
import io.wispforest.accessories.data.SlotGroupLoader;
import io.wispforest.accessories.data.SlotTypeLoader;
import io.wispforest.accessories.impl.AccessoriesEventHandler;
import net.fabricmc.fabric.api.resource.IdentifiableResourceReloadListener;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.resource.ResourceManager;
import net.minecraft.resource.ResourceReloader;
import net.minecraft.resource.ResourceType;
import net.minecraft.util.Identifier;
import net.minecraft.util.profiler.Profiler;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

public class DataLoaderImpl extends DataLoaderBase {

    public static final Identifier SLOT_LOADER_LOCATION = Accessories.of("slot_loader");
    public static final Identifier ENTITY_SLOT_LOADER_LOCATION = Accessories.of("entity_slot_loader");
    public static final Identifier SLOT_GROUP_LOADER_LOCATION = Accessories.of("slot_group_loader");

    private IdentifiableResourceReloadListener identifiedSlotLoader = null;
    private IdentifiableResourceReloadListener identifiedEntitySlotLoader = null;

    @Override
    protected Optional<ResourceReloader> getIdentifiedSlotLoader() {
        return Optional.ofNullable(identifiedSlotLoader);
    }

    @Override
    protected Optional<ResourceReloader> getIdentifiedEntitySlotLoader() {
        return Optional.ofNullable(identifiedEntitySlotLoader);
    }

    @Override
    public void registerListeners() {
        var manager = ResourceManagerHelper.get(ResourceType.SERVER_DATA);

        this.identifiedSlotLoader = new IdentifiableResourceReloadListenerImpl(SLOT_LOADER_LOCATION, SlotTypeLoader.INSTANCE);
        this.identifiedEntitySlotLoader = new IdentifiableResourceReloadListenerImpl(ENTITY_SLOT_LOADER_LOCATION, EntitySlotLoader.INSTANCE, SLOT_LOADER_LOCATION);

        manager.registerReloadListener(identifiedSlotLoader);
        manager.registerReloadListener(identifiedEntitySlotLoader);
        manager.registerReloadListener(new IdentifiableResourceReloadListenerImpl(SLOT_GROUP_LOADER_LOCATION, SlotGroupLoader.INSTANCE, SLOT_LOADER_LOCATION));

        manager.registerReloadListener(new SimpleSynchronousResourceReloadListener() {
            @Override
            public Identifier getFabricId() {
                return Accessories.of("data_reload_hook");
            }

            @Override
            public void onResourceManagerReload(ResourceManager resourceManager) {
                AccessoriesEventHandler.dataReloadOccurred = true;
            }
        });

        super.registerListeners();
    }

    public record IdentifiableResourceReloadListenerImpl(Identifier location, ResourceReloader listener, Set<Identifier> dependencies) implements IdentifiableResourceReloadListener {

        public IdentifiableResourceReloadListenerImpl(Identifier location, ResourceReloader listener, Identifier ...dependencies){
            this(location, listener, new HashSet<>(List.of(dependencies)));
        }

        @Override
        public Identifier getFabricId() {
            return this.location;
        }

        @Override
        public CompletableFuture<Void> reload(PreparationBarrier preparationBarrier, ResourceManager resourceManager, Profiler preparationsProfiler, Profiler reloadProfiler, Executor backgroundExecutor, Executor gameExecutor) {
            return this.listener.reload(preparationBarrier, resourceManager, preparationsProfiler, reloadProfiler, backgroundExecutor, gameExecutor);
        }

        @Override
        public Collection<Identifier> getFabricDependencies() {
            return dependencies;
        }
    }
}
