package io.wispforest.accessories.fabric.mixin;

import io.wispforest.accessories.fabric.ExtraEntityTrackingEvents;
import net.minecraft.entity.Entity;
import net.minecraft.server.network.EntityTrackerEntry;
import net.minecraft.server.network.ServerPlayerEntity;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(EntityTrackerEntry.class)
public abstract class ServerEntityEvent {

    @Shadow @Final private Entity entity;

    @Inject(method = "addPairing", at = @At("TAIL"))
    private void onStartTracking(ServerPlayerEntity player, CallbackInfo ci) {
        ExtraEntityTrackingEvents.POST_START_TRACKING.invoker().onStartTracking(this.entity, player);
    }
}
