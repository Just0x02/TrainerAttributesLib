package io.wispforest.accessories.fabric.mixin.client;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import io.wispforest.accessories.AccessoriesInternals;
import io.wispforest.accessories.AccessoriesLoaderInternals;
import io.wispforest.accessories.api.client.ArmorRenderingExtension;
import io.wispforest.accessories.compat.GeckoLibCompat;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.feature.ArmorFeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import software.bernie.geckolib.util.InternalUtil;

@Mixin(ArmorFeatureRenderer.class)
public abstract class HumanoidArmorLayerMixin<T extends LivingEntity, M extends BipedEntityModel<T>, A extends BipedEntityModel<T>> extends FeatureRenderer<T, M> implements ArmorRenderingExtension<T> {

    public HumanoidArmorLayerMixin(FeatureRendererContext<T, M> renderer) {
        super(renderer);
    }

    @Shadow
    protected abstract void renderArmorPiece(MatrixStack poseStack, VertexConsumerProvider multiBufferSource, T livingEntity, EquipmentSlot equipmentSlot, int i, A humanoidModel);

    @Shadow
    private A getArmorModel(EquipmentSlot slot) { return null; }

    @Shadow protected abstract void setPartVisibility(A humanoidModel, EquipmentSlot equipmentSlot);

    @Unique
    @Nullable
    private ItemStack tempStack = null;

    @Override
    public void renderEquipmentStack(ItemStack stack, MatrixStack poseStack, VertexConsumerProvider multiBufferSource, T livingEntity, EquipmentSlot equipmentSlot, int light, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
        this.tempStack = stack;

        if (!attemptGeckoRender(stack, poseStack, multiBufferSource, livingEntity, equipmentSlot, light, limbSwing, limbSwingAmount, partialTicks, ageInTicks, netHeadYaw, headPitch)) {
            this.renderArmorPiece(poseStack, multiBufferSource, livingEntity, equipmentSlot, light, this.getArmorModel(equipmentSlot));
        }

        this.tempStack = null;
    }

    @WrapOperation(method = "renderArmorPiece", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/LivingEntity;getItemBySlot(Lnet/minecraft/world/entity/EquipmentSlot;)Lnet/minecraft/world/item/ItemStack;"))
    private ItemStack getAlternativeStack(LivingEntity instance, EquipmentSlot equipmentSlot, Operation<ItemStack> original) {
        if (tempStack != null) return tempStack;

        return original.call(instance, equipmentSlot);
    }

    @Unique
    private boolean attemptGeckoRender(ItemStack stack, MatrixStack poseStack, VertexConsumerProvider multiBufferSource, T livingEntity, EquipmentSlot equipmentSlot, int light, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
        if (!AccessoriesLoaderInternals.isModLoaded("geckolib")) return false;

        return GeckoLibCompat.renderGeckoArmor(poseStack, multiBufferSource, livingEntity, stack, equipmentSlot, this.getContextModel(), this.getArmorModel(equipmentSlot), partialTicks, light, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, this::setPartVisibility);
    }
}
