package io.wispforest.accessories.fabric;

import com.google.common.collect.Multimap;
import com.google.gson.JsonObject;
import com.mojang.brigadier.arguments.ArgumentType;
import io.wispforest.accessories.api.AccessoriesHolder;

import io.wispforest.accessories.impl.AccessoriesHolderImpl;
import io.wispforest.accessories.menu.AccessoriesMenuData;
import io.wispforest.accessories.menu.AccessoriesMenuVariant;
import io.wispforest.accessories.menu.variants.AccessoriesMenuBase;
import io.wispforest.accessories.mixin.ItemStackAccessor;
import io.wispforest.accessories.utils.ManagedEndecDataLoader;
import io.wispforest.endec.Endec;
import io.wispforest.owo.serialization.CodecUtils;
import net.fabricmc.fabric.api.command.v2.ArgumentTypeRegistry;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.item.PlayerInventoryStorage;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.fabricmc.fabric.impl.resource.conditions.ResourceConditionsImpl;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.command.argument.serialize.ArgumentSerializer;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.registry.tag.TagManagerLoader;
import net.minecraft.resource.ResourceType;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.apache.commons.lang3.function.TriFunction;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.function.Consumer;
import java.util.function.UnaryOperator;
import java.util.stream.Collectors;

public class AccessoriesInternalsImpl {

    public static AccessoriesHolder getHolder(LivingEntity livingEntity){
        return livingEntity.getAttachedOrCreate(AccessoriesFabric.HOLDER_ATTACHMENT_TYPE);
    }

    public static void modifyHolder(LivingEntity livingEntity, UnaryOperator<AccessoriesHolderImpl> modifier){
        var holder = (AccessoriesHolderImpl) getHolder(livingEntity);

        holder = modifier.apply(holder);

        livingEntity.setAttached(AccessoriesFabric.HOLDER_ATTACHMENT_TYPE, holder);
    }

    public static final ThreadLocal<Map<RegistryKey<?>, Map<Identifier, Collection<RegistryEntry<?>>>>> LOADED_TAGS = new ThreadLocal<>();

    public static void setTags(List<TagManagerLoader.RegistryTags<?>> tags) {
        Map<RegistryKey<?>, Map<Identifier, Collection<RegistryEntry<?>>>> tagMap = new IdentityHashMap<>();

        for (TagManagerLoader.RegistryTags<?> registryTags : tags) {
            tagMap.put(registryTags.key(), (Map) registryTags.tags());
        }

        LOADED_TAGS.set(tagMap);
    }

    public static <T> Optional<Collection<RegistryEntry<T>>> getHolder(TagKey<T> tagKey){
        var tags = LOADED_TAGS.get().get(tagKey.registry());

        if(tags == null) return Optional.empty();

        var holders = tags.get(tagKey.id());

        if(holders == null) return Optional.empty();

        var converted = holders
                .stream()
                .map(holder -> (RegistryEntry<T>) holder)
                .collect(Collectors.toUnmodifiableSet());

        return Optional.of(converted);
    }

    //--

    public static void giveItemToPlayer(ServerPlayerEntity player, ItemStack stack) {
        if(stack.isEmpty()) return;

        try(var transaction = Transaction.openOuter()) {
            PlayerInventoryStorage.of(player).offerOrDrop(ItemVariant.of(stack), stack.getCount(), transaction);
            transaction.commit();
        }
    }

    public static boolean isValidOnConditions(JsonObject object, String dataType, Identifier key, @Nullable RegistryWrapper.WrapperLookup registryLookup) {
        return ResourceConditionsImpl.applyResourceConditions(object, dataType, key, registryLookup);
    }

    public static <T extends ScreenHandler, D> ScreenHandlerType<T> registerMenuType(Identifier location, Endec<D> endec, TriFunction<Integer, PlayerInventory, D, T> func){
        return Registry.register(Registries.SCREEN_HANDLER, location, new ExtendedScreenHandlerType<>(func::apply, CodecUtils.toPacketCodec(endec)));
    }

    public static <A extends ArgumentType<?>, T extends ArgumentSerializer.ArgumentTypeProperties<A>, I extends ArgumentSerializer<A, T>> I registerCommandArgumentType(Identifier location, Class<A> clazz, I info) {
        ArgumentTypeRegistry.registerArgumentType(location, clazz, info);

        return info;
    }

    public static void openAccessoriesMenu(PlayerEntity player, AccessoriesMenuVariant variant, @Nullable LivingEntity targetEntity, @Nullable ItemStack carriedStack) {
        player.openHandledScreen(new ExtendedScreenHandlerFactory<AccessoriesMenuData>() {
            @Override
            public AccessoriesMenuData getScreenOpeningData(ServerPlayerEntity player) {
                return AccessoriesMenuData.of(targetEntity, ((AccessoriesMenuBase) player.currentScreenHandler));
            }

            @Override
            public Text getDisplayName() { return Text.empty(); }

            @Override
            public boolean shouldCloseCurrentScreen() {
                return false;
            }

            @Nullable
            @Override
            public ScreenHandler createMenu(int i, PlayerInventory inventory, PlayerEntity player) {
                return AccessoriesMenuVariant.openMenu(i, inventory, variant, targetEntity, carriedStack);
            }
        });
    }

    public static void addAttributeTooltips(@Nullable PlayerEntity player, ItemStack stack, Multimap<RegistryEntry<EntityAttribute>, EntityAttributeModifier> multimap, Consumer<Text> tooltipAddCallback, Item.TooltipContext context, TooltipType flag) {
        for (Map.Entry<RegistryEntry<EntityAttribute>, EntityAttributeModifier> entry : multimap.entries()) {
            ((ItemStackAccessor) (Object) ItemStack.EMPTY).accessories$addModifierTooltip(tooltipAddCallback, player, entry.getKey(), entry.getValue());
        }
    }

    public static void registerLoader(ManagedEndecDataLoader<?> loader, Consumer<RegistryWrapper.WrapperLookup> registrySetCall) {
        ResourceManagerHelper.get(ResourceType.SERVER_DATA).registerReloadListener(loader.getLoaderId(), provider -> {
            registrySetCall.accept(provider);

            return new DataLoaderImpl.IdentifiableResourceReloadListenerImpl(loader.getLoaderId(), loader);
        });
    }
}
