package io.wispforest.accessories.fabric.mixin;

import io.wispforest.accessories.impl.AccessoriesEventHandler;
import io.wispforest.accessories.pond.DroppedStacksExtension;
import java.util.Collection;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.server.world.ServerWorld;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {

    @Inject(method = "tick", at = @At("HEAD"))
    private void accessories$tick(CallbackInfo ci){
        AccessoriesEventHandler.onLivingEntityTick((LivingEntity)(Object)this);
    }

    @Inject(method = "dropAllDeathLoot", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/LivingEntity;dropEquipment()V"))
    private void handleAccessoriesDrop(ServerWorld level, DamageSource damageSource, CallbackInfo ci) {
        var entity = (LivingEntity) (Object) this;
        var droppedStacks = AccessoriesEventHandler.onDeath(entity, damageSource);

        if (droppedStacks == null) return;

        if (this instanceof DroppedStacksExtension playerExtension) {
            playerExtension.addToBeDroppedStacks(droppedStacks);
        } else {
            for (var droppedStack : droppedStacks) {
                entity.dropStack(droppedStack);
            }
        }
    }
}
