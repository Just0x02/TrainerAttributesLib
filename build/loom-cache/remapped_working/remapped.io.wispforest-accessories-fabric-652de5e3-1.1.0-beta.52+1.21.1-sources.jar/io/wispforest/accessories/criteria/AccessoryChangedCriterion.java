package io.wispforest.accessories.criteria;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.wispforest.accessories.api.slot.SlotReference;
import io.wispforest.accessories.data.SlotGroupLoader;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.Optional;
import net.minecraft.advancement.criterion.AbstractCriterion;
import net.minecraft.item.ItemStack;
import net.minecraft.predicate.entity.EntityPredicate;
import net.minecraft.predicate.entity.LootContextPredicate;
import net.minecraft.predicate.item.ItemPredicate;
import net.minecraft.server.network.ServerPlayerEntity;

public class AccessoryChangedCriterion extends AbstractCriterion<AccessoryChangedCriterion.Conditions> {

    public void trigger(ServerPlayerEntity player, ItemStack accessory, SlotReference reference, Boolean cosmetic) {
        this.trigger(player, conditions -> {
            return conditions.itemPredicates().map(predicates -> predicates.stream().allMatch(predicate -> predicate.test(accessory))).orElse(true)
                    && conditions.groups().flatMap(groups -> SlotGroupLoader.INSTANCE.findGroup(false, reference.slotName()).map(group -> groups.stream().noneMatch(s -> s.equals(group.name())))).orElse(true)
                    && conditions.slots().map(slots -> slots.stream().noneMatch(reference.slotName()::equals)).orElse(true)
                    && conditions.indices().map(indices -> indices.stream().noneMatch(index -> index == reference.slot())).orElse(true)
                    && conditions.cosmetic().map(isCosmetic -> isCosmetic && cosmetic).orElse(true);
        });
    }

    @Override
    public @NotNull Codec<io.wispforest.accessories.criteria.AccessoryChangedCriterion.Conditions> getConditionsCodec() {
        return io.wispforest.accessories.criteria.AccessoryChangedCriterion.Conditions.CODEC;
    }

    public record Conditions(
            Optional<LootContextPredicate> player,
            Optional<List<ItemPredicate>> itemPredicates,
            Optional<List<String>> groups,
            Optional<List<String>> slots,
            Optional<List<Integer>> indices,
            Optional<Boolean> cosmetic
    ) implements SimpleInstance {
        public static final Codec<io.wispforest.accessories.criteria.AccessoryChangedCriterion.Conditions> CODEC = RecordCodecBuilder.create(instance -> instance.group(
                EntityPredicate.LOOT_CONTEXT_PREDICATE_CODEC.optionalFieldOf("player").forGetter(io.wispforest.accessories.criteria.AccessoryChangedCriterion.Conditions::player),
                ItemPredicate.CODEC.listOf().optionalFieldOf("items").forGetter(io.wispforest.accessories.criteria.AccessoryChangedCriterion.Conditions::itemPredicates),
                Codec.STRING.listOf().optionalFieldOf("groups").forGetter(io.wispforest.accessories.criteria.AccessoryChangedCriterion.Conditions::groups),
                Codec.STRING.listOf().optionalFieldOf("slots").forGetter(io.wispforest.accessories.criteria.AccessoryChangedCriterion.Conditions::slots),
                Codec.INT.listOf().optionalFieldOf("indices").forGetter(io.wispforest.accessories.criteria.AccessoryChangedCriterion.Conditions::indices),
                Codec.BOOL.optionalFieldOf("cosmetic").forGetter(io.wispforest.accessories.criteria.AccessoryChangedCriterion.Conditions::cosmetic)
                ).apply(instance, io.wispforest.accessories.criteria.AccessoryChangedCriterion.Conditions::new));
    }
}