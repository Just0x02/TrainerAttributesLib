package io.wispforest.accessories.client.gui;

import Z;
import com.mojang.blaze3d.systems.RenderSystem;
import io.wispforest.accessories.Accessories;
import io.wispforest.accessories.api.menu.AccessoriesBasedSlot;
import io.wispforest.accessories.networking.AccessoriesNetworking;
import io.wispforest.accessories.networking.server.SyncCosmeticToggle;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ButtonTextures;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import org.jetbrains.annotations.Nullable;

import java.util.function.Consumer;

public class ToggleButton extends ButtonWidget {

    private static final ButtonTextures SPRITES = new ButtonTextures(
            Identifier.ofVanilla("widget/button"),
            Identifier.ofVanilla("widget/button_disabled"),
            Identifier.ofVanilla("widget/button_highlighted"));

    private boolean toggled = false;

    private final int zIndex;

    private final Consumer<ToggleButton> onRender;

    protected ToggleButton(int x, int y, int zIndex, int width, int height, Text message, PressAction onPress, NarrationSupplier createNarration, Consumer<ToggleButton> onRender) {
        super(x, y, width, height, message, onPress, createNarration);

        this.zIndex = zIndex;
        this.onRender = onRender;
    }

    public static ToggleButton ofSlot(int x, int y, int z, AccessoriesBasedSlot slot) {
        return ToggleButton.toggleBuilder(Text.empty(), btn -> {
                    AccessoriesNetworking.sendToServer(SyncCosmeticToggle.of(slot.entity.equals(MinecraftClient.getInstance().player) ? null : slot.entity, slot.accessoriesContainer.slotType(), slot.getIndex()));
                }).onRender(btn -> {
                    var bl = slot.accessoriesContainer.shouldRender(slot.getIndex());

                    if (bl == btn.toggled()) return;

                    btn.toggled(bl);
                    btn.setTooltip(accessoriesToggleTooltip(bl));
                }).tooltip(accessoriesToggleTooltip(slot.accessoriesContainer.shouldRender(slot.getIndex())))
                .zIndex(z)
                .bounds(x, y, 5, 5)
                .build()
                .toggled(slot.accessoriesContainer.shouldRender(slot.getIndex()));
    }

    private static Tooltip accessoriesToggleTooltip(boolean value) {
        var key = "display.toggle." + (!value ? "show" : "hide");

        return Tooltip.of(Text.translatable(Accessories.translationKey(key)));
    }

    public ToggleButton toggled(boolean value){
        this.toggled = value;

        return this;
    }

    public boolean toggled(){
        return this.toggled;
    }

    @Override
    public void onPress() {
        this.onPress.onPress(this);
    }

    public static ToggleButton.Builder toggleBuilder(Text message, ButtonWidget.PressAction onPress) {
        return new ToggleButton.Builder(message, onPress);
    }

    @Override
    protected void renderWidget(DrawContext guiGraphics, int mouseX, int mouseY, float partialTick) {
        this.onRender.accept(this);

        var pose = guiGraphics.getMatrices();

        pose.push();
        pose.translate(0, 0, zIndex);

        guiGraphics.setShaderColor(1.0F, 1.0F, 1.0F, this.alpha);
        RenderSystem.enableBlend();
        RenderSystem.enableDepthTest();
        guiGraphics.drawGuiTexture(SPRITES.get(this.toggled(), this.isSelected()), this.getX(), this.getY(), this.getWidth(), this.getHeight());
        guiGraphics.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        int i = this.active ? 16777215 : 10526880;
        this.drawMessage(guiGraphics, MinecraftClient.getInstance().textRenderer, i | MathHelper.ceil(this.alpha * 255.0F) << 24);

        pose.pop();
    }

    @Environment(EnvType.CLIENT)
    public static class Builder {
        private final Text message;
        private final ButtonWidget.PressAction onPress;
        @Nullable
        private Tooltip tooltip;
        private int x;
        private int y;
        private int zIndex = 0;
        private int width = 150;
        private int height = 20;
        private ButtonWidget.NarrationSupplier createNarration = ButtonWidget.DEFAULT_NARRATION_SUPPLIER;

        private Consumer<ToggleButton> onRender = toggleButton -> {};

        public Builder(Text message, ButtonWidget.PressAction onPress) {
            this.message = message;
            this.onPress = onPress;
        }

        public ToggleButton.Builder pos(int x, int y) {
            this.x = x;
            this.y = y;
            return this;
        }

        public ToggleButton.Builder zIndex(int zIndex){
            this.zIndex = zIndex;

            return this;
        }

        public ToggleButton.Builder onRender(Consumer<ToggleButton> consumer){
            this.onRender = consumer;

            return this;
        }

        public ToggleButton.Builder width(int width) {
            this.width = width;
            return this;
        }

        public ToggleButton.Builder size(int width, int height) {
            this.width = width;
            this.height = height;
            return this;
        }

        public ToggleButton.Builder bounds(int x, int y, int width, int height) {
            return this.pos(x, y).size(width, height);
        }

        public ToggleButton.Builder tooltip(@Nullable Tooltip tooltip) {
            this.tooltip = tooltip;
            return this;
        }

        public ToggleButton.Builder createNarration(ButtonWidget.NarrationSupplier createNarration) {
            this.createNarration = createNarration;
            return this;
        }

        public ToggleButton build() {
            ToggleButton button = new ToggleButton(this.x, this.y, this.zIndex, this.width, this.height, this.message, this.onPress, this.createNarration, this.onRender);

            button.setTooltip(this.tooltip);
            return button;
        }
    }
}
