package io.wispforest.accessories.client;

import I;
import io.wispforest.accessories.client.gui.AccessoriesScreen;
import net.minecraft.client.render.VertexConsumer;
import org.joml.Vector3d;
import org.joml.Vector4i;

/**
 * Mean Position of all the Vertices™ (MPOATV)
 */
public final class MPOATVConstructingVertexConsumer implements VertexConsumer {

    private double minX = Double.MAX_VALUE;
    private double minY = Double.MAX_VALUE;
    private double minZ = Double.MAX_VALUE;
    private double maxX = -Double.MAX_VALUE;
    private double maxY = -Double.MAX_VALUE;
    private double maxZ = -Double.MAX_VALUE;

    private Vector3d meanPos = null;

    public Vector3d meanPos(){
        return this.meanPos;
    }

    @Override
    public VertexConsumer vertex(float x, float y, float z) {
        var leeway = 10;

        var box = AccessoriesScreen.SCISSOR_BOX;

        if ((x >= box.x - leeway && x <= box.z + leeway) && (y >= box.y - leeway && y <= box.w + leeway)) {
            this.minX = Math.min(this.minX, x);
            this.maxX = Math.max(this.maxX, x);

            this.minY = Math.min(this.minY, y);
            this.maxY = Math.max(this.maxY, y);

            this.minZ = Math.min(this.minZ, z);
            this.maxZ = Math.max(this.maxZ, z);
        }

        this.meanPos = new Vector3d((this.minX + this.maxX) / 2, (this.minY + this.maxY) / 2, (this.minZ + this.maxZ) / 2);

        return this;
    }

    @Override public VertexConsumer color(int i, int j, int k, int l) { return this; }
    @Override public VertexConsumer texture(float f, float g) { return this; }
    @Override public VertexConsumer overlay(int i, int j) { return this; }
    @Override public VertexConsumer light(int i, int j) { return this; }
    @Override public VertexConsumer normal(float f, float g, float h) { return this; }
}