package io.wispforest.accessories.client.gui.components;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import io.wispforest.owo.ui.base.BaseComponent;
import io.wispforest.owo.ui.core.OwoUIDrawContext;
import io.wispforest.owo.ui.core.Sizing;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;
import org.joml.Matrix4f;

public class PixelPerfectTextureComponent extends BaseComponent {

    private final Identifier texture;

    private final int textureWidth;
    private final int textureHeight;

    public PixelPerfectTextureComponent(Identifier texture, int textureWidth, int textureHeight, Sizing horizontalSizing, Sizing verticalSizing) {
        super();

        this.texture = texture;

        this.textureWidth = textureWidth;
        this.textureHeight = textureHeight;

        if(horizontalSizing.isContent()) throw new IllegalStateException("HorizontalSizing of PixelPerfectTextureComponent was found to be Content Sizing, which is not allowed!");
        if(verticalSizing.isContent()) throw new IllegalStateException("VerticalSizing of PixelPerfectTextureComponent was found to be Content Sizing, which is not allowed!");

        this.horizontalSizing(horizontalSizing);
        this.verticalSizing(verticalSizing);
    }

    @Override
    public void draw(OwoUIDrawContext context, int mouseX, int mouseY, float partialTicks, float delta) {
        drawPixelPerfectTextureQuad(context, texture, textureWidth, textureHeight, this.x(), this.y(), 0, this.width(), this.height());
    }

    public static void drawPixelPerfectTextureQuad(OwoUIDrawContext context, Identifier texture, int textureWidth, int textureHeight, int x1, int y1, float z, int width, int height) {
        int x2 = x1 + width;
        int y2 = y1 + height;

        RenderSystem.setShaderTexture(0, texture);
        RenderSystem.setShader(GameRenderer::getPositionTexProgram);

        Matrix4f matrix4f = context.getMatrices().peek().getPositionMatrix();

        BufferBuilder bufferBuilder = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE);

        bufferBuilder.vertex(matrix4f, x1, y1, z)
                .texture(0, 0);

        bufferBuilder.vertex(matrix4f, x1, y2, z)
                .texture(0, 1);

        bufferBuilder.vertex(matrix4f, x2, y2, z)
                .texture(1, 1);

        bufferBuilder.vertex(matrix4f, x2, y1, z)
                .texture(1, 0);

        BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
    }
}
