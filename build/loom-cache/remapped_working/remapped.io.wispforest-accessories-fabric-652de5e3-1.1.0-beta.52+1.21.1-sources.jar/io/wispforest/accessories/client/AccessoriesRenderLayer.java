package io.wispforest.accessories.client;

import F;
import J;
import Z;
import com.mojang.blaze3d.platform.GlStateManager;
import io.wispforest.accessories.Accessories;
import io.wispforest.accessories.api.AccessoriesCapability;
import io.wispforest.accessories.api.AccessoriesContainer;
import io.wispforest.accessories.api.client.AccessoriesRendererRegistry;
import io.wispforest.accessories.api.client.AccessoryRenderer;
import io.wispforest.accessories.api.slot.SlotReference;
import io.wispforest.accessories.client.gui.AccessoriesScreen;
import io.wispforest.accessories.client.gui.AccessoriesScreenBase;
import io.wispforest.accessories.impl.ExpandedSimpleContainer;
import io.wispforest.accessories.menu.AccessoriesInternalSlot;
import org.apache.commons.lang3.mutable.MutableBoolean;
import org.lwjgl.opengl.GL30;

import java.awt.*;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexConsumers;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;


/**
 * Render layer used to render equipped Accessories for a given {@link LivingEntity}.
 * This is only applied to {@link LivingEntityRenderer} that have a model that
 * extends {@link BipedEntityModel}
 */
public class AccessoriesRenderLayer<T extends LivingEntity, M extends EntityModel<T>> extends FeatureRenderer<T, M> {

    private static final PostEffectBuffer BUFFER = new PostEffectBuffer();

    private static final float increment = 0.1f;

    private static Map<String, Float> brightnessMap = new HashMap<>();
    private static Map<String, Float> opacityMap = new HashMap<>();

    private static long lastUpdated20th = 0;

    public AccessoriesRenderLayer(FeatureRendererContext<T, M> renderLayerParent) {
        super(renderLayerParent);
    }

    @Override
    public void render(
            MatrixStack poseStack,
            VertexConsumerProvider multiBufferSource,
            int light,
            T entity,
            float limbSwing,
            float limbSwingAmount,
            float partialTicks,
            float ageInTicks,
            float netHeadYaw,
            float headPitch
    ) {
        var capability = AccessoriesCapability.get(entity);

        if (capability == null) return;

        var containers = capability.getContainers();

        if (containers.isEmpty()) return;

        var renderingLines = AccessoriesScreen.COLLECT_ACCESSORY_POSITIONS.getValue();

        if (!renderingLines && !AccessoriesScreen.NOT_VERY_NICE_POSITIONS.isEmpty()) {
            AccessoriesScreen.NOT_VERY_NICE_POSITIONS.clear();
        }

        var useCustomerBuffer = AccessoriesScreenBase.IS_RENDERING_UI_ENTITY.getValue();

        if (useCustomerBuffer && multiBufferSource instanceof VertexConsumerProvider.Immediate bufferSource) {
            bufferSource.draw();
        }

        var scale = (float) (1 + (0.5 * (0.75 + (Math.sin((System.currentTimeMillis()) / 250d)))));

        var calendar = Calendar.getInstance();

        var current20th = calendar.getTimeInMillis() / 50;

        var shouldUpdate = lastUpdated20th != current20th;
        if (shouldUpdate) lastUpdated20th = current20th;

        AccessoriesInternalSlot selected = null;

        if (MinecraftClient.getInstance().currentScreen instanceof AccessoriesScreenBase screenBase && screenBase.getHoveredSlot() instanceof AccessoriesInternalSlot slot) {
            selected = slot;
        }

        boolean preventHovering = selected != null && selected.getStack().isEmpty();

        var unHoveredOptions = Accessories.config().screenOptions.unHoveredOptions;
        var hoveredOptions = Accessories.config().screenOptions.hoveredOptions;

        var isFunnyDate = calendar.get(Calendar.MONTH) + 1 == 5 && calendar.get(Calendar.DATE) == 16;

        for (var entry : containers.entrySet()) {
            var container = entry.getValue();

            var accessories = container.getAccessories();
            var cosmetics = container.getCosmeticAccessories();

            var containerSelected = selected != null && selected.accessoriesContainer.slotType() == container.slotType();

            for (int i = 0; i < accessories.size(); i++) {
                var isSelected = containerSelected && selected.getIndex() == i;

                var stack = accessories.getStack(i);
                var cosmeticStack = cosmetics.getStack(i);

                if (!cosmeticStack.isEmpty() && Accessories.config().clientOptions.showCosmeticAccessories()) stack = cosmeticStack;

                // No stack to renderer so no need to run any code
                if (stack.isEmpty()) continue;

                var renderer = AccessoriesRendererRegistry.getRenderer(stack);

                // No Renderer to render meaning no need to run any code
                if (renderer.isEmpty() || !renderer.shouldRender(container.shouldRender(i))) continue;

                var mapKey = entry.getKey() + i;

                if (shouldUpdate) {
                    var currentBrightness = brightnessMap.getOrDefault(mapKey, 1f);
                    var currentOpacity = opacityMap.getOrDefault(mapKey, 1f);

                    if (selected != null && !isSelected && !preventHovering) {
                        brightnessMap.put(mapKey, Math.max(unHoveredOptions.darkenedBrightness(), currentBrightness - increment));
                        opacityMap.put(mapKey, Math.max(unHoveredOptions.darkenedOpacity(), currentOpacity - increment));
                    } else {
                        brightnessMap.put(mapKey, Math.min(1, currentBrightness + increment));
                        opacityMap.put(mapKey, Math.min(1, currentOpacity + increment));
                    }
                }

                var mpoatv = new MPOATVConstructingVertexConsumer();

                var bufferedGrabbedFlag = new MutableBoolean(false);

                VertexConsumerProvider innerBufferSource = (renderType) -> {
                    bufferedGrabbedFlag.setValue(true);

                    return useCustomerBuffer ?
                            VertexConsumers.union(multiBufferSource.getBuffer(renderType), mpoatv) :
                            multiBufferSource.getBuffer(renderType);
                };

                if (!AccessoriesScreenBase.IS_RENDERING_UI_ENTITY.getValue() || isSelected || selected == null || unHoveredOptions.renderUnHovered()) {
                    poseStack.push();

                    try {
                        renderer.render(
                                stack,
                                SlotReference.of(entity, container.getSlotName(), i),
                                poseStack,
                                getContextModel(),
                                innerBufferSource,
                                light,
                                limbSwing,
                                limbSwingAmount,
                                partialTicks,
                                ageInTicks,
                                netHeadYaw,
                                headPitch
                        );
                    } catch (Throwable e) {
                        AccessoryRendererErrorCache.logIfTimeAllotted(entity, stack, renderer, e);
                    }

                    poseStack.pop();
                }

                float[] colorValues = null;

                if (useCustomerBuffer && bufferedGrabbedFlag.getValue()) {
                    if (multiBufferSource instanceof VertexConsumerProvider.Immediate bufferSource) {
                        if (hoveredOptions.brightenHovered() && isSelected) {
                            if (isFunnyDate) {
                                var hue = (float) ((System.currentTimeMillis() / 20d % 360d) / 360d);
                                var color = new Color(MathHelper.hsvToRgb(hue, 1, 1));

                                colorValues = new float[]{color.getRed() / 128f, color.getGreen() / 128f, color.getBlue() / 128f, 1};
                            } else {
                                var mul = hoveredOptions.cycleBrightness() ? scale : 1.5f;

                                colorValues = new float[]{mul, mul, mul, 1};
                            }
                        } else if (unHoveredOptions.darkenUnHovered()) {
                            var darkness = brightnessMap.getOrDefault(mapKey, 1f);

                            colorValues = new float[]{darkness, darkness, darkness, opacityMap.getOrDefault(mapKey, 1f)};
                        }

                        if (colorValues != null) {
                            BUFFER.beginWrite(true, GL30.GL_DEPTH_BUFFER_BIT);
                            bufferSource.draw();
                            BUFFER.endWrite();

                            BUFFER.draw(colorValues);

                            var frameBuffer = BUFFER.buffer();

                            GlStateManager._glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, frameBuffer.fbo);
                            GL30.glBlitFramebuffer(
                                    0,
                                    0,
                                    frameBuffer.textureWidth,
                                    frameBuffer.textureHeight,
                                    0,
                                    0,
                                    frameBuffer.textureWidth,
                                    frameBuffer.textureHeight,
                                    GL30.GL_DEPTH_BUFFER_BIT,
                                    GL30.GL_NEAREST
                            );
                            MinecraftClient.getInstance().getFramebuffer().beginWrite(false);
                        } else {
                            bufferSource.draw();
                        }
                    }

                    if (renderingLines && AccessoriesScreen.IS_RENDERING_LINE_TARGET.getValue()) {
                        AccessoriesScreen.NOT_VERY_NICE_POSITIONS.put(container.getSlotName() + i, mpoatv.meanPos());
                    }
                }
            }
        }
    }
}
