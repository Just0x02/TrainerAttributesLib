package io.wispforest.accessories.client;

import F;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import io.wispforest.accessories.mixin.client.GuiGraphicsAccessor;
import io.wispforest.owo.client.OwoClient;
import io.wispforest.owo.ui.core.OwoUIDrawContext;
import io.wispforest.owo.util.pond.OwoTessellatorExtension;
import org.apache.logging.log4j.util.BiConsumer;
import org.apache.logging.log4j.util.TriConsumer;
import org.joml.Matrix4f;
import org.joml.Vector4f;

import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.texture.Scaling;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

public class GuiGraphicsUtils {

    public static void blitSpriteBatched(DrawContext guiGraphics, Identifier sprite, int x, int y, int width, int height) {
        blitSpriteBatched(guiGraphics, sprite, x, y, 0, width, height);
    }

    public static void blitSpriteBatched(DrawContext guiGraphics, Identifier sprite, int x, int y, int blitOffset, int width, int height) {
        var sprites = MinecraftClient.getInstance().getGuiAtlasManager();

        Sprite textureAtlasSprite = sprites.getSprite(sprite);
        Scaling guiSpriteScaling = sprites.getScaling(textureAtlasSprite);

        if (guiSpriteScaling instanceof Scaling.Stretch) {
            ((GuiGraphicsAccessor) guiGraphics).callBlitSprite(textureAtlasSprite, x, y, blitOffset, width, height);
        } else if (guiSpriteScaling instanceof Scaling.Tile tile) {
            blitTiledSpriteBatched(guiGraphics, textureAtlasSprite, x, y, blitOffset, width, height, 0, 0, tile.width(), tile.height(), tile.width(), tile.height());
        } else if (guiSpriteScaling instanceof Scaling.NineSlice nineSlice) {
            blitNineSlicedSpriteBatched(guiGraphics, textureAtlasSprite, nineSlice, x, y, blitOffset, width, height);
        }
    }

    private static void blitNineSlicedSpriteBatched(DrawContext guiGraphics, Sprite sprite, Scaling.NineSlice nineSlice, int x, int y, int blitOffset, int width, int height) {
        Scaling.NineSlice.Border border = nineSlice.border();

        int i = Math.min(border.left(), width / 2);
        int j = Math.min(border.right(), width / 2);
        int k = Math.min(border.top(), height / 2);
        int l = Math.min(border.bottom(), height / 2);

        batched(guiGraphics, sprite.getAtlasId(), (bufferBuilder, poseStack) -> {
            if (width == nineSlice.width() && height == nineSlice.height()) {
                blitSprite(bufferBuilder, poseStack, sprite, nineSlice.width(), nineSlice.height(), 0, 0, x, y, blitOffset, width, height);
            } else if (height == nineSlice.height()) {
                blitSprite(bufferBuilder, poseStack, sprite, nineSlice.width(), nineSlice.height(), 0, 0, x, y, blitOffset, i, height);
                blitTiledSprite(bufferBuilder, poseStack, sprite, x + i, y, blitOffset, width - j - i, height, i, 0, nineSlice.width() - j - i, nineSlice.height(), nineSlice.width(), nineSlice.height());
                blitSprite(bufferBuilder, poseStack, sprite, nineSlice.width(), nineSlice.height(), nineSlice.width() - j, 0, x + width - j, y, blitOffset, j, height);
            } else if (width == nineSlice.width()) {
                blitSprite(bufferBuilder, poseStack, sprite, nineSlice.width(), nineSlice.height(), 0, 0, x, y, blitOffset, width, k);
                blitTiledSprite(bufferBuilder, poseStack, sprite, x, y + k, blitOffset, width, height - l - k, 0, k, nineSlice.width(), nineSlice.height() - l - k, nineSlice.width(), nineSlice.height());
                blitSprite(bufferBuilder, poseStack, sprite, nineSlice.width(), nineSlice.height(), 0, nineSlice.height() - l, x, y + height - l, blitOffset, width, l);
            } else {
                blitSprite(bufferBuilder, poseStack, sprite, nineSlice.width(), nineSlice.height(), 0, 0, x, y, blitOffset, i, k);
                blitTiledSprite(bufferBuilder, poseStack, sprite, x + i, y, blitOffset, width - j - i, k, i, 0, nineSlice.width() - j - i, k, nineSlice.width(), nineSlice.height());
                blitSprite(bufferBuilder, poseStack, sprite, nineSlice.width(), nineSlice.height(), nineSlice.width() - j, 0, x + width - j, y, blitOffset, j, k);
                blitSprite(bufferBuilder, poseStack, sprite, nineSlice.width(), nineSlice.height(), 0, nineSlice.height() - l, x, y + height - l, blitOffset, i, l);
                blitTiledSprite(bufferBuilder, poseStack, sprite, x + i, y + height - l, blitOffset, width - j - i, l, i, nineSlice.height() - l, nineSlice.width() - j - i, l, nineSlice.width(), nineSlice.height());
                blitSprite(bufferBuilder, poseStack, sprite, nineSlice.width(), nineSlice.height(), nineSlice.width() - j, nineSlice.height() - l, x + width - j, y + height - l, blitOffset, j, l);
                blitTiledSprite(bufferBuilder, poseStack, sprite, x, y + k, blitOffset, i, height - l - k, 0, k, i, nineSlice.height() - l - k, nineSlice.width(), nineSlice.height());
                blitTiledSprite(bufferBuilder, poseStack, sprite, x + i, y + k, blitOffset, width - j - i, height - l - k, i, k, nineSlice.width() - j - i, nineSlice.height() - l - k, nineSlice.width(), nineSlice.height());
                blitTiledSprite(bufferBuilder, poseStack, sprite, x + width - j, y + k, blitOffset, i, height - l - k, nineSlice.width() - j, k, j, nineSlice.height() - l - k, nineSlice.width(), nineSlice.height());
            }
        });
    }

    private static void blitTiledSpriteBatched(DrawContext guiGraphics, Sprite sprite, int x, int y, int blitOffset, int width, int height, int i, int j, int spriteWidth, int spriteHeight, int nineSliceWidth, int nineSliceHeight) {
        batched(guiGraphics, sprite.getAtlasId(), (bufferBuilder, poseStack) -> {
            if (width <= 0 || height <= 0) return;

            if (spriteWidth <= 0 || spriteHeight <= 0) {
                throw new IllegalArgumentException("Tiled sprite texture size must be positive, got " + spriteWidth + "x" + spriteHeight);
            }

            for(int k = 0; k < width; k += spriteWidth) {
                int l = Math.min(spriteWidth, width - k);

                for(int m = 0; m < height; m += spriteHeight) {
                    int n = Math.min(spriteHeight, height - m);

                    blitSprite(bufferBuilder, poseStack, sprite, nineSliceWidth, nineSliceHeight, i, j, x + k, y + m, blitOffset, l, n);
                }
            }
        });
    }

    private static void blitTiledSprite(BufferBuilder bufferBuilder, MatrixStack poseStack, Sprite sprite, int x, int y, int blitOffset, int width, int height, int i, int j, int spriteWidth, int spriteHeight, int nineSliceWidth, int nineSliceHeight) {
        if (width <= 0 || height <= 0) return;

        if (spriteWidth <= 0 || spriteHeight <= 0) {
            throw new IllegalArgumentException("Tiled sprite texture size must be positive, got " + spriteWidth + "x" + spriteHeight);
        }

        for(int k = 0; k < width; k += spriteWidth) {
            int l = Math.min(spriteWidth, width - k);

            for(int m = 0; m < height; m += spriteHeight) {
                int n = Math.min(spriteHeight, height - m);

                blitSprite(bufferBuilder, poseStack, sprite, nineSliceWidth, nineSliceHeight, i, j, x + k, y + m, blitOffset, l, n);
            }
        }
    }

    public static <T> void batched(DrawContext guiGraphics, Identifier location, List<T> list, TriConsumer<BufferBuilder, MatrixStack, T> consumer) {
        batched(guiGraphics, location, (bufferBuilder, poseStack) -> list.forEach(t -> consumer.accept(bufferBuilder, poseStack, t)));
    }

    public static void batched(DrawContext guiGraphics, Identifier location, BiConsumer<BufferBuilder, MatrixStack> consumer) {
        RenderSystem.setShaderTexture(0, location);
        RenderSystem.setShader(GameRenderer::getPositionTexProgram);

        var poseStack = guiGraphics.getMatrices();

        var bufferBuilder = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE);

        consumer.accept(bufferBuilder, poseStack);

        var data = bufferBuilder.endNullable();

        if(data != null) BufferRenderer.drawWithGlobalProgram(data);
    }

    private static void blitSprite(BufferBuilder bufferBuilder, MatrixStack poseStack, Sprite sprite, int sliceWidth, int sliceHeight, int uOffset, int vOffset, int x, int y, int blitOffset, int width, int height) {
        if (width == 0 || height == 0) return;

        blitInner(bufferBuilder, poseStack, x, x + width, y, y + height, blitOffset, sprite.getFrameU((float)uOffset / (float)sliceWidth), sprite.getFrameU((float)(uOffset + width) / (float)sliceWidth), sprite.getFrameV((float)vOffset / (float)sliceHeight), sprite.getFrameV((float)(vOffset + height) / (float)sliceHeight));
    }

    public static void blit(BufferBuilder bufferBuilder, MatrixStack poseStack, int x, int y, int size) {
        blit(bufferBuilder, poseStack, x, y, 0, 0, 0, size, size, size, size);
    }

    public static void blit(BufferBuilder bufferBuilder, MatrixStack poseStack, int x1, int y1, int blitOffset, float uOffset, float vOffset, int width, int height, int textureWidth, int textureHeight) {
        var minU = (uOffset) / (float) textureWidth;
        var maxU = (uOffset + (float) width) / (float) textureWidth;
        var minV = (vOffset) / (float) textureHeight;
        var maxV = (vOffset + (float) height) / (float) textureHeight;

        blitInner(bufferBuilder, poseStack, x1, x1 + width, y1, y1 + height, blitOffset, minU, maxU, minV, maxV);
    }

    private static void blitInner(BufferBuilder bufferBuilder, MatrixStack poseStack, int x1, int x2, int y1, int y2, int blitOffset, float minU, float maxU, float minV, float maxV) {
        var matrix4f = poseStack.peek().getPositionMatrix();

        bufferBuilder.vertex(matrix4f, (float) x1, (float) y1, (float) blitOffset).texture(minU, minV);
        bufferBuilder.vertex(matrix4f, (float) x1, (float) y2, (float) blitOffset).texture(minU, maxV);
        bufferBuilder.vertex(matrix4f, (float) x2, (float) y2, (float) blitOffset).texture(maxU, maxV);
        bufferBuilder.vertex(matrix4f, (float) x2, (float) y1, (float) blitOffset).texture(maxU, minV);
    }

    //--

    public static void blitWithAlpha(DrawContext ctx, Identifier atlasLocation, int x, int y, float uOffset, float vOffset, int width, int height, int textureWidth, int textureHeight, Vector4f alphaValues) {
        blitWithAlpha(ctx, atlasLocation, x, y, width, height, uOffset, vOffset, width, height, textureWidth, textureHeight, alphaValues);
    }

    private static void blitWithAlpha(DrawContext ctx, Identifier atlasLocation, int x, int y, int width, int height, float uOffset, float vOffset, int uWidth, int vHeight, int textureWidth, int textureHeight, Vector4f alphaValues) {
        blitWithAlpha(ctx, atlasLocation, x, x + width, y, y + height, 0, uWidth, vHeight, uOffset, vOffset, textureWidth, textureHeight, alphaValues);
    }

    private static void blitWithAlpha(DrawContext ctx, Identifier atlasLocation, int x1, int x2, int y1, int y2, int blitOffset, int uWidth, int vHeight, float uOffset, float vOffset, int textureWidth, int textureHeight, Vector4f alphaValues) {
        innerBlitWithAlpha(ctx, atlasLocation, x1, x2, y1, y2, blitOffset, (uOffset + 0.0F) / (float)textureWidth, (uOffset + (float)uWidth) / (float)textureWidth, (vOffset + 0.0F) / (float)textureHeight, (vOffset + (float)vHeight) / (float)textureHeight, alphaValues);
    }

    // X: Top Left
    // Y: Top Right
    // Z: Bottom Left
    // W: Bottom Right
    private static void innerBlitWithAlpha(DrawContext ctx, Identifier atlasLocation, int x1, int x2, int y1, int y2, int blitOffset, float minU, float maxU, float minV, float maxV, Vector4f alphaValues) {
        RenderSystem.setShaderTexture(0, atlasLocation);
        RenderSystem.setShader(GameRenderer::getPositionTexColorProgram);
        RenderSystem.enableBlend();
        Matrix4f matrix4f = ctx.getMatrices().peek().getPositionMatrix();
        BufferBuilder bufferBuilder = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
        bufferBuilder.vertex(matrix4f, (float)x1, (float)y1, (float)blitOffset).texture(minU, minV).color(1.0f, 1.0f, 1.0f, alphaValues.x);
        bufferBuilder.vertex(matrix4f, (float)x1, (float)y2, (float)blitOffset).texture(minU, maxV).color(1.0f, 1.0f, 1.0f, alphaValues.z);
        bufferBuilder.vertex(matrix4f, (float)x2, (float)y2, (float)blitOffset).texture(maxU, maxV).color(1.0f, 1.0f, 1.0f, alphaValues.w);
        bufferBuilder.vertex(matrix4f, (float)x2, (float)y1, (float)blitOffset).texture(maxU, minV).color(1.0f, 1.0f, 1.0f, alphaValues.y);
        BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
        RenderSystem.disableBlend();
    }

    //--

    public static void blitWithColor(DrawContext ctx, Identifier atlasLocation, int x, int y, float uOffset, float vOffset, int width, int height, int textureWidth, int textureHeight, float red, float green, float blue, float alpha) {
        blitWithColor(ctx, atlasLocation, x, y, width, height, uOffset, vOffset, width, height, textureWidth, textureHeight, red, green, blue, alpha);
    }

    private static void blitWithColor(DrawContext ctx, Identifier atlasLocation, int x, int y, int width, int height, float uOffset, float vOffset, int uWidth, int vHeight, int textureWidth, int textureHeight, float red, float green, float blue, float alpha) {
        blitWithColor(ctx, atlasLocation, x, x + width, y, y + height, 0, uWidth, vHeight, uOffset, vOffset, textureWidth, textureHeight, red, green, blue, alpha);
    }

    private static void blitWithColor(DrawContext ctx, Identifier atlasLocation, int x1, int x2, int y1, int y2, int blitOffset, int uWidth, int vHeight, float uOffset, float vOffset, int textureWidth, int textureHeight, float red, float green, float blue, float alpha) {
        innerBlitWithColor(ctx, atlasLocation, x1, x2, y1, y2, blitOffset, (uOffset + 0.0F) / (float)textureWidth, (uOffset + (float)uWidth) / (float)textureWidth, (vOffset + 0.0F) / (float)textureHeight, (vOffset + (float)vHeight) / (float)textureHeight, red, green, blue, alpha);
    }

    private static void innerBlitWithColor(DrawContext ctx, Identifier atlasLocation, int x1, int x2, int y1, int y2, int blitOffset, float minU, float maxU, float minV, float maxV, float red, float green, float blue, float alpha) {
        RenderSystem.setShaderTexture(0, atlasLocation);
        RenderSystem.setShader(GameRenderer::getPositionTexColorProgram);
        RenderSystem.enableBlend();
        Matrix4f matrix4f = ctx.getMatrices().peek().getPositionMatrix();
        BufferBuilder bufferBuilder = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
        bufferBuilder.vertex(matrix4f, (float)x1, (float)y1, (float)blitOffset).texture(minU, minV).color(red, green, blue, alpha);
        bufferBuilder.vertex(matrix4f, (float)x1, (float)y2, (float)blitOffset).texture(minU, maxV).color(red, green, blue, alpha);
        bufferBuilder.vertex(matrix4f, (float)x2, (float)y2, (float)blitOffset).texture(maxU, maxV).color(red, green, blue, alpha);
        bufferBuilder.vertex(matrix4f, (float)x2, (float)y1, (float)blitOffset).texture(maxU, minV).color(red, green, blue, alpha);
        BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
        RenderSystem.disableBlend();
    }

    //--

    public static void drawWithSpectrum(DrawContext ctx, int x, int y, int blitOffset, int width, int height, Sprite sprite, float alpha) {
        innerDrawWithSpectrum(ctx, sprite.getAtlasId(), x, x + width, y, y + height, blitOffset, sprite.getMinU(), sprite.getMaxU(), sprite.getMinV(), sprite.getMaxV(), new Vector4f(alpha));
    }

    public static void drawWithSpectrum(DrawContext ctx, int x, int y, int blitOffset, int width, int height, Sprite sprite, Vector4f alphaValues) {
        innerDrawWithSpectrum(ctx, sprite.getAtlasId(), x, x + width, y, y + height, blitOffset, sprite.getMinU(), sprite.getMaxU(), sprite.getMinV(), sprite.getMaxV(), alphaValues);
    }

    // X: Top Left
    // Y: Top Right
    // Z: Bottom Left
    // W: Bottom Right
    private static void innerDrawWithSpectrum(DrawContext ctx, Identifier atlasLocation, int x1, int x2, int y1, int y2, int blitOffset, float minU, float maxU, float minV, float maxV,  Vector4f alphaValues) {
        RenderSystem.setShaderTexture(0, atlasLocation);

        RenderSystem.enableBlend();

        Matrix4f matrix4f = ctx.getMatrices().peek().getPositionMatrix();

        BufferBuilder bufferBuilder = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);

        bufferBuilder.vertex(matrix4f, (float)x1, (float)y1, (float)blitOffset).texture(minU, minV).color(1.0f, 1.0f, 1.0f, alphaValues.x);
        bufferBuilder.vertex(matrix4f, (float)x1, (float)y2, (float)blitOffset).texture(minU, maxV).color(0, 1.0f, 1.0f, alphaValues.z);
        bufferBuilder.vertex(matrix4f, (float)x2, (float)y2, (float)blitOffset).texture(maxU, maxV).color(0, 1.0f, 1.0f, alphaValues.w);
        bufferBuilder.vertex(matrix4f, (float)x2, (float)y1, (float)blitOffset).texture(maxU, minV).color(1.0f, 1.0f, 1.0f, alphaValues.y);

        AccessoriesClient.SPECTRUM_PROGRAM.use();
        BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());

        RenderSystem.disableBlend();
    }

    public static void drawRectOutlineWithSpectrum(OwoUIDrawContext ctx, int x, int y, int z, int width, int height, float alpha, boolean vertical) {
        ctx.recordQuads();

        drawRectOutlineWithSpectrumWithoutRecord(ctx, x, y, z, width, height, alpha, vertical);

        ctx.submitQuads();
    }


    public static void drawRectOutlineWithSpectrumWithoutRecord(OwoUIDrawContext ctx, int x, int y, int z, int width, int height, float alpha, boolean vertical) {
        innerFill(ctx, x, y, x + width, y + 1, 0, alpha, !vertical);
        innerFill(ctx, x, y + height - 1, x + width, y + height, 0, alpha, !vertical);

        innerFill(ctx, x, y + 1, x + 1, y + height - 1, 0, alpha, vertical);
        innerFill(ctx, x + width - 1, y + 1, x + width, y + height - 1, 0, alpha, vertical);
    }

    private static void innerFill(DrawContext ctx, int minX, int minY, int maxX, int maxY, int z, float alpha, boolean vertical) {
        RenderSystem.enableBlend();

        Matrix4f matrix4f = ctx.getMatrices().peek().getPositionMatrix();
        if (minX < maxX) {
            int i = minX;
            minX = maxX;
            maxX = i;
        }

        if (minY < maxY) {
            int i = minY;
            minY = maxY;
            maxY = i;
        }

        if (ctx instanceof OwoUIDrawContext context && context.recording()) {
            ((OwoTessellatorExtension) Tessellator.getInstance()).owo$skipNextBegin();
        }

        BufferBuilder builder = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);

        var multiplier = (float) ((System.currentTimeMillis() / 20d % 360d) / 360d);

        var topValue = 1f - multiplier;
        var bottomValue = topValue; //0f + multiplier;

        builder.vertex(matrix4f, (float)minX, (float)minY, (float)z).color(topValue, 1f, 1f, alpha);
        builder.vertex(matrix4f, (float)minX, (float)maxY, (float)z).color(vertical ? bottomValue : topValue, 1f, 1f, alpha);
        builder.vertex(matrix4f, (float)maxX, (float)maxY, (float)z).color(bottomValue, 1f, 1f, alpha);
        builder.vertex(matrix4f, (float)maxX, (float)minY, (float)z).color(vertical ? topValue : bottomValue, 1f, 1f, alpha);

        //--

        OwoClient.HSV_PROGRAM.use();

        if (ctx instanceof OwoUIDrawContext context && context.recording()) {
            ((OwoTessellatorExtension) Tessellator.getInstance()).owo$setStoredBuilder(builder);

            return;
        }

        BufferRenderer.drawWithGlobalProgram(builder.end());

        RenderSystem.disableBlend();
    }
}
