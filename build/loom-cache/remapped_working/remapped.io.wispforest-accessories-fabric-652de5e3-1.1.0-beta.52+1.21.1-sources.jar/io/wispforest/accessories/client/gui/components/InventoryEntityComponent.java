package io.wispforest.accessories.client.gui.components;

import F;
import I;
import com.mojang.blaze3d.platform.GlConst;
import com.mojang.blaze3d.systems.RenderSystem;
import io.wispforest.owo.ui.component.EntityComponent;
import io.wispforest.owo.ui.core.Color;
import io.wispforest.owo.ui.core.Component;
import io.wispforest.owo.ui.core.OwoUIDrawContext;
import io.wispforest.owo.ui.core.Sizing;
import io.wispforest.owo.util.pond.OwoEntityRenderDispatcherExtension;
import org.apache.logging.log4j.util.TriConsumer;
import org.jetbrains.annotations.Nullable;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.util.function.BiConsumer;
import net.minecraft.client.render.DiffuseLighting;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.util.math.RotationAxis;

public class InventoryEntityComponent<E extends Entity> extends EntityComponent<E> {

    private float startingRotation = -45;

    private float lastBbWidth = 0.0f;
    private float lastBbHeight = 0.0f;

    private ScaleFitType type = ScaleFitType.NONE;

    public InventoryEntityComponent(Sizing sizing, E entity) {
        super(sizing, entity);

        this.lastBbWidth = entity.getWidth();
        this.lastBbHeight = entity.getHeight();
    }

    public InventoryEntityComponent(Sizing sizing, EntityType<E> type, @Nullable NbtCompound nbt) {
        super(sizing, type, nbt);
    }

    public static <E extends Entity> InventoryEntityComponent<E> of(Sizing verticalSizing, Sizing horizontalSizing, E entity) {
        var component = new InventoryEntityComponent<E>(verticalSizing, entity);

        component.horizontalSizing(horizontalSizing);

        return component;
    }

    private float getEntityScale() {
        return (entity instanceof LivingEntity living) ? living.getScale() : 1.0f;
    }

    public float xOffset = 0.0f;
    public float yOffset = 0.0f;

    private TriConsumer<OwoUIDrawContext, Component, Runnable> renderWrapping = (ctx, component, runnable) -> runnable.run();

    public InventoryEntityComponent<E> renderWrapping(TriConsumer<OwoUIDrawContext, Component, Runnable> renderWrapping) {
        this.renderWrapping = renderWrapping;

        return this;
    }

    public InventoryEntityComponent<E> scaleToFit(boolean scaleToFit) {
        if(scaleToFit) {
            var componentHeight = (float) this.verticalSizing().get().value;
            var componentWidth = (float) this.horizontalSizing().get().value - 40;

            var entityHeight = entity.getHeight() * (Math.min(componentWidth, componentHeight) / Math.max(componentWidth, componentHeight));
            var entityWidth = entity.getWidth()* (Math.max(componentWidth, componentHeight) / Math.min(componentWidth, componentHeight));

            var length = Math.max(entityHeight, entityWidth);

            float baseScale = (.35f / length);

            this.scale(baseScale);

            type = ScaleFitType.BOTH;
        } else {
            this.scale(1);

            type = ScaleFitType.NONE;
        }

        return this;
    }

    public InventoryEntityComponent<E> startingRotation(float value) {
        this.startingRotation = value;

        return this;
    }

    public InventoryEntityComponent<E> scaleToFitVertically(boolean scaleToFit) {
        this.scale(scaleToFit ? (.5f / entity.getHeight()) : 1);

        type = scaleToFit ? ScaleFitType.VERTICAL : ScaleFitType.NONE;

        return this;
    }

    public InventoryEntityComponent<E> scaleToFitHorizontally(boolean scaleToFit) {
        this.scale(scaleToFit ? (.5f / entity.getWidth()) : 1);

        type = scaleToFit ? ScaleFitType.HORIZONTAL : ScaleFitType.NONE;

        return this;
    }

    @Override
    public void draw(OwoUIDrawContext context, int mouseX, int mouseY, float partialTicks, float delta) {
        if(!(entity instanceof LivingEntity living)) {
            super.draw(context, mouseX, mouseY, partialTicks, delta);

            return;
        }

        if (this.lastBbWidth != entity.getWidth() || this.lastBbHeight != entity.getHeight()) {
            switch (type) {
                case VERTICAL -> this.scaleToFitVertically(true);
                case HORIZONTAL -> this.scaleToFitHorizontally(true);
                case BOTH -> this.scaleToFit(true);
                case NONE -> {}
            }

            this.lastBbWidth = entity.getWidth();
            this.lastBbHeight = entity.getHeight();
        }

//        var GL_ZERO     = 0x0000;
//        var GL_KEEP     = 0x1E00;
//        var GL_REPLACE  = 0x1E01;
//        var GL_INCR     = 0x1E02;
//        var GL_DECR     = 0x1E03;
//        var GL_INVERT   = 0x150A;
//        var GL_NOTEQUAL = 0x0205;
//        var GL_ALWAYS   = 0x0207;
//
//        var GL_STENCIL_BUFFER_BIT = 0x00000400;
//
//        var GL_STENCIL_TEST = 0x0B90;
//
//        context.flush();
//
//        RenderSystem.enableDepthTest();
//        GL11.glEnable(GL11.GL_STENCIL_TEST);
//
//        RenderSystem.clear(GL11.GL_COLOR_BUFFER_BIT, Minecraft.ON_OSX);
//        RenderSystem.clear(GL11.GL_DEPTH_BUFFER_BIT, Minecraft.ON_OSX);
//        RenderSystem.clear(GL11.GL_STENCIL_BUFFER_BIT, Minecraft.ON_OSX);
//        RenderSystem.clearStencil(0);
//
//        RenderSystem.stencilMask(0xFF);
//        RenderSystem.stencilFunc(GL11.GL_EQUAL, 1, 0xFF);
//        RenderSystem.stencilOp(GL11.GL_KEEP, GL11.GL_KEEP, GL11.GL_REPLACE);
//
//        context.fill(0, 0, Minecraft.getInstance().getWindow().getGuiScaledWidth(), Minecraft.getInstance().getWindow().getGuiScaledHeight(), Color.BLUE.argb());
//        context.fill(this.x, this.y, this.x + 50, this.y + 50, Color.WHITE.argb());
//
//        context.flush();
//
//        //RenderSystem.stencilMask(0x00);
//        RenderSystem.stencilFunc(GL11.GL_NOTEQUAL, 1, 0xFF);

        var matrices = context.getMatrices();
        matrices.push();

        var maxLength = Math.max(this.width, this.height);

        matrices.translate(x + this.width / 2f, y + this.height / 2f, 60);
        matrices.scale(75 * this.scale * maxLength / 64f, -75 * this.scale * maxLength / 64f, 75 * this.scale);

        matrices.translate(0, entity.getHeight() / -2f, 0);

        matrices.translate(this.xOffset, this.yOffset, 0);

        this.transform.accept(matrices);

        float prevYBodyRot0 = living.prevBodyYaw;
        float prevYBodyRot = living.bodyYaw;
        float prevYRot = living.getYaw();
        float prevYRot0 = living.prevYaw;
        float prevXRot = living.getPitch();
        float prevXRot0 = living.prevPitch;
        float prevYHeadRot0 = living.prevHeadYaw;
        float prevYHeadRot = living.headYaw;

        var dispatcher = (OwoEntityRenderDispatcherExtension) this.dispatcher;

        if (this.lookAtCursor) {
            float xRotation = (float) Math.toDegrees(Math.atan((mouseY - this.y - this.height / 2f) / 40f));
            float yRotation = (float) Math.toDegrees(Math.atan((mouseX - this.x - this.width / 2f) / 40f));

            living.prevHeadYaw = -yRotation;

            this.entity.prevYaw = -yRotation;
            this.entity.prevPitch = xRotation * .65f;

            // We make sure the xRotation never becomes 0, as the lighting otherwise becomes very unhappy
            if (xRotation == 0) xRotation = .1f;
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(xRotation * .35f));
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(yRotation * .555f));
        } else {
            float xRotation = (float) Math.toDegrees(Math.atan((mouseY - this.y - this.height / 2f) / 40f));

            this.entity.prevPitch = xRotation * .35f;

            if (xRotation == 0) xRotation = .1f;
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(xRotation * .15f));

            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(15));
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(startingRotation + this.mouseRotation));
        }

        {
            dispatcher.owo$setCounterRotate(true);
            dispatcher.owo$setShowNametag(this.showNametag);

            DiffuseLighting.method_34742();

            this.dispatcher.setRenderShadows(false);

            living.prevBodyYaw = 0;
            living.bodyYaw = 0;
            living.setYaw(0);
            living.headYaw = living.bodyYaw;
            living.prevHeadYaw = living.prevBodyYaw;

            RenderSystem.disableDepthTest();

            this.renderWrapping.accept(context,this,
                    () -> this.dispatcher.render(this.entity, 0, 0, 0, 0, 0, matrices, this.entityBuffers, LightmapTextureManager.MAX_LIGHT_COORDINATE)
            );

//            this.entityBuffers.endBatch();
//
//            RenderSystem.stencilMask(0xFF);
//            RenderSystem.stencilFunc(GL11.GL_ALWAYS, 1, 0xFF);
//            RenderSystem.enableDepthTest();
//
//            GL11.glDisable(GL_STENCIL_TEST);

            this.dispatcher.setRenderShadows(true);
        }

        living.prevBodyYaw = prevYBodyRot0;
        living.bodyYaw = prevYBodyRot;
        living.setYaw(prevYRot);
        living.prevYaw = prevYRot0;
        living.setPitch(prevXRot);
        living.prevPitch = prevXRot0;
        living.prevHeadYaw = prevYHeadRot0;
        living.headYaw = prevYHeadRot;

        this.dispatcher.setRenderShadows(true);
        this.entityBuffers.draw();
        DiffuseLighting.enableGuiDepthLighting();

        matrices.pop();

        dispatcher.owo$setCounterRotate(false);
        dispatcher.owo$setShowNametag(true);
    }

    @Override
    public boolean onMouseScroll(double mouseX, double mouseY, double amount) {
        this.scale += (float) (amount * this.scale * 0.1f);

        return true;
    }

    @Override
    public boolean onKeyPress(int keyCode, int scanCode, int modifiers) {
        if(keyCode == GLFW.GLFW_KEY_LEFT) {
            this.xOffset -= 0.05f;
        } else if(keyCode == GLFW.GLFW_KEY_RIGHT) {
            this.xOffset += 0.05f;
        }

        if(keyCode == GLFW.GLFW_KEY_UP) {
            this.yOffset += 0.05f;
        } else if(keyCode == GLFW.GLFW_KEY_DOWN) {
            this.yOffset -= 0.05f;
        }

        return super.onKeyPress(keyCode, scanCode, modifiers);
    }

    public enum ScaleFitType {
        VERTICAL,
        HORIZONTAL,
        BOTH,
        NONE;
    }
}
