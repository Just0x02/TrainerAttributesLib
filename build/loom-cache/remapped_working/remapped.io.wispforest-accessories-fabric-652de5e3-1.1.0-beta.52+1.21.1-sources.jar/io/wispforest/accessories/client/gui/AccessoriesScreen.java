package io.wispforest.accessories.client.gui;

import D;
import I;
import Z;
import io.wispforest.accessories.Accessories;
import io.wispforest.accessories.api.AccessoriesContainer;
import io.wispforest.accessories.api.slot.SlotGroup;
import io.wispforest.accessories.api.slot.SlotType;
import io.wispforest.accessories.api.slot.UniqueSlotHandling;
import io.wispforest.accessories.client.GuiGraphicsUtils;
import io.wispforest.accessories.data.EntitySlotLoader;
import io.wispforest.accessories.data.SlotGroupLoader;
import io.wispforest.accessories.impl.ExpandedSimpleContainer;
import io.wispforest.accessories.impl.SlotGroupImpl;
import io.wispforest.accessories.menu.AccessoriesInternalSlot;
import io.wispforest.accessories.menu.variants.AccessoriesMenu;
import io.wispforest.accessories.networking.AccessoriesNetworking;
import io.wispforest.accessories.networking.holder.HolderProperty;
import io.wispforest.accessories.networking.holder.SyncHolderChange;
import io.wispforest.accessories.networking.server.MenuScroll;
import io.wispforest.accessories.pond.ContainerScreenExtension;
import it.unimi.dsi.fastutil.Pair;
import org.apache.commons.lang3.Range;
import org.jetbrains.annotations.Nullable;
import org.joml.*;
import org.lwjgl.glfw.GLFW;

import java.lang.Math;
import java.util.*;
import java.util.Map.Entry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ButtonTextures;
import net.minecraft.client.gui.screen.FatalErrorScreen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.screen.slot.Slot;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

public class AccessoriesScreen extends HandledScreen<AccessoriesMenu> implements ContainerScreenExtension, AccessoriesScreenBase<AccessoriesMenu> {

    private static final Identifier SLOT = Accessories.of("textures/gui/theme/light/slot.png");

    private static final Identifier ACCESSORIES_INVENTORY_LOCATION = Accessories.of("textures/gui/container/accessories_inventory.png");

    private static final Identifier BACKGROUND_PATCH = Accessories.of("background_patch");

    private static final Identifier SCROLL_BAR_PATCH = Accessories.of("scroll_bar_patch");
    private static final Identifier SCROLL_BAR = Accessories.of("scroll_bar");

    private static final Identifier HORIZONTAL_TABS = Accessories.of("textures/gui/container/horizontal_tabs_small.png");

    private static final ButtonTextures SPRITES_12X12 = new ButtonTextures(Accessories.of("widget/12x12/button"), Accessories.of("widget/12x12/button_disabled"), Accessories.of("widget/12x12/button_highlighted"));
    public static final ButtonTextures SPRITES_8X8 = new ButtonTextures(Accessories.of("widget/8x8/button"), Accessories.of("widget/8x8/button_disabled"), Accessories.of("widget/8x8/button_highlighted"));

    private static final Identifier BACk_ICON = Accessories.of("widget/back");

    private static final Identifier LINE_HIDDEN = Accessories.of("widget/line_hidden");
    private static final Identifier LINE_SHOWN = Accessories.of("widget/line_shown");

    private static final Identifier UNUSED_SLOTS_HIDDEN = Accessories.of("widget/unused_slots_hidden");
    private static final Identifier UNUSED_SLOTS_SHOWN = Accessories.of("widget/unused_slots_shown");

    private final Map<AccessoriesInternalSlot, ToggleButton> cosmeticButtons = new LinkedHashMap<>();

    private int currentTabPage = 1;

    private int scrollBarHeight = 0;

    private boolean isScrolling = false;

    public AccessoriesScreen(AccessoriesMenu menu, PlayerInventory inventory, Text component) {
        super(menu, inventory, Text.empty());

        this.titleX = 97;
        this.playerInventoryTitleX = 42069;
    }

    private static final int upperPadding = 8;

    public int getPanelHeight() {
        return getPanelHeight(upperPadding);
    }

    public int getPanelHeight(int upperPadding) {
        return 14 + (Math.min(handler.totalSlots, 8) * 18) + upperPadding;
    }

    public int getPanelWidth() {
        int width = 8 + 18 + 18;

        if (handler.isCosmeticsOpen()) width += 18 + 2;

        if (!handler.overMaxVisibleSlots) width -= 12;

        return width;
    }

    public int getStartingPanelX() {
        int x = this.x - ((handler.isCosmeticsOpen()) ? 72 : 52);

        if (!handler.overMaxVisibleSlots) x += 12;

        return x;
    }

    public int leftPos() {
        return this.x;
    }

    public int topPos() {
        return this.y;
    }

    public final LivingEntity targetEntityDefaulted() {
        var targetEntity = this.handler.targetEntity();

        return (targetEntity != null) ? targetEntity : this.client.player;
    }

    protected boolean insideScrollbar(double mouseX, double mouseY) {
        int x = getStartingPanelX() + 13;
        int y = this.y + 7 + upperPadding;

        int height = getPanelHeight() - 22;
        int width = 8;

        return this.handler.overMaxVisibleSlots && (mouseX >= x && mouseY >= y && mouseX < (x + width) && mouseY < (y + height));
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        var bl = super.mouseClicked(mouseX, mouseY, button);

        if (this.getFocused() instanceof ButtonWidget) this.blur();

        if (this.insideScrollbar(mouseX, mouseY)) {
            this.isScrolling = true;

            return true;
        }

        if (Accessories.config().screenOptions.showGroupTabs() && this.handler.maxScrollableIndex() > 0) {
            int x = getStartingPanelX();
            int y = this.y;

            for (var value : this.getGroups(x, y).values()) {
                if (!value.isInBounds((int) Math.round(mouseX), (int) Math.round(mouseY))) continue;

                var index = value.startingIndex;

                if (index > this.handler.maxScrollableIndex()) index = this.handler.maxScrollableIndex();

                if (index != this.handler.scrolledIndex) {
                    AccessoriesNetworking.sendToServer(new MenuScroll(index, false));

                    MinecraftClient.getInstance().getSoundManager()
                            .play(PositionedSoundInstance.master(SoundEvents.UI_BUTTON_CLICK, 1.0F));
                }

                break;
            }
        }

        return bl;
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (!this.insideScrollbar(mouseX, mouseY) && button == GLFW.GLFW_MOUSE_BUTTON_1) this.isScrolling = false;

        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    protected void drawBackground(DrawContext guiGraphics, float partialTick, int mouseX, int mouseY) {
        int leftPos = this.x;
        int topPos = this.y;

        guiGraphics.drawTexture(ACCESSORIES_INVENTORY_LOCATION, leftPos, topPos, 0, 0, this.backgroundWidth, this.backgroundHeight);

        //--

        var scissorStart = new Vector2i(leftPos + 26, topPos + 8);
        var scissorEnd = new Vector2i(leftPos + 26 + 124, topPos + 8 + 70);
        var size = new Vector2i((scissorEnd.x - scissorStart.x) / 2, scissorEnd.y - scissorStart.y);

        SCISSOR_BOX.set(scissorStart.x, scissorStart.y, scissorEnd.x, scissorEnd.y);

        // --

        AccessoriesScreenBase.togglePositionCollection();

        AccessoriesScreenBase.IS_RENDERING_UI_ENTITY.setValue(true);

        IS_RENDERING_LINE_TARGET.setValue(true);

        renderEntityInInventoryFollowingMouseRotated(guiGraphics, scissorStart, size, scissorStart, scissorEnd, mouseX, mouseY, 0);

        IS_RENDERING_LINE_TARGET.setValue(false);

        renderEntityInInventoryFollowingMouseRotated(guiGraphics, new Vector2i(scissorStart).add(size.x, 0), size, scissorStart, scissorEnd, mouseX, mouseY, 180);

        AccessoriesScreenBase.IS_RENDERING_UI_ENTITY.setValue(false);

        COLLECT_ACCESSORY_POSITIONS.setValue(false);


//        HOVERED_SLOT_TYPE = null;

        //--

        var pose = guiGraphics.getMatrices();

        pose.push();
        pose.translate(0.0F, 0.0F, 0);

        int x = getStartingPanelX();
        int y = this.y;

        int height = getPanelHeight();
        int width = getPanelWidth();

        //guiGraphics.blitSprite(AccessoriesScreen.BACKGROUND_PATCH, x + 6, y, width, height); //147
        GuiGraphicsUtils.blitSpriteBatched(guiGraphics, AccessoriesScreen.BACKGROUND_PATCH, x + 6, y, width, height); //147

        if (handler.overMaxVisibleSlots) {
            //guiGraphics.blitSprite(AccessoriesScreen.SCROLL_BAR_PATCH, x + 13, y + 7 + upperPadding, 8, height - 22);
            GuiGraphicsUtils.blitSpriteBatched(guiGraphics, AccessoriesScreen.SCROLL_BAR_PATCH, x + 13, y + 7 + upperPadding, 8, height - 22);
        }

        pose.pop();

        //--

        pose.push();
        pose.translate(-1, -1, 0);

//        for (Slot slot : this.menu.slots) {
//            if (!(slot.container instanceof ExpandedSimpleContainer) || !slot.isActive()) continue;
//
//            if (slot instanceof AccessoriesInternalSlot accessoriesSlot && !accessoriesSlot.getItem().isEmpty()) {
//                var positionKey = accessoriesSlot.accessoriesContainer.getSlotName() + accessoriesSlot.getContainerSlot();
//
//                var vec = NOT_VERY_NICE_POSITIONS.getOrDefault(positionKey, null);
//
//                if (!accessoriesSlot.isCosmetic && vec != null && (menu.areLinesShown())) {
//                    var start = new Vector3d(slot.x + this.leftPos + 17, slot.y + this.topPos + 9, 5000);
//                    var vec3 = vec.add(0, 0, 5000);
//
//                    this.accessoryLines.add(Pair.of(start, vec3));}
//            }
//        }

        GuiGraphicsUtils.batched(guiGraphics, SLOT, this.handler.slots, (bufferBuilder, poseStack, slot) -> {
            if (!(slot.inventory instanceof ExpandedSimpleContainer) || !slot.isEnabled()) return;

            GuiGraphicsUtils.blit(bufferBuilder, poseStack, slot.x + this.x, slot.y + this.y, 18);
        });

        if (getHoveredSlot() != null && getHoveredSlot() instanceof AccessoriesInternalSlot slot && slot.isEnabled() && !slot.getStack().isEmpty()) {
            if (NOT_VERY_NICE_POSITIONS.containsKey(slot.accessoriesContainer.getSlotName() + slot.getIndex())) {
                ACCESSORY_POSITIONS.add(NOT_VERY_NICE_POSITIONS.get(slot.accessoriesContainer.getSlotName() + slot.getIndex()));

                var positionKey = slot.accessoriesContainer.getSlotName() + slot.getIndex();
                var vec = NOT_VERY_NICE_POSITIONS.getOrDefault(positionKey, null);

                if (!slot.isCosmetic && vec != null && (Accessories.config().screenOptions.hoveredOptions.line())) {
                    var start = new Vector3d(slot.x + this.x + 17, slot.y + this.y + 9, 5000);
                    var vec3 = vec.add(0, 0, 5000);

                    ACCESSORY_LINES.add(Pair.of(start, vec3));
                }
            }
        }

        pose.pop();
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (insideScrollbar(mouseX, mouseY) || (Accessories.config().screenOptions.allowSlotScrolling() && this.focusedSlot instanceof AccessoriesInternalSlot)) {
            int index = (int) Math.max(Math.min(-scrollY + this.handler.scrolledIndex, this.handler.maxScrollableIndex()), 0);

            if (index != handler.scrolledIndex) {
                AccessoriesNetworking.sendToServer(new MenuScroll(index, false));

                return true;
            }
        }

        return super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dragX, double dragY) {
        if (this.isScrolling) {
            int patchYOffset = this.y + 7 + upperPadding;
            int height = getPanelHeight();

            this.handler.smoothScroll = MathHelper.clamp((float) (mouseY - patchYOffset) / (height - 22f), 0.0f, 1.0f); //(menu.smoothScroll + (dragY / (getPanelHeight(upperPadding) - 24)))

            int index = Math.round(this.handler.smoothScroll * this.handler.maxScrollableIndex());

            if (index != handler.scrolledIndex) {
                AccessoriesNetworking.sendToServer(new MenuScroll(index, true));

                return true;
            }
        }

        return super.mouseDragged(mouseX, mouseY, button, dragX, dragY);
    }

    @Override
    public void render(DrawContext guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.render(guiGraphics, mouseX, mouseY, partialTick);

        for (var cosmeticButton : this.cosmeticButtons.values()) {
            cosmeticButton.render(guiGraphics, mouseX, mouseY, partialTick);
        }

        int x = getStartingPanelX();
        int y = this.y;

        int panelHeight = getPanelHeight();

        if (this.handler.overMaxVisibleSlots) {
            int startingY = y + upperPadding + 8;

            startingY += this.handler.smoothScroll * (panelHeight - 24 - this.scrollBarHeight);

            GuiGraphicsUtils.blitSpriteBatched(guiGraphics, AccessoriesScreen.SCROLL_BAR, x + 14, startingY, 6, this.scrollBarHeight);
        }

        //--

        var pose = guiGraphics.getMatrices();

        if (Accessories.config().screenOptions.showGroupTabs()) {
            for (var entry : getGroups(x, y).entrySet()) {
                var group = entry.getKey();
                var pair = entry.getValue();

                var vector = pair.dimensions();

                int v = (pair.isSelected()) ? vector.w : vector.w * 3;

                guiGraphics.drawTexture(HORIZONTAL_TABS, vector.x, vector.y, 0, v, vector.z, vector.w, 19, vector.w * 4); //32,128

                pose.push();

                pose.translate(vector.x + 3, vector.y + 3, 0);
                pose.translate(1, 1, 0);

                if (pair.isSelected) pose.translate(2, 0, 0);

                // MultiDraw?
                guiGraphics.drawGuiTexture(group.icon(), 0, 0, 0, 8, 8);

                pose.pop();
            }
        }

        //--

        if (Accessories.config().screenOptions.hoveredOptions.clickbait()) {
            ACCESSORY_POSITIONS.forEach(pos -> guiGraphics.drawGuiTexture(Accessories.of("highlight/clickbait"), (int) pos.x - 128, (int) pos.y - 128, 100, 256, 256));
            ACCESSORY_POSITIONS.clear();
        }

        this.drawMouseoverTooltip(guiGraphics, mouseX, mouseY);

        if (!ACCESSORY_LINES.isEmpty() && Accessories.config().screenOptions.hoveredOptions.line()) {
            var buf = guiGraphics.getVertexConsumers().getBuffer(RenderLayer.LINES);
            var lastPose = guiGraphics.getMatrices().peek();

            for (Pair<Vector3d, Vector3d> line : ACCESSORY_LINES) {
                var normalVec = line.second().sub(line.first(), new Vector3d()).normalize().get(new Vector3f());

                double segments = Math.max(10, ((int) (line.first().distance(line.second()) * 10)) / 100);
                segments *= 2;

                var movement = (System.currentTimeMillis() / (segments * 1000) % 1);
                var delta = movement % (2 / (segments)) % segments;

                var firstVec = line.first().get(new Vector3f());

                if (delta > 0.05) {
                    buf.vertex(firstVec)
                            .color(255, 255, 255, 255)
                            .overlay(OverlayTexture.DEFAULT_UV)
                            //.uv2(LightTexture.FULL_BLOCK)
                            .normal(lastPose, normalVec.x, normalVec.y, normalVec.z);
                    //.endVertex();

                    var pos = new Vector3d(
                            MathHelper.lerp(delta - 0.05, line.first().x, line.second().x),
                            MathHelper.lerp(delta - 0.05, line.first().y, line.second().y),
                            MathHelper.lerp(delta - 0.05, line.first().z, line.second().z)
                    ).get(new Vector3f());

                    buf.vertex(pos)
                            .color(255, 255, 255, 255)
                            .overlay(OverlayTexture.DEFAULT_UV)
                            //.uv2(LightTexture.FULL_BLOCK)
                            .normal(lastPose, normalVec.x, normalVec.y, normalVec.z);
                    //.endVertex();
                }
                for (int i = 0; i < segments / 2; i++) {
                    var delta1 = ((i * 2) / segments + movement) % 1;
                    var delta2 = ((i * 2 + 1) / segments + movement) % 1;

                    var pos1 = new Vector3d(
                            MathHelper.lerp(delta1, line.first().x, line.second().x),
                            MathHelper.lerp(delta1, line.first().y, line.second().y),
                            MathHelper.lerp(delta1, line.first().z, line.second().z)
                    ).get(new Vector3f());
                    var pos2 = (delta2 > delta1 ? new Vector3d(
                            MathHelper.lerp(delta2, line.first().x, line.second().x),
                            MathHelper.lerp(delta2, line.first().y, line.second().y),
                            MathHelper.lerp(delta2, line.first().z, line.second().z)
                    ) : line.second()).get(new Vector3f());

                    buf.vertex(pos1)
                            .color(255, 255, 255, 255)
                            .overlay(OverlayTexture.DEFAULT_UV)
                            //.setUv2(LightTexture.FULL_BLOCK)
                            .normal(lastPose, normalVec.x, normalVec.y, normalVec.z);
                    //.endVertex();
                    buf.vertex(pos2)
                            .color(255, 255, 255, 255)
                            .overlay(OverlayTexture.DEFAULT_UV)
                            //.setUv2(LightTexture.FULL_BLOCK)
                            .normal(lastPose, normalVec.x, normalVec.y, normalVec.z);
                    //.endVertex();
                }
            }

            client.getBufferBuilders().getEntityVertexConsumers().draw(RenderLayer.LINES);

            ACCESSORY_LINES.clear();
        }
    }

    private ButtonWidget backButton = null;

    private ButtonWidget cosmeticToggleButton = null;
    private ButtonWidget linesToggleButton = null;

    private ButtonWidget unusedSlotsToggleButton = null;
    private ButtonWidget uniqueSlotsToggleButton = null;

    private ButtonWidget tabUpButton = null;
    private ButtonWidget tabDownButton = null;

    @Override
    protected void init() {
        if (!handler.isValidMenu()) {
            MinecraftClient.getInstance().setScreen(
                    new FatalErrorScreen(
                            Text.literal("Accessories Screen Opening Error!"),
                            Text.literal("Unable to open Accessories Screen due to desync with the Server!")
                    ));

            return;
        }

        super.init();

        this.currentTabPage = 1;

        this.cosmeticButtons.clear();

        this.backButton = this.addDrawableChild(
                ButtonWidget.builder(Text.empty(), (btn) -> this.switchToBaseInventory())
                        .dimensions(this.x + 141, this.y + 9, 8, 8)
                        .tooltip(Tooltip.of(Text.translatable(Accessories.translationKey("back.screen"))))
                        .build()).adjustRendering((button, guiGraphics, sprite, x, y, width, height) -> {
            guiGraphics.method_52706(SPRITES_8X8.method_52729(button.field_22763, button.method_25367()), x, y, width, height);

            var pose = guiGraphics.method_51448();

            pose.method_22903();
            pose.method_22904(0.5, 0.5, 0.0);

            guiGraphics.method_52706(BACk_ICON, x, y, width - 1, height - 1);

            pose.method_22909();

            return true;
        });

        var cosmeticsOpen = this.handler.isCosmeticsOpen();

        this.cosmeticToggleButton = this.addDrawableChild(
                ButtonWidget.builder(Text.empty(), (btn) -> {
                            AccessoriesNetworking
                                    .sendToServer(SyncHolderChange.of(HolderProperty.COSMETIC_PROP, this.getScreenHandler().owner(), bl -> !bl));
                        })
                        .tooltip(cosmeticsToggleTooltip(cosmeticsOpen))
                        .dimensions(this.x - 27 + (cosmeticsOpen ? -20 : 0), this.y + 7, (cosmeticsOpen ? 38 : 18), 6)
                        .build());

        var btnOffset = this.y + 7;

        this.unusedSlotsToggleButton = this.addDrawableChild(
                ButtonWidget.builder(Text.empty(), (btn) -> {
                            AccessoriesNetworking
                                    .sendToServer(SyncHolderChange.of(HolderProperty.UNUSED_PROP, this.getScreenHandler().owner(), bl -> !bl));
                        })
                        .tooltip(unusedSlotsToggleButton(this.handler.areUnusedSlotsShown()))
                        .dimensions(this.x + 154, btnOffset, 12, 12)
                        .build()).adjustRendering((button, guiGraphics, sprite, x, y, width, height) -> {
            guiGraphics.method_52706(SPRITES_12X12.method_52729(button.field_22763, button.method_25367()), x, y, width, height);
            guiGraphics.method_52706((this.field_2797.areUnusedSlotsShown() ? UNUSED_SLOTS_SHOWN : UNUSED_SLOTS_HIDDEN), x, y, width, height);

            return true;
        });

        btnOffset += 15;

//        if (Accessories.getConfig().clientData.showLineRendering) {
//            this.linesToggleButton = this.addRenderableWidget(
//                    Button.builder(Component.empty(), (btn) -> {
//                                AccessoriesNetworking
//                                        .sendToServer(SyncHolderChange.of(HolderProperty.LINES_PROP, this.getMenu().owner(), bl -> !bl));
//                            })
//                            .bounds(this.leftPos + 154, btnOffset, 12, 12)
//                            //.bounds(this.leftPos - (this.menu.isCosmeticsOpen() ? 59 : 39), this.topPos + 7, 8, 6)
//                            .build()).adjustRendering((button, guiGraphics, sprite, x, y, width, height) -> {
//                guiGraphics.blitSprite(SPRITES_12X12.get(button.active, button.isHoveredOrFocused()), x, y, width, height);
//                guiGraphics.blitSprite((this.menu.areLinesShown() ? LINE_SHOWN : LINE_HIDDEN), x, y, width, height);
//
//                return true;
//            });
//        }

        int accessoriesSlots = 0;

        for (Slot slot : this.handler.slots) {
            if (!(slot instanceof AccessoriesInternalSlot accessoriesSlot && !accessoriesSlot.isCosmetic)) continue;

            var slotButton = ToggleButton.ofSlot(slot.x + this.x + 13, slot.y + this.y - 2, 300, accessoriesSlot);

            slotButton.visible = accessoriesSlot.isEnabled();
            slotButton.active = accessoriesSlot.isEnabled();

            cosmeticButtons.put(accessoriesSlot, this.addSelectableChild(slotButton));

            accessoriesSlots++;
        }

//        if (tabPageCount() > 1) {
//            this.tabDownButton = this.addRenderableWidget(
//                    Button.builder(Component.literal("⬆"), button -> this.onTabPageChange(true))
//                            .bounds(this.leftPos - 56, this.topPos - 11, 10, 10)
//                            .build());
//
//            this.tabDownButton.active = false;
//
//            var height = getPanelHeight();
//
//            this.tabUpButton = this.addRenderableWidget(
//                    Button.builder(Component.literal("⬇"), button -> this.onTabPageChange(false))
//                            .bounds(this.leftPos - 56, this.topPos + height + 0, 10, 10)
//                            .build());
//
//            this.tabUpButton.setTooltip(Tooltip.create(Component.literal("Page 2")));
//
//            this.tabUpButton.active = tabPageCount() != 1;
//        }

        this.handler.setScrollEvent(this::updateAccessoryToggleButtons);

        this.scrollBarHeight = MathHelper.lerp(Math.min(accessoriesSlots / 20f, 1.0f), 101, 31);

        if (this.scrollBarHeight % 2 == 0) this.scrollBarHeight++;
    }

    private void onTabPageChange(boolean isDown) {
//        if ((this.currentTabPage <= 1 && isDown) || (this.currentTabPage > tabPageCount() && !isDown)) {
//            return;
//        }
//
//        this.currentTabPage += (isDown) ? -1 : 1;
//
//        var lowerLabel = "Page " + (this.currentTabPage - 1);
//        var upperLabel = "Page " + (this.currentTabPage + 1);
//
//        this.tabDownButton.setTooltip(Tooltip.create(Component.literal(lowerLabel)));
//        this.tabUpButton.setTooltip(Tooltip.create(Component.literal(upperLabel)));
//
////        this.tabDownButton.setMessage(Component.literal(lowerLabel));
////        this.tabUpButton.setMessage(Component.literal(upperLabel));
//
//        if (this.currentTabPage <= 1) {
//            this.tabDownButton.active = false;
//        } else if (!this.tabDownButton.active) {
//            this.tabDownButton.active = true;
//        }
//
//        if (this.currentTabPage >= tabPageCount()) {
//            this.tabUpButton.active = false;
//        } else if (!this.tabUpButton.active) {
//            this.tabUpButton.active = true;
//        }
    }

    @Override
    public void onHolderChange(String key) {
        switch (key) {
            case "lines" -> updateLinesButton();
            case "cosmetic" -> updateCosmeticToggleButton();
            case "unused_slots" -> updateUnusedSlotToggleButton();
        }
    }

    public void updateLinesButton() {
//        if (Accessories.getConfig().clientData.showLineRendering) {
//            this.linesToggleButton.setTooltip(linesToggleTooltip(this.menu.areLinesShown()));
//        }
    }

    public void updateCosmeticToggleButton() {
        var btn = this.cosmeticToggleButton;
        btn.setWidth(this.handler.isCosmeticsOpen() ? 38 : 18);
        btn.setX(btn.getX() + (this.handler.isCosmeticsOpen() ? -20 : 20));
        btn.setTooltip(cosmeticsToggleTooltip(this.handler.isCosmeticsOpen()));
    }

    public void updateUnusedSlotToggleButton() {
        this.unusedSlotsToggleButton.setTooltip(unusedSlotsToggleButton(this.handler.areUnusedSlotsShown()));
        this.handler.reopenMenu();
    }

    public void updateAccessoryToggleButtons() {
        for (var entry : cosmeticButtons.entrySet()) {
            var accessoriesSlot = entry.getKey();
            var btn = entry.getValue();

            if (!accessoriesSlot.isEnabled()) {
                btn.active = false;
                btn.visible = false;
            } else {
                btn.setTooltip(toggleTooltip(accessoriesSlot.accessoriesContainer.shouldRender(accessoriesSlot.getIndex())));

                btn.setX(accessoriesSlot.x + this.x + 13);
                btn.setY(accessoriesSlot.y + this.y - 2);

                btn.toggled(accessoriesSlot.accessoriesContainer.shouldRender(accessoriesSlot.getIndex()));

                btn.active = true;
                btn.visible = true;
            }
        }
    }

    private static Tooltip cosmeticsToggleTooltip(boolean value) {
        return createToggleTooltip("slot.cosmetics", value);
    }

    private static Tooltip linesToggleTooltip(boolean value) {
        return createToggleTooltip("lines", value);
    }

    private static Tooltip unusedSlotsToggleButton(boolean value) {
        return createToggleTooltip("unused_slots", value);
    }

    private static Tooltip uniqueSlotsToggleButton(boolean value) {
        return createToggleTooltip("unique_slots", value);
    }

    private static Tooltip toggleTooltip(boolean value) {
        return createToggleTooltip("display", value);
    }

    private static Tooltip createToggleTooltip(String type, boolean value) {
        var key = type + ".toggle." + (!value ? "show" : "hide");

        return Tooltip.of(Text.translatable(Accessories.translationKey(key)));
    }

    @Override
    public @Nullable Boolean isHovering_Logical(Slot slot, double mouseX, double mouseY) {
        for (var child : this.children()) {
            if (child instanceof ToggleButton btn && btn.isMouseOver(mouseX, mouseY)) return false;
        }

        return ContainerScreenExtension.super.isHovering_Logical(slot, mouseX, mouseY);
    }

    @Override
    protected void drawMouseoverTooltip(DrawContext guiGraphics, int x, int y) {
        if (this.focusedSlot instanceof AccessoriesInternalSlot slot) {
            AccessoriesScreenBase.FORCE_TOOLTIP_LEFT.setValue(true);

            if (slot.getStack().isEmpty() && slot.accessoriesContainer.slotType() != null) {
                guiGraphics.drawTooltip(MinecraftClient.getInstance().textRenderer, slot.getTooltipData(), Optional.empty(), x, y);

                return;
            }
        }

        if (Accessories.config().screenOptions.showGroupTabs()) {
            int panelX = getStartingPanelX();
            int panelY = this.y;

            for (var entry : getGroups(panelX, panelY).entrySet()) {
                if (!entry.getValue().isInBounds(x, y)) continue;

                var tooltipData = new ArrayList<Text>();
                var group = entry.getKey();

                tooltipData.add(Text.translatable(group.translation()));
                if (UniqueSlotHandling.isUniqueGroup(group.name(), true)) tooltipData.add(Text.literal(group.name()).formatted(Formatting.BLUE, Formatting.ITALIC));

                guiGraphics.drawTooltip(MinecraftClient.getInstance().textRenderer, tooltipData, Optional.empty(), x, y);

                break;
            }
        }

        super.drawMouseoverTooltip(guiGraphics, x, y);

        AccessoriesScreenBase.FORCE_TOOLTIP_LEFT.setValue(false);
    }

    @Override
    protected boolean isClickOutsideBounds(double mouseX, double mouseY, int x, int y, int mouseButton) {
        int leftPos = this.x;
        int topPos = this.y;

        boolean insideMainPanel = (mouseX >= leftPos && mouseX <= leftPos + this.backgroundWidth)
                && (mouseY >= topPos && mouseY <= topPos + this.backgroundHeight);

        int sidePanelX = getStartingPanelX();
        int sidePanelY = topPos;

        boolean insideSidePanel = (mouseX >= sidePanelX && mouseX <= sidePanelX + this.getPanelWidth() + this.backgroundWidth)
                && (mouseY >= sidePanelY && mouseY <= sidePanelY + this.getPanelHeight());

        boolean insideGroupPanel = false;

        if (Accessories.config().screenOptions.showGroupTabs() && this.handler.maxScrollableIndex() > 0) {
            for (var value : this.getGroups(sidePanelX, sidePanelY).values()) {
                if (value.isInBounds((int) Math.round(mouseX), (int) Math.round(mouseY))) {
                    insideGroupPanel = true;
                    break;
                }
            }
        }

        return !(insideMainPanel || insideSidePanel || insideGroupPanel);
    }

    public static int tabPageCount() {
        var groups = SlotGroupLoader.INSTANCE.getGroups(true, true);

        return (int) Math.ceil(groups.size() / 9f);
    }

    // MAX 9
    private Map<SlotGroup, SlotGroupData> getGroups(int x, int y) {
        var groups = this.getScreenHandler().validGroups().stream()
                .sorted(Comparator.comparingInt(SlotGroup::order).reversed())
                .toList();

        if (tabPageCount() > 1) {
            var lowerBound = (this.currentTabPage - 1) * 9;
            var upperBound = lowerBound + 9;

            if (upperBound > groups.size()) upperBound = groups.size();

            groups = groups.subList(lowerBound, upperBound);
        }

        var bottomIndex = this.handler.scrolledIndex;
        var upperIndex = bottomIndex + 8 - 1;

        var scrollRange = Range.between(bottomIndex, upperIndex, Integer::compareTo);

        var targetEntity = this.targetEntityDefaulted();
        var containers = targetEntity.accessoriesCapability().getContainers();

        var slotToSize = new HashMap<String, Integer>();

        for (var slotType : EntitySlotLoader.getEntitySlots(targetEntity).values()) {
            var usedSlots = this.getScreenHandler().usedSlots();
            if (usedSlots != null && !usedSlots.contains(slotType)) continue;

            var container = containers.get(slotType.name());
            if(container == null) continue;

            slotToSize.put(slotType.name(), container.getAccessories().method_5439());
        }

        int currentIndexOffset = 0;

        var groupToIndex = new HashMap<SlotGroup, Integer>();
        var selectedGroup = new HashSet<String>();

        for (var group : groups) {
            var groupSize = slotToSize.entrySet().stream()
                    .filter(entry -> group.slots().contains(entry.getKey()))
                    .mapToInt(Map.Entry::getValue)
                    .sum();

            if (groupSize <= 0) continue;

            var groupMinIndex = currentIndexOffset;
            var groupMaxIndex = groupMinIndex + groupSize - 1;

            var groupRange = Range.between(groupMinIndex, groupMaxIndex, Integer::compareTo);

            if (groupRange.isOverlappedBy(scrollRange)) {
                selectedGroup.add(group.name());
            }

            groupToIndex.put(group, groupMinIndex);

            currentIndexOffset += groupSize;
        }

        int maxHeight = getPanelHeight() - 4;

        int width = 19;//32;
        int height = 16;//28;

        int tabY = y + 4;
        int tabX = x - (width - 10);

        int yOffset = 0;

        var groupValues = new HashMap<SlotGroup, SlotGroupData>();

        for (var group : groups) {
            if ((yOffset + height) > maxHeight) break;

            var selected = selectedGroup.contains(group.name());

            int xOffset = (selected) ? 0 : 2;

            var index = groupToIndex.get(group);

            if (index == null) continue;

            groupValues.put(group, new SlotGroupData(new Vector4i(tabX + xOffset, tabY + yOffset, width - xOffset, height), selected, index));

            yOffset += height + 1;
        }

        return groupValues;
    }

    private static SlotGroupImpl copy(SlotGroup group) {
        return new SlotGroupImpl(group.name() + 1, group.order(), group.slots(), group.icon());
    }

    private record SlotGroupData(Vector4i dimensions, boolean isSelected, int startingIndex) {
        private boolean isInBounds(int x, int y) {
            return (x > dimensions.x) && (y > dimensions.y) && (x < dimensions.x + dimensions.z) && (y < dimensions.y + dimensions.w);
        }
    }

    //--

    private void renderEntityInInventoryFollowingMouseRotated(DrawContext guiGraphics, Vector2i pos, Vector2i size, Vector2i scissorStart, Vector2i scissorEnd, float mouseX, float mouseY, float rotation) {
        int scale = 30;
        float yOffset = 0.0625F;
        var entity = this.targetEntityDefaulted();

        float f = (float) (pos.x + pos.x + size.x) / 2.0F;
        float g = (float) (pos.y + pos.y + size.y) / 2.0F;
        guiGraphics.enableScissor(scissorStart.x, scissorStart.y, scissorEnd.x, scissorEnd.y);
        float h = (float) Math.atan(((scissorStart.x + scissorStart.x + size.x) / 2f - mouseX) / 40.0F);
        float i = (float) Math.atan(((scissorStart.y + scissorStart.y + size.y) / 2f - mouseY) / 40.0F);
        Quaternionf quaternionf = (new Quaternionf()).rotateZ(3.1415927F).rotateY((float) (rotation * (Math.PI / 180)));
        Quaternionf quaternionf2 = (new Quaternionf()).rotateX(i * 20.0F * 0.017453292F);
        quaternionf.mul(quaternionf2);
        float j = entity.bodyYaw;
        float k = entity.getYaw();
        float l = entity.getPitch();
        float m = entity.prevHeadYaw;
        float n = entity.headYaw;
        entity.bodyYaw = 180.0F + h * 30.0F;
        entity.setYaw(180.0F + h * 40.0F);
        entity.setPitch(-i * 20.0F);
        entity.headYaw = entity.getYaw();
        entity.prevHeadYaw = entity.getYaw();
        Vector3f vector3f = new Vector3f(0.0F, entity.getHeight() / 2.0F + yOffset, 0.0F);
        InventoryScreen.drawEntity(guiGraphics, f, g, scale, vector3f, quaternionf, quaternionf2, entity);
        entity.bodyYaw = j;
        entity.setYaw(k);
        entity.setPitch(l);
        entity.prevHeadYaw = m;
        entity.headYaw = n;
        guiGraphics.disableScissor();
    }

    public Slot getHoveredSlot() {
        return this.focusedSlot;
    }
}
