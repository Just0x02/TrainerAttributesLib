package io.wispforest.accessories.client;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import io.wispforest.accessories.pond.AccessoriesFrameBufferExtension;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gl.SimpleFramebuffer;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL30;
import org.lwjgl.opengl.GL30C;

public class PostEffectBuffer {

    private Framebuffer framebuffer = null;
    private int prevBuffer = 0;
    private int textureFilter = -1;

    public void clear() {
        this.ensureInitialized();

        int previousBuffer = GlStateManager.getBoundFramebuffer();
        this.framebuffer.clear(MinecraftClient.IS_SYSTEM_MAC);
        GlStateManager._glBindFramebuffer(GL30.GL_FRAMEBUFFER, previousBuffer);
    }

    public void beginWrite(boolean clear, int blitFromMain) {
        this.ensureInitialized();

        this.prevBuffer = GlStateManager.getBoundFramebuffer();
        if (clear) this.framebuffer.clear(MinecraftClient.IS_SYSTEM_MAC);

        if (blitFromMain != 0) {
            GlStateManager._glBindFramebuffer(GL30C.GL_READ_FRAMEBUFFER, this.prevBuffer);
            GlStateManager._glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, this.framebuffer.fbo);
            GL30.glBlitFramebuffer(
                    0, 0,
                    this.framebuffer.textureWidth, this.framebuffer.textureHeight,
                    0, 0,
                    this.framebuffer.textureWidth, this.framebuffer.textureHeight,
                    blitFromMain, GL11.GL_NEAREST
            );
        }

        this.framebuffer.beginWrite(false);
    }

    public void endWrite() {
        GlStateManager._glBindFramebuffer(GL30C.GL_FRAMEBUFFER, this.prevBuffer);
    }

    public void draw(boolean blend) {
        if (blend) {
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
        }

        RenderSystem.backupProjectionMatrix();
        this.framebuffer.draw(this.framebuffer.textureWidth, this.framebuffer.textureHeight, !blend);
        RenderSystem.restoreProjectionMatrix();
    }

    public void draw(float[] color) {
        ((AccessoriesFrameBufferExtension)this.framebuffer).accessories$setUseHighlightShader(true);
        AccessoriesClient.BLIT_SHADER.colorModulator.setAndFlip(color[0], color[1], color[2], color[3]);
        this.draw(true);
        ((AccessoriesFrameBufferExtension)this.framebuffer).accessories$setUseHighlightShader(false);
    }

    public Framebuffer buffer() {
        this.ensureInitialized();
        return this.framebuffer;
    }

    private void ensureInitialized() {
        if (this.framebuffer != null) return;

        this.framebuffer = new SimpleFramebuffer(MinecraftClient.getInstance().getFramebuffer().textureWidth, MinecraftClient.getInstance().getFramebuffer().textureHeight, true, MinecraftClient.IS_SYSTEM_MAC);
        this.framebuffer.setClearColor(0, 0, 0, 0);

        AccessoriesClient.WINDOW_RESIZE_CALLBACK_EVENT.register((client, window) -> {
            this.framebuffer.resize(window.getFramebufferWidth(), window.getFramebufferHeight(), MinecraftClient.IS_SYSTEM_MAC);
            if (this.textureFilter != -1) {
                this.framebuffer.setTexFilter(this.textureFilter);
            }
        });
    }

}
