package io.wispforest.accessories.client.gui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.PressableWidget;
import net.minecraft.util.Identifier;

public class ButtonEvents {

    public static <B extends PressableWidget> B adjustRendering(B button, AdjustRendering event){
        ((AbstractButtonExtension) button).getRenderingEvent().register(event);

        return button;
    }

    public interface AdjustRendering {
        boolean render(PressableWidget button, DrawContext instance, Identifier sprite, int x, int y, int width, int height);
    }
}
